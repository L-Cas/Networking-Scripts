---
type: review
period: weekly
status: active
---
# Weekly Review

## What moved?

- 

## What is waiting or blocked?

```dataview
TABLE WITHOUT ID file.link AS "Work", status AS "Status", site AS "Site", program AS "Program"
FROM "20 Projects"
WHERE status = "waiting" OR status = "blocked"
SORT file.name ASC
```

## Open issues

```dataview
TABLE WITHOUT ID file.link AS "Issue", project AS "Project", site AS "Site"
FROM "30 Records"
WHERE type = "issue" AND status != "resolved"
SORT file.mtime DESC
```

## What should be archived?

- 

## Accomplishments worth remembering

- 
