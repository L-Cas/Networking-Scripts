---
type: dashboard
status: active
focus_project: "[[20 Projects/Program Alpha - 100 User Expansion|Program Alpha - 100 User Expansion]]"
focus_text: "Get the fiber scope quoted and close the capacity questions."
cssclasses:
  - workops-workbench
---
# Operations Workbench

<div class="workops-actions">

`BUTTON[new-project]` `BUTTON[new-record]`

</div>

```meta-bind-button
id: new-project
hidden: true
label: + Project
style: primary
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Project Template.md"
  folderPath: "20 Projects"
  fileName: "New Project - RENAME ME"
  openNote: true
```

```meta-bind-button
id: new-record
hidden: true
label: + Record
style: default
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Record Template.md"
  folderPath: "30 Records"
  fileName: "New Record - RENAME ME"
  openNote: true
```

> [!focus]+ Current Focus
> `VIEW[{focus_project}][link]`
>
> `VIEW[{focus_text}]`

## Today

```tasks
not done
due before tomorrow
sort by priority
sort by due
limit 10
```

## Quick Capture

```dataviewjs
const root = dv.container;
root.classList.add("workops-capture");

const box = document.createElement("textarea");
box.placeholder = "Write a quick note for today's log…";
box.rows = 3;

const status = document.createElement("div");
status.className = "workops-capture-status";

const buttons = document.createElement("div");
buttons.className = "workops-capture-buttons";

const logBtn = document.createElement("button");
logBtn.textContent = "Add to Today";

const taskBtn = document.createElement("button");
taskBtn.textContent = "Add as Task";

buttons.append(logBtn, taskBtn);
root.append(box, buttons, status);

function todayPath() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `01 Daily/${y}/${y}-${m}-${day}.md`;
}

function stamp() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
}

async function ensureDaily(path) {
  let file = app.vault.getAbstractFileByPath(path);
  if (file) return file;

  const ymd = path.split("/").pop().replace(".md","");
  const initial = `---\ntype: daily\ndate: ${ymd}\n---\n# ${ymd}\n\n## Today\n\n## Log\n\n## Actions\n\n## Wrap-up\n\n`;
  await app.vault.create(path, initial);
  return app.vault.getAbstractFileByPath(path);
}

async function appendUnderHeading(file, heading, line) {
  const text = await app.vault.read(file);
  const marker = `## ${heading}`;
  const idx = text.indexOf(marker);

  if (idx === -1) {
    await app.vault.modify(file, text.trimEnd() + `\n\n${marker}\n\n${line}\n`);
    return;
  }

  const afterHeading = idx + marker.length;
  const nextHeading = text.indexOf("\n## ", afterHeading);
  const insertAt = nextHeading === -1 ? text.length : nextHeading;
  const before = text.slice(0, insertAt).trimEnd();
  const after = text.slice(insertAt);
  await app.vault.modify(file, `${before}\n\n${line}\n${after}`);
}

async function submit(kind) {
  const value = box.value.trim();
  if (!value) {
    status.textContent = "Type something first.";
    return;
  }

  try {
    const path = todayPath();
    const file = await ensureDaily(path);

    if (kind === "log") {
      await appendUnderHeading(file, "Log", `- ${stamp()} — ${value}`);
    } else {
      await appendUnderHeading(file, "Actions", `- [ ] ${value}`);
    }

    box.value = "";
    status.textContent = kind === "log" ? "Added to today's Log." : "Added to today's Actions.";
    setTimeout(() => status.textContent = "", 2200);
  } catch (err) {
    console.error(err);
    status.textContent = "Capture failed. Check Dataview JavaScript permissions.";
  }
}

logBtn.addEventListener("click", () => submit("log"));
taskBtn.addEventListener("click", () => submit("task"));
```

## Active Work

![[98 System/Views/Projects.base#Workbench]]

## Waiting / Issues

```dataview
TABLE WITHOUT ID
  file.link AS "Item",
  type AS "Type",
  status AS "Status",
  site AS "Site"
FROM "20 Projects" OR "30 Records"
WHERE status = "waiting" OR status = "blocked" OR (type = "issue" AND status != "resolved")
SORT file.mtime DESC
LIMIT 10
```

> [!tip]- Open the supporting views
> [[00 Workbench/Weekly Review|Weekly Review]] · [[98 System/Setup|Setup]] · [[98 System/Views/Records.base|Records View]] · [[99 Archive/README|Archive]]
