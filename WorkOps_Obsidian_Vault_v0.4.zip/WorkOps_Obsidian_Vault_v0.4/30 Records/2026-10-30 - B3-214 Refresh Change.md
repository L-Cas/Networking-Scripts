---
type: change
status: planned
date: 2026-10-30
---
# B3-214 Refresh Change

## Related

- [[10 Contexts/Main Campus|Main Campus]]
- [[20 Projects/Main Campus - Tech Refresh|Main Campus Tech Refresh]]
- [[30 Records/B3-214 - Uplink Investigation|B3-214 Uplink Investigation]]

## Plan

1. Capture prechecks.
2. Perform approved migration.
3. Validate uplinks and representative connectivity.

## Rollback

Rollback if required production connectivity cannot be restored in the approved window.
