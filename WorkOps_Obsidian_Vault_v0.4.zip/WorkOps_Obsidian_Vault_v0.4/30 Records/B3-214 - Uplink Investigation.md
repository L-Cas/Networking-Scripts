---
type: issue
status: open
date: 2026-10-28
---
# B3-214 - Uplink Investigation

## Related

- [[10 Contexts/Main Campus|Main Campus]]
- [[20 Projects/Main Campus - Tech Refresh|Main Campus Tech Refresh]]

## Context

Quick observation from the Daily Note became a Record because it now needs investigation and history.

Location: **Building 3 / Room 214**

## Actions

- [ ] Check optic and patching
- [ ] Review counters afterward
