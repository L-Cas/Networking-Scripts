---
type: meeting
date: 2026-10-28
status: complete
---
# Network Coordination Meeting

## Related

- [[10 Contexts/Main Campus|Main Campus]]
- [[10 Contexts/Program Alpha|Program Alpha]]
- [[20 Projects/Main Campus - Tech Refresh|Main Campus Tech Refresh]]
- [[20 Projects/Program Alpha - 100 User Expansion|100 User Expansion]]

## Notes

### Tech refresh

Building sequencing was discussed. No separate record needed beyond this meeting yet.

### Program Alpha expansion

Fiber capacity and access switching were discussed. Fiber work now has enough independent scope for [[20 Projects/100 User Expansion - Fiber Workstream|Fiber Workstream]].

### General

Upcoming maintenance windows and staffing were discussed.

## Actions

- [ ] Send fiber quote request [[20 Projects/100 User Expansion - Fiber Workstream|Fiber Workstream]]
- [ ] Review building sequencing [[20 Projects/Main Campus - Tech Refresh|Main Campus Tech Refresh]]
