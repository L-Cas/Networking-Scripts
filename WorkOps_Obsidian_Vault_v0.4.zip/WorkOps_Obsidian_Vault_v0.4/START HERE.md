---
type: guide
version: "0.4"
status: active
---
# WorkOps v0.4

V0.4 is the **lean build**.

The goal is not to track everything. The goal is to make it effortless to capture work, preserve context, and surface what matters.

## Core structure

```text
00 Workbench    → the place you work from
01 Daily        → scratchpad + daily history
10 Contexts     → sites and programs
20 Projects     → outcomes you are managing
30 Records      → meetings, issues, decisions, changes, contextual notes
40 Reference    → durable knowledge
90 Templates    → repeatable note creation
98 System       → views/setup/assets
99 Archive      → old work, preserved
```

## Mental model

**Something happened** → Log it in today's Daily Note  
**Something needs action** → Make it a task  
**Something deserves its own history/context** → Create a Record  
**Something has an outcome with multiple actions** → Create a Project  
**Something describes where/who the work belongs to** → Create a Context

Start at [[00 Workbench/Workbench|Workbench]].
