---
type: daily
date: {{date:YYYY-MM-DD}}
---
# {{date:dddd · MMMM D}}

## Today

- [ ] 
- [ ] 
- [ ] 

## Log

- {{time:HH:mm}} — 

## Actions

- [ ] 

## Wrap-up

**Accomplished**
- 

**Carry forward**
- 
