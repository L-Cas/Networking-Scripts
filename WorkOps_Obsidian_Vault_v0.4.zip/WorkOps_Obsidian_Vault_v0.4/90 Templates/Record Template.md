<%*
const title = await tp.system.prompt("Record title");
const kind = await tp.system.suggester(
  ["Meeting", "General Note", "Issue", "Change", "Decision", "Other"],
  ["meeting", "record", "issue", "change", "decision", "record"]
);
if (title) await tp.file.rename(`${tp.date.now("YYYY-MM-DD")} - ${title}`);
%>
---
type: <% kind %>
date: <% tp.date.now("YYYY-MM-DD") %>
status:
---
# <% tp.file.title %>

## Related

- 

## Notes

## Actions

- [ ] 
