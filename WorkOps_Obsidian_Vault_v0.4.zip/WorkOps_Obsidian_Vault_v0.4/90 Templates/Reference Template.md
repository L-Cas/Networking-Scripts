<%*
const title = await tp.system.prompt("Reference title");
if (title) await tp.file.rename(title);
%>
---
type: reference
status: active
---
# <% tp.file.title %>

## Notes
