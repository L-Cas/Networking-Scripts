<%*
const title = await tp.system.prompt("Context name");
const kind = await tp.system.suggester(["Site", "Program"], ["site", "program"]);
if (title) await tp.file.rename(title);
%>
---
type: <% kind %>
status: active
---
# <% tp.file.title %>

## Notes

## Projects

```dataview
TABLE WITHOUT ID file.link AS "Project", status AS "Status", target AS "Target"
FROM "20 Projects"
WHERE site = this.file.link OR program = this.file.link
SORT file.name ASC
```
