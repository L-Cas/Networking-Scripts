<%*
const name = await tp.system.prompt("Project name");
if (name) await tp.file.rename(name);
%>
---
type: project
status: active
site:
program:
location:
parent_project:
target:
priority:
---
# <% tp.file.title %>

## Objective

## Current status

## Next actions

- [ ] 

## Related records

```dataview
TABLE WITHOUT ID file.link AS "Record", type AS "Type", file.mtime AS "Updated"
FROM "30 Records"
WHERE contains(file.outlinks, this.file.link)
SORT file.mtime DESC
```

## Notes
