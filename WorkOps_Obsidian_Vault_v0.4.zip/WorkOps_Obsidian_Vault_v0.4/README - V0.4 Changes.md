# V0.4 Changes

V0.4 deliberately removes complexity.

## Removed

- separate Sites and Programs folders
- separate Meetings / Issues / Changes / Decisions folders
- Activity note system
- large Operations Pulse metrics
- multiple setup/philosophy/reference notes
- mirrored archive hierarchy
- separate workstream note type
- Daily Note sections for every possible record type

## Added / simplified

- `10 Contexts` for Sites + Programs
- `30 Records` for Meetings + Issues + Changes + Decisions + contextual notes
- one Workbench
- one Weekly Review
- embedded Quick Capture → today's Daily Note
- two deliberate create buttons: Project and Record
- four-section Daily Note
- archive by year
