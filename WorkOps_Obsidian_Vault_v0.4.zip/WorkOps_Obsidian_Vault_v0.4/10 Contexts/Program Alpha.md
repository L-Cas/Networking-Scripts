---
type: program
status: active
---
# Program Alpha

Supported program at [[10 Contexts/Main Campus|Main Campus]].

## Projects

```dataview
TABLE WITHOUT ID file.link AS "Project", site AS "Site", location AS "Location", status AS "Status", target AS "Target"
FROM "20 Projects"
WHERE program = this.file.link AND status != "archived"
SORT file.name ASC
```

## Related records

```dataview
TABLE WITHOUT ID file.link AS "Record", type AS "Type", file.mtime AS "Updated"
FROM "30 Records"
WHERE contains(file.outlinks, this.file.link)
SORT file.mtime DESC
LIMIT 15
```
