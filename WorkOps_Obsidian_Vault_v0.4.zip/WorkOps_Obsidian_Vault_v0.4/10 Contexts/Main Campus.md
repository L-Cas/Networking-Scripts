---
type: site
status: active
---
# Main Campus

Large multi-building campus.

## Active projects

```dataview
TABLE WITHOUT ID file.link AS "Project", program AS "Program", location AS "Location", status AS "Status", target AS "Target"
FROM "20 Projects"
WHERE site = this.file.link AND status != "archived"
SORT file.name ASC
```

## Related records

```dataview
TABLE WITHOUT ID file.link AS "Record", type AS "Type", file.mtime AS "Updated"
FROM "30 Records"
WHERE contains(file.outlinks, this.file.link)
SORT file.mtime DESC
LIMIT 15
```
