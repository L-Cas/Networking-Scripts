---
type: site
status: active
---
# Remote Site

Smaller single-building site.

Use locations like:

`Floor 2 / IDF`
