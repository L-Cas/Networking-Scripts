---
type: reference
status: active
---
# Reference

Use this folder only for durable knowledge you expect to reuse:

- procedures
- troubleshooting notes
- useful commands
- vendor/process notes
- documentation

Do not use it for temporary work context; that belongs in Daily Notes or Records.
