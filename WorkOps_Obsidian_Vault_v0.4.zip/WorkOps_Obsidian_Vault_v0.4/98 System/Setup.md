---
type: system
status: active
---
# Setup

## Core Obsidian

Enable:

- Bases
- Daily Notes
- Properties
- Templates
- Backlinks
- Workspaces

Daily Notes:

- Folder: `01 Daily/2026`
- Template: `90 Templates/Daily Note Template`
- Format: `YYYY-MM-DD`

## Community plugins

### Keep

1. **Tasks** — centralized task views
2. **Dataview** — live context/project views + Workbench capture widget
3. **Templater** — smart templates
4. **Meta Bind** — the two Workbench create buttons
5. **Calendar Plus** — sidebar Daily Note calendar
6. **Homepage** — open the Workbench at startup

### Optional later

- QuickAdd — hotkey capture when you are not on the Workbench
- Full Calendar Remastered — only if scheduled work needs a full calendar
- Commander — only if you actually want more ribbon buttons
- Contribution Graph — only if review/metrics become valuable

## Dataview setting

Enable JavaScript queries for the Workbench Quick Capture box.

## Homepage

Startup note:

`00 Workbench/Workbench.md`

## Calendar Plus

Keep it in the right sidebar. The calendar should navigate Daily Notes; it does not need to occupy the Workbench itself.

## Principle

Plugins provide interaction.

Markdown, links, and properties remain the source of truth.
