---
type: project
status: waiting
site: "[[10 Contexts/Main Campus|Main Campus]]"
program: "[[10 Contexts/Program Alpha|Program Alpha]]"
location: "Building 3 / East Wing"
parent_project: "[[20 Projects/Program Alpha - 100 User Expansion|Program Alpha - 100 User Expansion]]"
target: 2026-11-20
priority: high
---
# 100 User Expansion - Fiber Workstream

## Objective

Scope, quote, schedule, and validate the required fiber work.

## Actions

- [ ] Confirm spare-strand assumptions
- [ ] Send quote request
- [ ] #waiting Receive vendor quote
- [ ] Review scope
- [ ] Confirm funding path
- [ ] Schedule installation
- [ ] Validate installation
