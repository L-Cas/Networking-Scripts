---
type: project
status: active
site: "[[10 Contexts/Main Campus|Main Campus]]"
program:
location:
parent_project:
target: 2027-03-31
priority: high
---
# Main Campus - Tech Refresh

## Objective

Refresh aging infrastructure across the campus.

## Next actions

- [ ] Confirm next building sequence
- [ ] Review hardware allocation
- [ ] Update migration checklist

## Notes

Use this page for durable project context. Room-level details can stay in Daily Notes or Records unless they become their own workstream.

## Related records

```dataview
TABLE WITHOUT ID file.link AS "Record", type AS "Type", file.mtime AS "Updated"
FROM "30 Records"
WHERE contains(file.outlinks, this.file.link)
SORT file.mtime DESC
```
