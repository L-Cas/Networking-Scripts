---
type: project
status: active
site: "[[10 Contexts/Main Campus|Main Campus]]"
program: "[[10 Contexts/Program Alpha|Program Alpha]]"
location: "Building 3 / East Wing"
parent_project:
target: 2026-12-15
priority: high
---
# Program Alpha - 100 User Expansion

## Objective

Support approximately 100 additional users.

## Current status

Capacity review is active. Fiber work became complex enough to earn its own child project.

## Next actions

- [ ] Validate access-switch capacity
- [ ] Review wireless impact
- [ ] Confirm jack requirements
- [ ] Review fiber quote when received

## Child projects

```dataview
TABLE WITHOUT ID file.link AS "Workstream", status AS "Status", target AS "Target"
FROM "20 Projects"
WHERE parent_project = this.file.link AND status != "archived"
```

## Related records

```dataview
TABLE WITHOUT ID file.link AS "Record", type AS "Type", file.mtime AS "Updated"
FROM "30 Records"
WHERE contains(file.outlinks, this.file.link)
SORT file.mtime DESC
```
