---
type: system
status: active
---
# Archive

Move completed, cancelled, or superseded material into the current year folder instead of deleting it.

Keep the note properties that explain what it was and why it was archived.
