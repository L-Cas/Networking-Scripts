---
type: project
status: archived
archived: 2026-08-21
archive_reason: completed
---
# Example - Completed Pilot

A tiny example showing that archived work remains available without cluttering active views.
