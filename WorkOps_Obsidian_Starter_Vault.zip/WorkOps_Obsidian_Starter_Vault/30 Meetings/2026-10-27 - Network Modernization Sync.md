---
type: meeting
status: complete
date: 2026-10-27
program: "[[10 Programs/North Campus Network Modernization|North Campus Network Modernization]]"
projects:
  - "[[20 Projects/Closet A21 Cutover|Closet A21 Cutover]]"
  - "[[20 Projects/Wireless Controller Upgrade|Wireless Controller Upgrade]]"
meeting_type: project-sync
---
# Network Modernization Sync — 2026-10-27

## Attendees

- Demo Engineer
- Demo Operations
- Demo Project Lead

## Agenda

1. A21 readiness
2. Wireless dependency
3. November change windows

## Notes

- [[20 Projects/Closet A21 Cutover|Closet A21 Cutover]] is on track if optics validate.
- [[20 Projects/Wireless Controller Upgrade|Wireless Controller Upgrade]] remains dependent on an implementation window.

## Decisions

- Preserve the A21 change date unless the optic test fails.
- Wireless work moves only after the external dependency clears.

## Actions

- [ ] Validate A21 optics 📅 2026-10-29 [[20 Projects/Closet A21 Cutover|Closet A21 Cutover]]
- [ ] #waiting Confirm wireless implementation window 📅 2026-11-15 [[20 Projects/Wireless Controller Upgrade|Wireless Controller Upgrade]]
