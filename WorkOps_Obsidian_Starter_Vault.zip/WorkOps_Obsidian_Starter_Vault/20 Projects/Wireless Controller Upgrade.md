---
type: project
status: waiting
priority: medium
program: "[[10 Programs/North Campus Network Modernization|North Campus Network Modernization]]"
owner: me
started: 2026-10-01
target: 2027-01-31
health: waiting
area: wireless
---
# Wireless Controller Upgrade

## Current status

Design direction is agreed, but implementation is waiting on an upstream dependency.

## Waiting on

- [ ] #waiting Receive approved implementation window 📅 2026-11-15

## Notes

This project demonstrates how `status: waiting` flows into the Command Center automatically.
