---
type: project
status: active
priority: high
program: "[[10 Programs/North Campus Network Modernization|North Campus Network Modernization]]"
owner: me
started: 2026-10-20
target: 2026-10-30
health: watch
area: network
---
# Closet A21 Cutover

> [!warning] Demo project
> This is fictional sample content.

## Current status

Hardware staged. Configuration review is complete. Final dependency is optic/fiber validation before the change window.

## Next actions

- [ ] Validate uplink optics 🔺 📅 2026-10-29
- [ ] Confirm rollback configuration 📅 2026-10-29
- [ ] Export precheck evidence 📅 2026-10-30
- [ ] Run post-cutover validation 📅 2026-10-30

## Project timeline

- **2026-10-20** — Project opened.
- **2026-10-24** — Config draft completed.
- **2026-10-27** — Review meeting completed.
- **2026-10-28** — Prechecks completed.
- **2026-10-30** — Planned change window.

## Related records

```base
filters:
  and:
    - 'file.hasLink(this.file)'
    - or:
        - 'type == "meeting"'
        - 'type == "change"'
        - 'type == "issue"'
        - 'type == "decision"'
        - 'type == "activity"'
views:
  - type: table
    name: Related Work
    groupBy:
      property: type
      direction: ASC
    order:
      - file.name
      - type
      - status
      - date
```

## Notes

Use this page for durable project knowledge. Fast meeting notes and random observations can remain in Daily Notes until they are worth promoting.
