---
type: change
status: planned
date: 2026-10-30
project: "[[20 Projects/Closet A21 Cutover|Closet A21 Cutover]]"
risk: medium
window: "18:00-20:00"
---
# Change — Closet A21 Cutover

## Objective

Replace the demo access stack and validate connectivity.

## Preconditions

- [ ] Optics validated
- [ ] Configuration reviewed
- [ ] Rollback configuration available
- [ ] Stakeholders notified

## Implementation

1. Capture prechecks.
2. Move uplinks according to approved procedure.
3. Validate stack state.
4. Validate routing/uplink state.
5. Validate representative endpoint connectivity.

## Rollback trigger

Rollback if uplink stability or required production connectivity cannot be restored within the approved window.

## Validation

- [ ] Uplinks healthy
- [ ] Expected VLANs present
- [ ] No unexpected spanning-tree state
- [ ] Representative endpoints pass
- [ ] Monitoring clean
