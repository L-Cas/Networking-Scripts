---
type: issue
status: open
date: 2026-10-28
project: "[[20 Projects/Closet A21 Cutover|Closet A21 Cutover]]"
priority: high
owner: vendor
---
# Issue — Optics Delivery Delay

## Impact

Could threaten the planned [[40 Operations/Changes/2026-10-30 - Closet A21 Cutover|A21 change window]] if validation cannot occur in time.

## Current state

Temporary test optics are available. Permanent inventory is still in transit.

## Actions

- [ ] #waiting Confirm permanent delivery ETA 📅 2026-10-29
- [ ] Validate temporary optics as fallback 📅 2026-10-29
