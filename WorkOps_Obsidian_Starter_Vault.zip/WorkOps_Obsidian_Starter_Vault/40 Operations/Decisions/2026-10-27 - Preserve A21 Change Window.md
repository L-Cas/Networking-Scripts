---
type: decision
status: accepted
date: 2026-10-27
project: "[[20 Projects/Closet A21 Cutover|Closet A21 Cutover]]"
decision_owner: project-team
---
# Decision — Preserve A21 Change Window

## Decision

Keep the 2026-10-30 change window unless optic validation fails.

## Rationale

Configuration and staging are complete, and the remaining dependency has a practical fallback.

## Consequence

Optic validation becomes the final go/no-go item.
