# What to Try

## Demo route

1. Open **START HERE**.
2. Open **Work Command Center**.
3. Click the active program.
4. Open **Closet A21 Cutover**.
5. Notice its inline Base of related records.
6. Open the **2026-10-28 Daily Note** and see how fast capture links back into structured work.
7. Open `80 Bases/Projects.base` and switch among Active, Waiting and Blocked, Cards, and All.
8. Open **Task Center**. Install Tasks later to make its query blocks live.
9. Open **Workflow Architecture.canvas** for the visual model.

## Suggested experiment

Duplicate `Closet A21 Cutover.md`, rename it, and change only these properties:

```yaml
status: active
priority: high
program: "[[North Campus Network Modernization]]"
target: 2026-11-15
health: good
```

The new project should automatically appear in the appropriate Bases views.

That is the core idea of the vault: **edit the source note once; every dashboard updates from the same properties.**
