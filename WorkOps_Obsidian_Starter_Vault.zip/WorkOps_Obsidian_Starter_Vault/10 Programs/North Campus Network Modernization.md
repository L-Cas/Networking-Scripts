---
type: program
status: active
priority: high
owner: me
started: 2026-09-15
target: 2027-03-31
area: network
---
# North Campus Network Modernization

> [!abstract] Program objective
> Modernize switching, improve documentation quality, reduce cutover risk, and create a repeatable migration process. **Fictional demo program.**

## Program health

**Status:** Active  
**Priority:** High  
**Current focus:** Access-layer cutovers and dependency tracking.

## Projects

```base
filters:
  and:
    - 'type == "project"'
    - 'program == this.file.asLink()'
views:
  - type: table
    name: Projects
    order:
      - file.name
      - status
      - priority
      - target
      - health
```

## Recent linked activity

```base
filters:
  and:
    - 'type == "activity"'
    - 'file.hasLink(this.file)'
views:
  - type: table
    name: Activity
    order:
      - date
      - activity_type
      - file.name
```

## Program notes

- Standardize precheck and postcheck format.
- Track external dependencies explicitly.
- Preserve decisions rather than burying them in meeting notes.

## Program-level tasks

- [ ] Review project health every Friday 🔁 every Friday 📅 2026-10-30
- [ ] Confirm November change-window capacity 📅 2026-11-02
