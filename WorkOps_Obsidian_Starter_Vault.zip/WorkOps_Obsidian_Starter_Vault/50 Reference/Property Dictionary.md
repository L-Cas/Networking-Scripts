---
type: reference
status: active
---
# Property Dictionary

Keep property names intentionally small and consistent.

| Property | Used for | Example |
|---|---|---|
| `type` | Object class | `project`, `meeting`, `issue` |
| `status` | Lifecycle | `active`, `waiting`, `complete` |
| `priority` | Importance | `high`, `medium`, `low` |
| `program` | Parent program | `[[Program Name]]` |
| `project` | Parent project | `[[Project Name]]` |
| `date` | Event/record date | `2026-10-28` |
| `target` | Target completion | `2026-12-15` |
| `health` | Project health | `good`, `watch`, `at-risk` |
| `area` | Broad work area | `network`, `wireless` |
| `owner` | Accountability | `me`, `vendor` |

## Recommended status vocabulary

### Programs / Projects

- `active`
- `waiting`
- `blocked`
- `complete`
- `archived`

### Issues

- `open`
- `monitoring`
- `resolved`

### Changes

- `planned`
- `approved`
- `complete`
- `cancelled`

### Decisions

- `proposed`
- `accepted`
- `superseded`
