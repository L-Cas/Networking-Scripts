---
type: reference
status: active
---
# QuickAdd Recipes

These are starter workflows to configure after installing QuickAdd.

## 1. Log Activity

**Goal:** Append a fast timestamped line under `## Notes / Capture` in today's Daily Note.

Suggested captured line:

`**{{TIME:HH:mm}}** — {{VALUE}}`

Good hotkey: something reachable with one hand.

## 2. New Meeting

Use [[90 Templates/Meeting Template]].

Destination folder:

`30 Meetings`

Filename pattern:

`{{DATE:YYYY-MM-DD}} - {{VALUE}}`

## 3. New Project

Use [[90 Templates/Project Template]].

Destination folder:

`20 Projects`

## 4. Capture Task

Append beneath `## Tasks` in today's Daily Note:

`- [ ] {{VALUE}}`

Then use the Tasks plugin's edit command if you want to add due date / recurrence / priority.

## 5. Promote an important note

When a Daily Note item becomes important:

- Create an Issue, Decision, Meeting, Change, or Project note.
- Link it back to the relevant project.
- Leave the original Daily Note entry in place as the historical trace.

That gives you both **chronology** and **structured records**.
