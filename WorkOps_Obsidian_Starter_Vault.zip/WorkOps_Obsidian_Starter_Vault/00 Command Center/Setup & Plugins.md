---
type: guide
status: active
---
# Setup & Plugins

## Core plugins to enable

Open **Settings → Core plugins** and make sure these are enabled:

- Bases
- Daily notes
- Templates
- Canvas
- Properties view
- Backlinks
- Outgoing links
- Command palette
- Workspaces (optional)

## Template settings

**Settings → Templates**

- Template folder location: `90 Templates`

## Daily Notes settings

**Settings → Daily notes**

- New file location: `01 Daily/2026`
- Template file location: `90 Templates/Daily Note Template`
- Date format: `YYYY-MM-DD`

## CSS

The vault includes:

`.obsidian/snippets/work-os.css`

If it is not enabled automatically:

**Settings → Appearance → CSS snippets → Work OS → Enable**

## Recommended community plugins

### Tasks

Use this for vault-wide task queries. The demo dashboards already contain `tasks` code blocks.

Suggested workflow:

- `Ctrl+Enter` → complete a task using the Tasks command
- Use due dates like `📅 2026-10-30`
- Use `#waiting` for externally blocked work

### QuickAdd

Use QuickAdd only after the basic structure feels natural.

Good first QuickAdd choices:

1. **Log Activity** → append a timestamped line to today's note
2. **New Meeting** → create from Meeting Template in `30 Meetings`
3. **New Project** → create from Project Template in `20 Projects`
4. **Capture Task** → append a checkbox under `## Tasks` in today's Daily Note

See [[50 Reference/QuickAdd Recipes]].

### Dataview

Not required for the starter system. Add it later for calculations, advanced metrics, and a true contribution-style heatmap.

## Suggested hotkeys

- Daily Notes: Open today's daily note → `Ctrl+Alt+D`
- Quick Switcher → `Ctrl+O`
- Command Palette → `Ctrl+P`
- New task (Tasks plugin) → choose an easy shortcut
- QuickAdd: Log Activity → choose an easy shortcut

## Upgrade path

**Phase 1:** Daily Notes + Projects + Programs + Bases  
**Phase 2:** Tasks + QuickAdd  
**Phase 3:** Weekly/monthly metrics + activity heatmap  
**Phase 4:** Automated project health and review dashboards
