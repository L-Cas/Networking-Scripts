---
type: dashboard
status: active
cssclasses:
  - work-dashboard
---
# ✅ Task Center

> [!tip] Requires the Tasks community plugin
> The checkboxes still remain normal Markdown if the plugin is not installed.

## Today + Overdue

```tasks
not done
due before tomorrow
sort by priority
sort by due
```

## Next 7 Days

```tasks
not done
due after today
due before in 8 days
sort by due
```

## Waiting

```tasks
not done
description includes #waiting
sort by due
```

## High Priority

```tasks
not done
priority is above medium
sort by due
```

## Completed Recently

```tasks
done after 2026-10-20
sort by done reverse
limit 25
```
