---
type: dashboard
status: active
cssclasses:
  - work-dashboard
---
# 🛰 Work Command Center

> [!ops] Operating picture
> **Today:** [[01 Daily/2026/2026-10-28|2026-10-28]]  
> **Weekly Review:** [[00 Command Center/Weekly Review]]  
> **Task Center:** [[00 Command Center/Task Center]]  
> **Architecture:** [[00 Command Center/Workflow Architecture.canvas|Open Canvas]]

## 🔥 Today / Overdue

> [!note] Optional Tasks plugin view
> Once the **Tasks** community plugin is installed, this becomes a live list gathered from the entire vault.

```tasks
not done
due before tomorrow
sort by priority
sort by due
limit 30
```

## 🧭 Active Programs

![[80 Bases/Programs.base#Active]]

## 🚧 Active Projects

![[80 Bases/Projects.base#Active]]

## ⏸ Waiting / Blocked

![[80 Bases/Projects.base#Waiting and Blocked]]

## 🛠 Open Changes

![[80 Bases/Operations.base#Open Changes]]

## ⚠ Open Issues

![[80 Bases/Operations.base#Open Issues]]

## 📝 Recent Decisions

![[80 Bases/Operations.base#Recent Decisions]]

## 📡 Recent Activity

![[80 Bases/Activity.base#Recent]]

## 📅 Recent Meetings

![[80 Bases/Meetings.base#Recent]]

---

### Capture rule

If you're busy, **do not stop to file the thought perfectly**.

1. Put it in today's Daily Note.
2. Add `[[Project Name]]` when obvious.
3. Add a task checkbox if it requires action.
4. Promote important material into a project/change/decision/meeting note later.
