---
type: dashboard
status: active
---
# 📈 Activity & Metrics

## Current activity records

![[80 Bases/Activity.base#Recent]]

## Why activity records exist

Daily Notes give you chronology. Activity records give you a small number of **important, queryable accomplishments**.

Do **not** create an activity record for every tiny action. Good candidates:

- major validation completed
- cutover completed
- issue resolved
- design reviewed
- deliverable submitted
- milestone reached
- dependency identified
- important documentation completed

## Demo heatmap

The starter vault intentionally does not force a heatmap plugin dependency.

A later version can calculate a contribution-style calendar from:

- Daily Note activity
- completed Tasks
- Activity records
- or a weighted combination of all three

### Example scoring model

| Event | Points |
|---|---:|
| Daily note exists | 1 |
| Task completed | 1 |
| Meeting record | 1 |
| Activity record | 2 |
| Change completed | 3 |
| Issue resolved | 3 |

That creates a work-intensity heatmap without rewarding meaningless note spam.
