---
type: review
period: weekly
status: active
---
# Weekly Review

## 1. Operating picture

- What moved forward?
- What is blocked?
- What is waiting on someone else?
- Which deadline changed?
- What project is receiving too much attention?
- What project is being neglected?

## 2. Active projects

![[80 Bases/Projects.base#Active]]

## 3. Waiting / blocked

![[80 Bases/Projects.base#Waiting and Blocked]]

## 4. Open issues

![[80 Bases/Operations.base#Open Issues]]

## 5. Decisions this week

![[80 Bases/Operations.base#Recent Decisions]]

## 6. Tasks

```tasks
not done
sort by due
sort by priority
limit 50
```

## 7. Accomplishments to preserve

Use this section for performance-review material.

- 
