---
type: guide
status: active
cssclasses:
  - work-dashboard
---
# WorkOps Starter Vault

> [!success] Open this first
> This is a fictional demo vault designed to show how Obsidian can behave like a personal work operations center.

## What is already demonstrated

- **Program → Project → work item hierarchy**
- A central **Work Command Center**
- Obsidian **Bases** for live project, program, meeting, change, issue, decision, and activity views
- A **Daily Note** workflow for fast, messy capture
- An optional **Tasks** command center using normal Markdown checkboxes
- Project pages that automatically pull related notes through links/properties
- Demo meeting, change, issue, decision, and activity records
- Templates for daily notes, programs, projects, meetings, changes, decisions, and issues
- A visual **Canvas** map of the workflow
- A lightweight dashboard CSS snippet

## First 5 minutes

1. Open [[00 Command Center/Work Command Center|Work Command Center]].
2. Open [[10 Programs/North Campus Network Modernization|North Campus Network Modernization]].
3. Open [[20 Projects/Closet A21 Cutover|Closet A21 Cutover]].
4. Open [[01 Daily/2026/2026-10-28|2026-10-28 Daily Note]].
5. Open [[00 Command Center/Workflow Architecture.canvas|Workflow Architecture]].
6. Open any file in `80 Bases` to see the database-style views.

> [!important] Work-data safety
> The demo content is fictional. Before using this for real work, follow your employer's rules for proprietary, controlled, classified, export-controlled, customer, device, credential, or infrastructure data. A local Markdown vault is not automatically approved storage.

## Core design rule

**Capture first. Organize second.**

During active work, write into the Daily Note and add a project/program link when obvious. Structured project pages and Bases give you the organized view later.

## Optional community plugins

The vault works as plain Markdown without them. To unlock the demo query blocks and faster capture, install:

- **Tasks** — vault-wide task queries and completion
- **QuickAdd** — one-command capture workflows
- **Dataview** — optional advanced metrics/heatmaps later
- **Calendar** — convenient Daily Note navigation

See [[00 Command Center/Setup & Plugins]].
