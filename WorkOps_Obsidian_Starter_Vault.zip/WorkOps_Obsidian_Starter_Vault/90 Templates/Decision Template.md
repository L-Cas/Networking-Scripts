---
type: decision
status: accepted
date: {{date:YYYY-MM-DD}}
project:
decision_owner:
---
# {{title}}

## Decision

## Rationale

## Consequence
