---
type: activity
date: {{date:YYYY-MM-DD}}
time: "{{time:HH:mm}}"
activity_type:
project:
program:
---
# {{title}}

## Summary
