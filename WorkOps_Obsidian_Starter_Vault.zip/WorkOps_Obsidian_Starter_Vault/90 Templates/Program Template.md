---
type: program
status: active
priority: medium
owner: me
started: {{date:YYYY-MM-DD}}
target:
area:
---
# {{title}}

## Objective

## Program health

## Projects

```base
filters:
  and:
    - 'type == "project"'
    - 'program == this.file.asLink()'
views:
  - type: table
    name: Projects
    order:
      - file.name
      - status
      - priority
      - target
      - health
```

## Program-level tasks

- [ ] 
