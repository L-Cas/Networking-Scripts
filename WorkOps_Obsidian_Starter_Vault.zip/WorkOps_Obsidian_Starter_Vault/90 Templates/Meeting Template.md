---
type: meeting
status: planned
date: {{date:YYYY-MM-DD}}
program:
projects:
meeting_type:
---
# {{title}}

## Attendees

- 

## Agenda

1. 

## Notes

## Decisions

- 

## Actions

- [ ] 
