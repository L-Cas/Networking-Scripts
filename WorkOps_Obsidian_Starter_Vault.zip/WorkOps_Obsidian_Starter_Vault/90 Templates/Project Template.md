---
type: project
status: active
priority: medium
program:
owner: me
started: {{date:YYYY-MM-DD}}
target:
health: good
area:
---
# {{title}}

## Objective

## Current status

## Next actions

- [ ] 

## Timeline

- **{{date:YYYY-MM-DD}}** — Project created.

## Related records

```base
filters:
  and:
    - 'file.hasLink(this.file)'
    - or:
        - 'type == "meeting"'
        - 'type == "change"'
        - 'type == "issue"'
        - 'type == "decision"'
        - 'type == "activity"'
views:
  - type: table
    name: Related Work
    groupBy:
      property: type
      direction: ASC
    order:
      - file.name
      - type
      - status
      - date
```

## Notes
