---
type: daily
date: {{date:YYYY-MM-DD}}
week:
focus:
---
# {{date:dddd, YYYY-MM-DD}}

## Top 3

- [ ] 
- [ ] 
- [ ] 

## Notes / Capture

**{{time:HH:mm}}** — 

## Meetings

## Tasks

## Activity

## End-of-day

### Accomplished

- 

### Carry forward

- 
