---
type: project
status: Blocked
progress: 25
target: 2026-12-15
locations:
  - "[[04 Locations/DC]]"
  - "[[04 Locations/Richmond]]"
---

# Security Hardening

## Current state

Blocked pending approval of a fictional exception request.

## Open work

- [[02 Work Items/Security hardening exception review]]
