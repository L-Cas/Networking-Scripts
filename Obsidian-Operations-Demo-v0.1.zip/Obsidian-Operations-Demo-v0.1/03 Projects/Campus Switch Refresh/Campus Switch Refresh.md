---
type: project
status: On Track
progress: 42
target: 2027-02-15
locations:
  - "[[04 Locations/Baltimore]]"
  - "[[04 Locations/DC]]"
  - "[[04 Locations/Richmond]]"
---

# Campus Switch Refresh

## Outcome

Standardize fictional campus access switching across multiple locations.

## Why this project matters to the demo

This proves that a project can span several locations without being physically stored under any one site.

## Open work

- [[02 Work Items/Review campus switch baseline]]
- [[02 Work Items/Confirm maintenance window]]

## Notes

- [[03 Projects/Campus Switch Refresh/Scope Notes]]
