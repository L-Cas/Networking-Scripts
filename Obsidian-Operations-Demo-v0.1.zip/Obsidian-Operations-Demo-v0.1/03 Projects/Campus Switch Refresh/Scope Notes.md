---
type: project-note
status: In Progress
project: "[[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]"
---

# Scope Notes

- Baltimore: new deployments should use the new baseline.
- DC: prioritize older access closets.
- Richmond: validate Building B carrier-demarc dependencies before scheduling.
