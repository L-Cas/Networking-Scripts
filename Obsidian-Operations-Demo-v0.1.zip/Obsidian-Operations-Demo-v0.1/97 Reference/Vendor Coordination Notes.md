---
type: reference
---

# Vendor Coordination Notes

General, fictional reminders:

- Confirm delivery window
- Confirm receiving contact
- Confirm tracking number
- Confirm required site-access notice
