# Changelog

## v0.1 — 2026-10-29

Initial demo vault.

- Split Work Items and Projects into separate top-level folders.
- Added centralized dashboards.
- Added native Bases for Work Items, Projects, Locations, Meetings, and Archive.
- Added fictional sample data.
- Added recurring meeting history and carry-forward example.
- Added manual archive example.
- Added property dictionary and plugin registry.
- Added responsive dashboard CSS.
- Kept community plugins unbundled.
