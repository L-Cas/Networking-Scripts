---
type: system
---

# Demo Test Script

Use this to decide whether v0.1 is genuinely helpful.

## 1 — Morning open

Open [[00 Dashboard/Home]].

Check:
- Daily Operations visible?
- Today readable?
- This Week useful?
- Overdue / Waiting obvious without feeling noisy?
- Active projects understandable at a glance?

## 2 — Quick hallway request

Open [[01 Capture/Scratchpad]].

Pretend someone asks:
> “Can you check a switch in DC when you get a chance?”

Write one line only.

Decision:
- If you finish immediately, leave it checked.
- If it survives, create a Work Item using [[98 Templates/Template - Work Item]].

## 3 — Growing work item

Open [[02 Work Items/Investigate DC intermittent disconnects]].

Notice:
- It has subtasks.
- Two subtasks became separate Work Items.
- It is still not forced into a Project.

Ask yourself: does this feel natural?

## 4 — Project history

Open [[03 Projects/Baltimore Site Standup/Baltimore Site Standup]].

Then open [[03 Projects/Baltimore Site Standup/Switch Configuration]].

Notice:
- Switch Configuration is complete.
- It remains inside the active project.
- It should not be individually archived.

## 5 — Cross-context project

Open [[03 Projects/Campus Switch Refresh/Campus Switch Refresh]].

Verify that one project relates to Baltimore, DC, and Richmond without living under any site folder.

## 6 — Meeting carry-forward

Open:
- [[05 Meetings/Weekly Team Meeting/2026-10-26 - Weekly Team Meeting]]
- [[05 Meetings/Weekly Team Meeting/2026-11-02 - Weekly Team Meeting]]

Check whether the carry-forward model makes sense without copying the entire previous meeting.

## 7 — Archive

Open [[99 Archive/Projects/Old Lab Refresh/Old Lab Refresh]].

Confirm:
- It is easy to find intentionally.
- It does not appear in active project views.
- Its history remains intact.

## Evaluation questions

- What required too many clicks?
- What information was duplicated?
- Which dashboard section felt noisy?
- Which status/property felt unnecessary?
- What did you expect to be clickable but was not?
- What did you have trouble finding?
