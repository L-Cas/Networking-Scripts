---
type: system
---

# Plugin Registry

This file is the dependency ledger for the vault.

> [!important]
> Community plugins are **not bundled** in this demo. Install them from **Settings → Community Plugins**. Record the version you actually install in the `Installed/Tested` column.

| Plugin | Kind | Target / current stable at v0.1 build | Required for core demo? | Purpose | Installed/Tested |
|---|---|---:|---:|---|---|
| **Bases** | Core | Obsidian core plugin | Yes | Main editable data views | Built in |
| **QuickAdd** | Community | 2.33.1 | Recommended | Fast capture, templates, promotion workflows | ☐ |
| **Tasks** | Community | 8.5.0 | Recommended | Aggregate inline checkboxes from anywhere in vault | ☐ |
| **Meta Bind** | Community | 1.5.1 | Optional for v0.1 | Interactive property controls/buttons | ☐ |
| **Note Toolbar** | Community | 1.34.13 | Optional for v0.1 | Contextual action bars | ☐ |
| **Homepage** | Community | 4.5.0 | Recommended | Open Home/dashboard on launch | ☐ |
| **Omnisearch** | Community | 1.31.0 | Recommended | Better vault-wide search | ☐ |
| **Full Calendar Remastered** | Community | Install latest stable | Experimental | Calendar/provider experiments | ☐ |
| **Templater** | Community | Install only if needed | No | Advanced template logic | ☐ |

## Recommended install order

1. QuickAdd
2. Tasks
3. Homepage
4. Omnisearch
5. Meta Bind
6. Note Toolbar
7. Calendar plugin only after the core workflow feels good

## Why no plugin is allowed to own the data

The source of truth remains normal Markdown files and properties. Community plugins should improve capture, presentation, and interaction—not make the information unreadable without them.
