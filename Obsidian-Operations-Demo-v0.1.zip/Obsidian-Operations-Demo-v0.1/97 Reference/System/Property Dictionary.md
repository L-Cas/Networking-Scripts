---
type: system
---

# Property Dictionary

Keep this list intentionally small.

| Property | Applies to | Values / format | Required? | Purpose |
|---|---|---|---|---|
| `type` | All structured notes | `work-item`, `project`, `location`, `meeting`, etc. | Yes | Identifies what the note is |
| `status` | Work / projects | See below | Usually | Drives operational views |
| `priority` | Work items | `High`, `Normal`, `Low` | No | Optional signal |
| `date` | Work / meetings | `YYYY-MM-DD` | No | Due/scheduled date |
| `time` | Work items | `"HH:MM"` | No | Optional precision |
| `project` | Work / meetings / project notes | Wikilink | No | Relationship to project |
| `location` | Work / meetings / project notes | Wikilink | No | Location context |
| `locations` | Projects | list of Wikilinks | No | Multi-location project context |
| `source` | Work items | Wikilink | No | Where the work originated |
| `created` | Work items | `YYYY-MM-DD` | No | Creation history |
| `completed` | Completed notes | `YYYY-MM-DD` | No | Completion history |
| `progress` | Projects | integer 0–100 | No | Demo task-completion indicator |
| `target` | Projects | `YYYY-MM-DD` | No | Project target date |

## Work-item statuses

- Open
- In Progress
- Waiting
- Blocked
- Complete

## Project statuses

- Planning
- On Track
- Waiting
- Blocked
- Complete

## Rule

Do **not** add a new property until there is a demonstrated workflow that needs it.
