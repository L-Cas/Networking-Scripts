---
type: system
cssclasses:
  - ops-dashboard
---

# Vault Guide

## Mental model

**Capture** is where information enters.  
**Work Items** are things that need tracking.  
**Projects** coordinate larger bodies of work.  
**Locations** describe places.  
**Meetings** record what was discussed.  
**Dashboards** visualize all of the above.  
**Archive** removes finished material from normal operational views without deleting history.

## Folder map

```text
00 Dashboard
01 Capture
02 Work Items
03 Projects
04 Locations
05 Meetings
97 Reference
98 Templates
99 Archive
```

## Lifecycle

```text
Capture
  ↓
Finish immediately ─────────────→ leave checked in source
  ↓ survives
Work Item
  ↓ needs more context
Work Item note + subtasks
  ↓ needs coordination / milestones / workstreams
Project
  ↓ finished
Complete
  ↓ manual decision
Archive
```

## The promotion rule

Do not classify too early.

A hallway request can begin as one line in Scratchpad. If it takes thirty seconds, finish it there. If it survives, create a Work Item. If the Work Item grows, add context or child items. Only create a Project when project-level coordination is genuinely useful.

## Meetings

Meeting notes may be messy. That is acceptable.

A meeting is a **source**, not the permanent container of every task discussed in it.

If a trackable already exists, reference or update it rather than recreating it.

## Locations

A location note is a **contact card / durable context note**.

Manual content should describe the place itself. Work related to that place remains in Work Items or Projects and links back to the location.

## Completion vs archive

- **Complete** is a status.
- **Archive** is a manual filing decision.
- Completed notes owned by an active project stay with that project.
- Archive the entire finished project folder as a unit.
- Active dashboards exclude `99 Archive` by design.

## Dates

- Date is optional.
- Time is optional and implies extra precision.
- No date does **not** mean backlog. It means open work with no deadline.
- Do not auto-reschedule unfinished work.

## Status vocabulary

`Open` → `In Progress` → `Waiting` / `Blocked` → `Complete`

Projects use:

`Planning` → `On Track` → `Waiting` / `Blocked` → `Complete`

## Priority

Optional:

`High` · `Normal` · `Low`

Do not spend time assigning priority when it adds no value.
