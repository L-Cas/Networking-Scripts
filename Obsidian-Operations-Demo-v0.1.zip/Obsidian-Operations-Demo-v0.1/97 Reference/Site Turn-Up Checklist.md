---
type: reference
---

# Site Turn-Up Checklist

Fictional generic reference used by the demo.

- Confirm rack / power
- Confirm carrier handoff
- Confirm equipment arrival
- Validate management reachability
- Validate user connectivity
- Record handoff notes
