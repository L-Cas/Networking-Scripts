---
type: capture
cssclasses:
  - ops-dashboard
---

# Scratchpad

## Quick Capture

- [ ] Ask vendor whether the Baltimore shipment includes the spare optics.
- [ ] Someone mentioned the DC conference room drops briefly after lunch — check when there is time.
- Cyber team said the new baseline should be used for all new access deployments.
- Need to remember that Richmond has a separate carrier demarc in Building B.
- [x] Check whether tomorrow's rack-power walk-through is still happening.

## Processing idea

Use the lightest possible outcome:

- **Finished quickly?** Check it off and leave it here.
- **Needs to survive?** Create a Work Item.
- **Needs context/history/subtasks?** Give the Work Item its own note.
- **Needs coordination/milestones/workstreams?** Promote to a Project.
