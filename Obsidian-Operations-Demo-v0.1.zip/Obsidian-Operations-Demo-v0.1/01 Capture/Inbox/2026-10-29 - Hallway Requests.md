---
type: capture
date: 2026-10-29
---

# Hallway Requests — 2026-10-29

Messy by design.

- Pat said a workstation in DC keeps dropping for a few seconds.
- Need to check switch logs when there is time.
- Somebody asked whether Baltimore has spare firewall hardware.
- Training is due next week.
- Vendor might have moved shipment ETA again.

Processed outcomes:
- [[02 Work Items/Investigate DC intermittent disconnects]]
- [[02 Work Items/Locate spare firewall]]
- [[02 Work Items/Complete annual training]]
- [[02 Work Items/Confirm Baltimore equipment shipment]]
