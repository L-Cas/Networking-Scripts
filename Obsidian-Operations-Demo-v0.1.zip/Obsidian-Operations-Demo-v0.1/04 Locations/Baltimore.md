---
type: location
region: Mid-Atlantic
site_type: New site
wan_provider: Vendor A
primary_contact: Site Coordinator
---

# Baltimore

> [!info] Location card
> Fictional site used to test location context.

## Durable site information

- **WAN provider:** Vendor A
- **Primary contact:** Site Coordinator
- **Buildings:** Main Building
- **Known quirk:** Delivery dock requires 24-hour notice
- **Reference:** [[97 Reference/Site Turn-Up Checklist]]

## Related projects

- [[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]
- [[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]
