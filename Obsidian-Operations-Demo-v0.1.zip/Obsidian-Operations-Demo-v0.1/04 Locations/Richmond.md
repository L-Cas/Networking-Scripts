---
type: location
region: Mid-Atlantic
site_type: Regional site
wan_provider: Vendor C
primary_contact: Regional Operations
---

# Richmond

## Durable site information

- **WAN provider:** Vendor C
- **Primary contact:** Regional Operations
- **Buildings:** A, B
- **Known quirk:** Building B has a separate carrier demarc
