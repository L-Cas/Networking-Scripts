---
type: location
region: Mid-Atlantic
site_type: Primary campus
wan_provider: Vendor B
primary_contact: Local Operations
---

# DC

## Durable site information

- **WAN provider:** Vendor B
- **Primary contact:** Local Operations
- **Buildings:** North, South
- **Known quirk:** South Building closet access requires escort
