---
type: meeting
date: 2026-10-27
series: Baltimore Vendor Coordination
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
location: "[[04 Locations/Baltimore]]"
---

# Baltimore Vendor Coordination — 2026-10-27

## Notes

- Delivery moved to 2026-10-30.
- Need confirmation of spare optics.
- Dock notification remains required.

## Updated trackable

- [[02 Work Items/Confirm Baltimore equipment shipment]]
