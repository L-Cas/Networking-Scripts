---
type: meeting
date: 2026-10-26
series: "[[05 Meetings/Weekly Team Meeting/Weekly Team Meeting]]"
location:
  - "[[04 Locations/Baltimore]]"
  - "[[04 Locations/DC]]"
---

# Weekly Team Meeting — 2026-10-26

## Raw notes

- Baltimore shipment still has not arrived.
- Cyber wants the new access-switch baseline used for new deployments.
- DC user reported intermittent disconnects.
- Training due next week.
- Several unrelated team updates.

## Trackables created / updated

- [[02 Work Items/Confirm Baltimore equipment shipment]]
- [[02 Work Items/Investigate DC intermittent disconnects]]
- [[02 Work Items/Complete annual training]]

## Existing projects referenced

- [[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]
- [[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]
