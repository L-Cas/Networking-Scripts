---
type: meeting
date: 2026-11-02
series: "[[05 Meetings/Weekly Team Meeting/Weekly Team Meeting]]"
---

# Weekly Team Meeting — 2026-11-02

## Carry Forward

- [[02 Work Items/Confirm Baltimore equipment shipment]] — current status should be reviewed
- [[02 Work Items/Investigate DC intermittent disconnects]] — investigation remains open
- [[02 Work Items/Review campus switch baseline]] — due before meeting

## Agenda

- Baltimore standup
- Campus switch refresh
- Open operational items

## Notes

Start typing here during the meeting.
