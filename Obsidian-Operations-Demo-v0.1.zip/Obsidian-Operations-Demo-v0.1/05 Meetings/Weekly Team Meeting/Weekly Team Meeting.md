---
type: meeting-series
cadence: Weekly
---

# Weekly Team Meeting

This is the permanent meeting-series page.

## Meeting history

- [[05 Meetings/Weekly Team Meeting/2026-10-12 - Weekly Team Meeting]]
- [[05 Meetings/Weekly Team Meeting/2026-10-19 - Weekly Team Meeting]]
- [[05 Meetings/Weekly Team Meeting/2026-10-26 - Weekly Team Meeting]]
- [[05 Meetings/Weekly Team Meeting/2026-11-02 - Weekly Team Meeting]]

## Carry-forward principle

The meeting does not own every task. Trackable work lives independently and points back to the meeting that created or updated it.

## Open items created by this series

- [[02 Work Items/Confirm Baltimore equipment shipment]]
- [[02 Work Items/Review campus switch baseline]]
