---
type: meeting
date: 2026-10-28
series: Cybersecurity Sync
project: "[[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]"
---

# Cybersecurity Sync — 2026-10-28

## Notes

- New access baseline should be used for upcoming deployments.
- Exception review remains blocked.

## Trackables

- [[02 Work Items/Review campus switch baseline]]
- [[02 Work Items/Security hardening exception review]]
