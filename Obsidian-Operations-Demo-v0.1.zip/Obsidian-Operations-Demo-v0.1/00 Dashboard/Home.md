---
type: dashboard
cssclasses:
  - ops-dashboard
---

# Operations Dashboard

> [!nav] Workspace
> [[01 Capture/Scratchpad|✚ Capture]] · [[00 Dashboard/Today|Today]] · [[00 Dashboard/All Work|All Work]] · [[00 Dashboard/Projects|Projects]] · [[00 Dashboard/Locations|Locations]] · [[00 Dashboard/Calendar|Calendar]] · [[97 Reference/System/Vault Guide|Guide]]

> [!daily] Daily Operations
> ![[00 Dashboard/Daily Operations]]

> [!today] Today
> ![[02 Work Items/Work Items.base#Today]]

> [!week] This Week
> ![[02 Work Items/Work Items.base#This Week]]

> [!attention] Needs Attention
> **Overdue**
> ![[02 Work Items/Work Items.base#Overdue]]
>
> **Waiting / Blocked**
> ![[02 Work Items/Work Items.base#Waiting + Blocked]]

> [!projects] Active Projects
> ![[03 Projects/Projects.base#Cards]]

> [!capture] Scratchpad
> ![[01 Capture/Scratchpad#Quick Capture]]

---

**Design rule:** dashboards visualize the system; notes remain the source of truth.
