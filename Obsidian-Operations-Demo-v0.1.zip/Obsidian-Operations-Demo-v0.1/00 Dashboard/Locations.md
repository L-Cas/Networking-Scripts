---
type: dashboard
cssclasses:
  - ops-dashboard
---

# Locations

Locations are **context entities**, not containers for work.

![[04 Locations/Locations.base]]

> [!tip] Principle
> `[[Baltimore]]` describes Baltimore. The dashboard finds anything related to Baltimore from work items, projects, and meetings.
