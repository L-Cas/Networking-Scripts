---
type: dashboard
cssclasses:
  - ops-dashboard
---

# All Work

> [!nav] Views
> Use the tabs inside the embedded Base to switch among **Open**, **Today**, **This Week**, **Overdue**, **Waiting + Blocked**, **No Date**, and **Status Board**.

![[02 Work Items/Work Items.base]]
