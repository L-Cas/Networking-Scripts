---
type: dashboard
cssclasses:
  - ops-dashboard
---

# Calendar

## Work week — demo view

| Monday | Tuesday | Wednesday | Thursday | Friday |
|---|---|---|---|---|
| Weekly planning | DC troubleshooting | Cybersecurity Sync | **Today** — shipment follow-up | Rack power |
| Switch baseline | Vendor prep | Review config | Baltimore review | Project planning |
|  |  |  | Daily operations |  |

## October 2026

| Mon | Tue | Wed | Thu | Fri | Sat | Sun |
|---:|---:|---:|---:|---:|---:|---:|
|  |  |  | 1 | 2 | 3 | 4 |
| 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| 12 | 13 | 14 | 15 | 16 | 17 | 18 |
| 19 | 20 | 21 | 22 | 23 | 24 | 25 |
| 26 | 27 | 28 | **29** | 30 | 31 |  |

> [!note] v0.1 calendar scope
> This page demonstrates the visual direction. The data-driven calendar is intentionally left for plugin testing so the core vault is not dependent on a calendar plugin.
