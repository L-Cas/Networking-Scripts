---
type: operations
cssclasses:
  - ops-dashboard
---

- [ ] Check email
- [ ] Review ticket queue
- [ ] Review calendar / meetings
- [ ] Check operational monitoring
- [ ] Review anything overdue

> [!note] v0.1 reset behavior
> This checklist intentionally stays simple. Re-open this note and uncheck the boxes at the start of the next day. A one-click reset can be added later after the core workflow proves itself.
