---
type: dashboard
cssclasses:
  - ops-dashboard
---

# Projects

> [!nav] Project views
> Use **Cards** for a clean portfolio view, **Active** for a compact list, and **Status Board** for grouped status.

![[03 Projects/Projects.base]]
