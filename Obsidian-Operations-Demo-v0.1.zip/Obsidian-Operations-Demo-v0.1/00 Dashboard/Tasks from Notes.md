---
type: dashboard
cssclasses:
  - ops-dashboard
---

# Tasks from Notes

This page becomes live after installing the **Tasks** community plugin.

## Open tasks from anywhere

```tasks
not done
path does not include 99 Archive
sort by due
sort by priority
```

## Due or overdue

```tasks
not done
due before tomorrow
path does not include 99 Archive
sort by due
```

## No due date

```tasks
not done
no due date
path does not include 99 Archive
sort by path
```
