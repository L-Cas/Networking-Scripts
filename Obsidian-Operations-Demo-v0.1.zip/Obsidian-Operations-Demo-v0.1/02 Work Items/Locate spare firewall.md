---
type: work-item
status: Open
priority: Normal
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
location: "[[04 Locations/Baltimore]]"
source: "[[01 Capture/Inbox/2026-10-29 - Hallway Requests]]"
created: 2026-10-29
---

# Locate spare firewall

No due date. This is still active work, not a backlog item.
