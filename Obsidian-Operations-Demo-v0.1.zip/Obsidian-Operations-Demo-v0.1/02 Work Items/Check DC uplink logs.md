---
type: work-item
status: Open
priority: Normal
location: "[[04 Locations/DC]]"
source: "[[02 Work Items/Investigate DC intermittent disconnects]]"
created: 2026-10-29
---

# Check DC uplink logs

Promoted from a checkbox because it needs its own observations.

## Notes

No deadline assigned yet.
