---
type: work-item
status: Open
priority: Normal
date: 2026-10-30
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
location: "[[04 Locations/Baltimore]]"
created: 2026-10-28
---

# Verify Baltimore rack power

Confirm rack power before equipment installation.
