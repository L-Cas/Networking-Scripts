---
type: work-item
status: Complete
priority: Normal
date: 2026-10-27
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
location: "[[04 Locations/Baltimore]]"
completed: 2026-10-27
created: 2026-10-20
---

# Update inventory after Baltimore install

Completed sample item. It remains in Work Items for the demo so you can test the **Complete** group before manually archiving it.
