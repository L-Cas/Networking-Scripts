---
type: work-item
status: Open
priority: Normal
date: 2026-11-03
project: "[[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]"
created: 2026-10-29
---

# Confirm maintenance window

Coordinate the next fictional maintenance window.
