---
type: work-item
status: In Progress
priority: High
date: 2026-10-28
location: "[[04 Locations/DC]]"
source: "[[01 Capture/Inbox/2026-10-29 - Hallway Requests]]"
created: 2026-10-27
---

# Investigate DC intermittent disconnects

Started as a hallway request and grew into multi-step investigation.

## Investigation

- [x] Identify affected workstation
- [x] Check access port counters
- [ ] Review uplink logs
- [ ] Validate cabling
- [ ] Determine whether switch replacement is justified

## Child work

- [[02 Work Items/Check DC uplink logs]]
- [[02 Work Items/Replace failed access switch]]

> [!note]
> This work item has several children but is intentionally **not yet a Project**.
