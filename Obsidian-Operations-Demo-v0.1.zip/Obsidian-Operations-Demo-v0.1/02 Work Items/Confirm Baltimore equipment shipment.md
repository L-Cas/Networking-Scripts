---
type: work-item
status: Waiting
priority: High
date: 2026-10-29
time: "14:00"
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
location: "[[04 Locations/Baltimore]]"
source: "[[05 Meetings/Weekly Team Meeting/2026-10-26 - Weekly Team Meeting]]"
created: 2026-10-26
---

# Confirm Baltimore equipment shipment

Waiting on Vendor A to confirm arrival and whether spare optics are included.

## History

- 2026-10-26 — Created from weekly team meeting.
- 2026-10-27 — Vendor revised ETA to 2026-10-30.
- 2026-10-29 — Follow-up scheduled for 2:00 PM.

## Next

- [ ] Confirm shipment contents
- [ ] Notify project stakeholders after delivery
