---
type: work-item
status: Open
priority: High
location: "[[04 Locations/DC]]"
source: "[[02 Work Items/Investigate DC intermittent disconnects]]"
created: 2026-10-29
---

# Replace failed access switch

Potential follow-on work if the investigation proves hardware failure.

This demonstrates a work item that could later become a mini-project without being forced into one today.
