---
type: work-item
status: Open
priority: Normal
date: 2026-11-06
source: "[[01 Capture/Inbox/2026-10-29 - Hallway Requests]]"
created: 2026-10-29
---

# Complete annual training

Administrative work item with no project or location.
