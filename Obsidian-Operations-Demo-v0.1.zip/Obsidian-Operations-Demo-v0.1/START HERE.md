---
type: system
cssclasses:
  - ops-dashboard
---

# Obsidian Operations Demo v0.1

This is a **fictional, sanitized demo vault** built to test the workflow architecture before adapting it to real work.

> [!important] Demo goal
> Prove that capture, work items, projects, locations, meetings, dashboards, and archives can feel like one clean workspace without making the Markdown underneath fragile.

## First launch

1. Open this folder as an Obsidian vault.
2. Go to **Settings → Appearance → CSS snippets** and enable `operations-dashboard`.
3. Make sure the **Bases** core plugin is enabled.
4. Open [[00 Dashboard/Home|Home]].
5. Read [[97 Reference/System/Vault Guide|Vault Guide]].
6. Review [[97 Reference/System/Plugin Registry|Plugin Registry]] before installing community plugins.

## What works without community plugins

- Markdown notes and properties
- Links and backlinks
- Location cards
- Project folders
- Obsidian Bases views
- Dashboard CSS
- Sample workflows
- Manual archive structure

## What improves after optional plugins are installed

- Quick capture / note creation: **QuickAdd**
- Inline task aggregation: **Tasks**
- Property controls and buttons: **Meta Bind**
- App-like toolbars: **Note Toolbar**
- Automatic launch to Home: **Homepage**
- Enhanced vault search: **Omnisearch**

## Demo date

The sample content is centered around **October 29, 2026** so Today / Overdue / This Week views contain meaningful data immediately.

## Safety

Everything in this vault is fictional. Do not paste real credentials, internal configs, sensitive diagrams, proprietary documentation, or production data into this demo while evaluating it.
