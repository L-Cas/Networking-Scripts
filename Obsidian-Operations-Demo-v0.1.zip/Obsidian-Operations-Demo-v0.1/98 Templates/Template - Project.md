---
type: project
status: Planning
progress: 0
target:
locations:
---

# Project

## Outcome

## Current state

## Next actions

## Project notes

## Meetings

## Log
