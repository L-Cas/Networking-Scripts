"""Experimental offline port of the Huge Normal PlateUp graph. No network access."""
from room_generator import Generator, first_graph_seed, signed, DIR, TYPES, compare
from seed_probe import UnityRandomCandidate, seed_hash, context_seed, LAYOUT_CONTEXT
import json,argparse
from pathlib import Path
from collections import defaultdict
import struct
SEED_ALPHABET = "abcdefghijklmnopqrstuvwxyz123456789"

def normalize_seed(seed):
 if not seed.isascii():
  raise ValueError("Seed must have 1–8 ASCII letters a-z or digits 1–9 (no zero)")
 seed = seed.lower()
 if not 1 <= len(seed) <= 8 or any(c not in SEED_ALPHABET for c in seed):
  raise ValueError("Seed must have 1–8 letters a-z or digits 1–9 (no zero)")
 return seed

class Failure(Exception):pass

def plus(a,b):return a[0]+b[0],a[1]+b[1]
def edge(a,b):return tuple(sorted((a,b)))
class Graph(Generator):
 def __init__(self,graph_seed):
  super().__init__(graph_seed);self.draws=0
 def integer(self,lo,hi):
  if lo!=hi:self.draws+=1
  return super().integer(lo,hi)
 def random_key(self):
  self.draws+=1
  return self.rng.next_uint()&0x7fffff
 def room(self,p):return self.tiles.get(p,(0,0))
 def flat(self,p):return sum(self.room(plus(p,d))[0]==self.room(p)[0] for d in DIR)==3
 def feature_pass(self):
  self.new_id() # front door copy
  candidates=[p for p,r in self.tiles.items() if p[1]==-6 and r[1]==2]
  if not candidates:raise Failure('no entrance')
  front=candidates[self.integer(0,len(candidates))];front=(front,plus(front,(0,-1)),3)
  self.new_id() # find all features copy
  allf=sorted([(p,plus(p,d),1) for p,r in self.tiles.items() for d in DIR if self.room(plus(p,d))[0]!=r[0]],key=lambda f:f[0][0]*1000+f[1][1])
  self.new_id() # filter free space copy
  free=[f for f in allf if self.flat(f[0]) and self.flat(f[1])]
  self.new_id() # one per pair copy
  room_ids=list({r[0] for r in self.tiles.values()});pairs={tuple(sorted((a,b))) for a in room_ids for b in room_ids if a!=b}
  doors=[]
  for f in sorted(free,key=lambda f:self.random_key()):
   pair=tuple(sorted((self.room(f[0])[0],self.room(f[1])[0])))
   if pair in pairs:pairs.remove(pair);doors.append(f)
  self.new_id() # filter room copy
  hatch=[f for f in allf if {self.room(f[0])[1],self.room(f[1])[1]}=={2,3}]
  def adjacent_pair():
   self.new_id()
   fs=sorted(hatch,key=lambda f:self.random_key());result=hatch
   for a,b,t in fs:
    for c,e,u in hatch:
     if any((c==plus(a,d) and e==plus(b,d)) or (e==plus(a,d) and c==plus(b,d)) for d in DIR):
      result=[(a,b,t),(c,e,u)];break
    else:continue
    break
   self.new_id() # switch features
   return [(a,b,2) for a,b,t in result]
  h2=adjacent_pair() # 78945
  h1=adjacent_pair() # 75413
  self.new_id() # append features
  features=[front];seen={edge(*front[:2])}
  for fs in [h1,doors,h2]:
   # game AddRange enumerates list and sees already appended features
   for f in fs:
    k=edge(*f[:2])
    if k not in seen:features.append(f);seen.add(k)
  self.new_id() # accessibility
  ids={r[0] for r in self.tiles.values()};reachable={self.room(front[0])[0]};adj=defaultdict(set)
  for a,b,t in features:
   if t in (1,3):adj[self.room(a)[0]].add(self.room(b)[0]);adj[self.room(b)[0]].add(self.room(a)[0])
  todo=list(reachable)
  while todo:
   for q in adj[todo.pop()]:
    if q not in reachable:reachable.add(q);todo.append(q)
  if not ids<=reachable:raise Failure('inaccessible room')
  for rid in ids:
   group={p for p,r in self.tiles.items() if r[0]==rid};todo=[next(iter(group))];seen={todo[0]}
   while todo:
    p=todo.pop()
    for d in DIR:
     q=plus(p,d)
     if q in group and q not in seen:seen.add(q);todo.append(q)
   if seen!=group or len(group)==1:raise Failure('disjoint room')
  self.new_id() # require features
  if sum(f[2]==2 for f in features)<2:raise Failure('not enough hatches')
  self.new_id() # output
  return features
 def one_pass(self):
  self.rooms();return self.feature_pass()
 def decorate_dining(self,features):
  nearby=DIR+((1,1),(-1,1),(1,-1),(-1,-1))
  feature_tiles={p for f in features for p in f[:2]}
  for rid,typ in dict.fromkeys(self.tiles.values()):
   if typ!=2:continue
   room_tiles=[p for p,r in self.tiles.items() if r[0]==rid]
   for attempt in range(5):
    occupied=set();tables=[]
    for p in sorted(room_tiles,key=lambda p:self.random_key()):
     if not all(self.room(plus(p,d))[0]==rid for d in nearby):continue
     if any(plus(p,d) in occupied or plus(p,d) in feature_tiles for d in DIR):continue
     tables.append(p)
     if len(tables)==4:break
     occupied.update(plus(p,d) for d in nearby)
    # Game decrements counter before each try, so success on the fifth still fails.
    if len(tables)==4:break
   if len(tables)!=4 or attempt==4:raise Failure('cannot place four dining tables')
   self.tables=tables
 def decorate_kitchen(self,features):
  nearby=DIR+((1,1),(-1,1),(1,-1),(-1,-1))
  feature_tiles={p for f in features for p in f[:2]}
  hatch_tiles={p for f in features if f[2]==2 for p in f[:2]}
  used=set(self.tables);appliances=[]
  def open_space(p):return all(self.room(plus(p,d))[0]==self.room(p)[0] for d in nearby)
  def rotation(p):
   for d in DIR:
    if self.room(plus(p,d))[0]!=self.room(p)[0]:return {(0,1):0,(0,-1):180,(-1,0):270,(1,0):90}[d]
   return 0
  for rid,typ in dict.fromkeys(self.tiles.values()):
   if typ!=3:continue
   room_tiles=[p for p,r in self.tiles.items() if r[0]==rid]
   for p in room_tiles:
    if p in hatch_tiles:appliances.append((p,'Counter',rotation(p)));used.add(p)
   available=[p for p in room_tiles if p not in used]
   if not available:raise Failure('no free kitchen tile')
   p=available[self.integer(0,len(available))]
   def next_tile(p):
    for q in [plus(p,d) for d in DIR if self.room(plus(p,d))[0]==self.room(p)[0]]+room_tiles:
     if any(open_space(plus(q,d)) for d in DIR) and q not in feature_tiles and self.flat(q) and q not in used:
      used.add(q);return q
    raise Failure('cannot place kitchen appliance')
   p=next_tile(p)
   for name in ['Counter','Starter Sink','Starter Bin']+['Reservation']*6+['Blueprint Cabinet','Counter','Counter','Counter']:
    if name!='Reservation':appliances.append((p,name,rotation(p)))
    used.add(p);p=next_tile(p)
  self.kitchen_appliances=appliances
 def build(self):
  self.one_pass();first=self.draws;features=self.one_pass();self.decorate_dining(features);self.decorate_kitchen(features);return first,features

def as_layout(seed,attempt,g,features):
 return {'seed':seed.lower(),'settingSlug':'normal','settingName':'Normal','layoutProfileId':154938708,'mapSizeName':'Huge','width':16,'height':12,'graphSeed':signed(first_graph_seed(seed)+attempt),'attempt':attempt,'status':'offline candidate; benchmark-validated Huge Normal profile','tableApplianceId':209074140,'tiles':[{'x':x,'y':y,'roomId':r[0],'roomType':TYPES[r[1]]} for (x,y),r in g.tiles.items()],'appliances':[{'x':p[0],'y':p[1],'applianceName':name,'applianceId':{'Dining Table':209074140,'Counter':-1248669347,'Starter Sink':-266993023,'Starter Bin':481495292,'Blueprint Cabinet':-571205127}[name],'rotationDegrees':rot} for p,name,rot in [(p,'Dining Table',0) for p in g.tables]+g.kitchen_appliances],'features':[{'tile1X':a[0],'tile1Y':a[1],'tile2X':b[0],'tile2Y':b[1],'type':{1:'Door',2:'Hatch',3:'FrontDoor'}[t]} for a,b,t in features]}

def feature_diff(f,ref):
 a={(*edge((x['tile1X'],x['tile1Y']),(x['tile2X'],x['tile2Y'])),x['type']) for x in f};b={(*edge((x['tile1X'],x['tile1Y']),(x['tile2X'],x['tile2Y'])),x['type']) for x in ref};return len(a^b)
def is_huge(seed):
 return UnityRandomCandidate(context_seed(seed_hash(normalize_seed(seed)),LAYOUT_CONTEXT)).range_int(0,8) in (3,7)

def generate(seed):
 seed=normalize_seed(seed)
 if not is_huge(seed):return None
 base=first_graph_seed(seed)
 for i in range(100):
  g=Graph(signed(base+i))
  try:offset,fs=g.build()
  except Failure:continue
  return as_layout(seed,i,g,fs)
 return None

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('seeds',nargs='*',default=['oxford','rgzs','pizza']);p.add_argument('--output',default='generated.json');a=p.parse_args();out=[]
 for s in a.seeds:
  try: normalize_seed(s)
  except ValueError as e: p.error(f"{s}: {e}")
 for s in a.seeds:
  d=generate(s)
  if d is None:print(s,'not Huge or no successful candidate');continue
  print(s,'generated at retry',d['attempt']);out.append(d)
 Path(a.output).write_text(json.dumps(out,indent=2))
