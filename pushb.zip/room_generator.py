"""Experimental Huge room generation port; features and retry acceptance not implemented."""
from seed_probe import UnityRandomCandidate, seed_hash, context_seed, MAP_CONTEXT, signed
from collections import deque
import json, argparse
from pathlib import Path
DIR=((0,1),(0,-1),(-1,0),(1,0))
TYPES={1:'Unassigned',2:'Dining',3:'Kitchen'}
class Generator:
 def __init__(self,graph_seed): self.rng=UnityRandomCandidate(graph_seed); self.tiles={}
 def integer(self,lo,hi):return self.rng.range_int(lo,hi)
 def new_id(self):return self.integer(-2**31,2**31-1)
 def adjacent(self,room):
  found={}
  for (x,y),(rid,typ) in self.tiles.items():
   if rid!=room[0]:continue
   for dx,dy in DIR:
    other=self.tiles.get((x+dx,y+dy))
    if other and other[0]!=rid:found.setdefault(other,None)
  return list(found)
 def replace(self,old,new):
  for pos,r in self.tiles.items():
   if r[0]==old[0]:self.tiles[pos]=new
 def join(self,x,y,n,typ):
  old=self.tiles[(x,y)];new=(old[0],typ);self.replace(old,new)
  for _ in range(n):
   options=[r for r in self.adjacent(new) if r[1]==1]
   if not options:return
   self.replace(options[self.integer(0,len(options))],new)
 def split(self,axis,index):
  out={}
  for pos,r in self.tiles.items():
   p=list(pos)
   if p[axis]>=index:p[axis]+=1
   out[tuple(p)]=r
   if pos[axis]==index:out[pos]=r
  self.tiles=out
 def rooms(self):
  self.new_id() # RoomGrid blueprint
  self.tiles={(x,y):(self.new_id(),1) for x in range(6) for y in range(4)}
  self.new_id();self.join(0,0,5,2)
  self.new_id();self.join(3,2,8,3)
  self.new_id()
  for x in range(5,-1,-1):self.split(0,x)
  for y in range(3,-1,-1):self.split(1,y)
  for i in range(4):self.split(1,self.integer(0,8+i))
  for i in range(4):self.split(0,self.integer(0,12+i))
  self.new_id()
  for room in list(dict.fromkeys(self.tiles.values())):
   for other in self.adjacent(room):
    if other[1]==room[1]:self.replace(other,room)
  self.new_id()
  self.tiles={(x-8,y-6):r for (x,y),r in self.tiles.items()}
  return self.tiles

def first_graph_seed(seed):
 return UnityRandomCandidate(context_seed(seed_hash(seed.lower()),MAP_CONTEXT)).range_int(-2**31,2**31-1)
def compare(tiles,ref):
 target={(t['x'],t['y']):t['roomType'] for t in ref['tiles']}
 return sum(TYPES[r[1]]!=target.get(p) for p,r in tiles.items())+len(target.keys()-tiles.keys())
def candidate(seed,attempt):
 graph=signed(first_graph_seed(seed)+attempt);g=Generator(graph);tiles=g.rooms()
 return {'seed':seed.lower(),'settingSlug':'normal','layoutProfileId':154938708,'mapSizeName':'Huge','width':16,'height':12,'graphSeed':graph,'attempt':attempt,'status':'experimental room stage only; not a validated vanilla layout','tiles':[{'x':x,'y':y,'roomId':r[0],'roomType':TYPES[r[1]]} for (x,y),r in tiles.items()]}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('seeds',nargs='*',default=['oxford','rgzs','pizza']);p.add_argument('--attempts',type=int,default=100);p.add_argument('--output',default='room_candidates.json');a=p.parse_args();refs={r['seed']:r for r in json.loads(Path(__file__).with_name('benchmarks.json').read_text())};out=[]
 for seed in a.seeds:
  ref=refs.get(seed.lower()); best=None
  for i in range(a.attempts if ref else 1):
   graph=signed(first_graph_seed(seed)+i);g=Generator(graph);tiles=g.rooms();diff=compare(tiles,ref) if ref else None
   if best is None or diff<best[0]:best=(diff,i)
   if diff==0:break
  print(seed,'closest room type differences:',best[0],'attempt:',best[1]);out.append(candidate(seed,best[1]))
 Path(a.output).write_text(json.dumps(out,indent=2))
