"""Offline Windows-friendly launcher using Python's standard Tkinter."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from datetime import datetime
import queue,threading,webbrowser
from hunt import scan,save_results,HERE
from scoring import DEFAULT_WEIGHTS,normalize_weights
from rescore import rescore
class App:
    def __init__(self,root):
        self.root=root;root.title('PlateUp Seed Hunter — Offline Beta 0.2');root.geometry('700x555');root.minsize(650,540)
        self.count=tk.StringVar(value='1000');self.hatches=tk.StringVar(value='4');self.limit=tk.StringVar(value='100');self.better=tk.BooleanVar();self.status=tk.StringVar(value='Ready. No internet or game required.');self.stop=threading.Event();self.events=queue.Queue();self.latest=None
        self.weights=[tk.StringVar(value=str(w)) for w in DEFAULT_WEIGHTS]
        f=ttk.Frame(root,padding=22);f.pack(fill='both',expand=True)
        ttk.Label(f,text='PlateUp Seed Hunter',font=('Segoe UI',22,'bold')).pack(anchor='w');ttk.Label(f,text='Huge · Normal · Overtime scoring v0.2 · Offline').pack(anchor='w',pady=(0,14))
        grid=ttk.Frame(f);grid.pack(fill='x');grid.columnconfigure(1,weight=1)
        for i,(label,var) in enumerate([('Huge seeds to test',self.count),('Minimum consecutive kitchen–dining hatches',self.hatches),('Maximum saved results',self.limit)]):
            ttk.Label(grid,text=label).grid(row=i,column=0,sticky='w',pady=4);ttk.Entry(grid,textvariable=var,width=12).grid(row=i,column=1,sticky='e',padx=4)
        wbox=ttk.LabelFrame(f,text='Scoring weights (automatically normalized)',padding=8);wbox.pack(fill='x',pady=9)
        for i,(label,var) in enumerate(zip(('Openness','Secondary space','Windows','Connectivity'),self.weights)):
            wbox.columnconfigure(i,weight=1);ttk.Label(wbox,text=label).grid(row=0,column=i);ttk.Entry(wbox,textvariable=var,width=8).grid(row=1,column=i,pady=3)
        ttk.Button(wbox,text='Reset weights',command=lambda:[v.set(str(w)) for v,w in zip(self.weights,DEFAULT_WEIGHTS)]).grid(row=2,column=0,columnspan=4,pady=3)
        ttk.Checkbutton(f,text='Only show seeds with a score higher than OXFORD (new formula)',variable=self.better).pack(anchor='w',pady=5)
        self.progress=ttk.Progressbar(f,mode='indeterminate');self.progress.pack(fill='x',pady=5)
        ttk.Label(f,textvariable=self.status,wraplength=630).pack(anchor='w',pady=5)
        btn=ttk.Frame(f);btn.pack(fill='x',pady=7);self.run=ttk.Button(btn,text='Start offline hunt',command=self.start);self.run.pack(side='left');self.cancel=ttk.Button(btn,text='Stop',command=self.stop.set,state='disabled');self.cancel.pack(side='left',padx=6);self.imp=ttk.Button(btn,text='Rescore saved JSON',command=self.import_json);self.imp.pack(side='left',padx=6);self.open=ttk.Button(btn,text='Open results',command=self.open_latest,state='disabled');self.open.pack(side='right')
        ttk.Button(f,text='Open five-seed comparison',command=lambda:webbrowser.open((HERE/'comparison'/'Hunt_Results.html').as_uri())).pack(anchor='w',pady=5)
        ttk.Label(f,text='Rescore saved JSON keeps all imported maps for comparison. Gallery filters and weights can be adjusted without another hunt.',wraplength=630).pack(anchor='w',pady=4);root.after(100,self.poll)
    def get_weights(self):
        w=tuple(float(v.get()) for v in self.weights);normalize_weights(w);return w
    def start(self):
        try:
            n,h,l=int(self.count.get()),int(self.hatches.get()),int(self.limit.get());w=self.get_weights();assert 1<=n<=100000 and 0<=h<=16 and 1<=l<=1000
        except (ValueError,AssertionError):messagebox.showerror('Invalid filters','Enter 1–100,000 seeds, 0–16 hatches, 1–1,000 results and nonnegative weights (one positive).');return
        better=self.better.get();self.launch(lambda:scan(n,h,l,progress=lambda s:self.events.put(('progress',s)),stop=self.stop.is_set,better=better,weights=w),True)
    def import_json(self):
        try:w=self.get_weights()
        except ValueError as e:messagebox.showerror('Invalid weights',str(e));return
        paths=filedialog.askopenfilenames(title='Select saved hunt_results.json files',filetypes=[('JSON layouts','*.json')])
        if paths:self.launch(lambda:rescore(paths,w),False)
    def launch(self,job,cancellable):
        self.stop.clear();self.run.configure(state='disabled');self.imp.configure(state='disabled');self.cancel.configure(state='normal' if cancellable else 'disabled');self.progress.start(12);self.status.set('Working offline…')
        def worker():
            try:
                rows,stats=job();folder=HERE/'results'/datetime.now().strftime('%Y%m%d_%H%M%S_%f');path=save_results(rows,stats,folder);self.events.put(('done',(path,stats)))
            except Exception as e:self.events.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def open_latest(self):
        if self.latest:webbrowser.open(self.latest.resolve().as_uri())
    def poll(self):
        try:
            while True:
                event,value=self.events.get_nowait()
                if event=='progress':self.status.set(value)
                else:
                    self.progress.stop();self.run.configure(state='normal');self.imp.configure(state='normal');self.cancel.configure(state='disabled')
                    if event=='error':self.status.set('Error: '+value)
                    else:
                        self.latest,stats=value;self.open.configure(state='normal');self.status.set(f"{'Stopped' if stats['cancelled'] else 'Complete'}: {stats['tested']:,} tested/imported, {stats['matches']:,} unique matches. Results saved.");self.open_latest()
        except queue.Empty:pass
        self.root.after(100,self.poll)
if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
