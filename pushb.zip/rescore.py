"""Re-rank saved layouts without generating or downloading anything."""
import argparse,json,webbrowser
from pathlib import Path
from hunt import save_results,signature,HERE
from scoring import metrics,DEFAULT_WEIGHTS,normalize_weights
from generator import generate

def rescore(paths,weights=DEFAULT_WEIGHTS,hatches=0,better=False,limit=None):
    normalize_weights(weights);rows=[];seen=set();count=dupes=0;benchmark=metrics(generate('oxford'),weights)['score']
    for p in paths:
        data=json.loads(Path(p).read_text(encoding='utf-8-sig'))
        if isinstance(data,dict):data=data.get('results',[data])
        if not isinstance(data,list):raise ValueError(f'Not a layout list: {p}')
        for item in data:
            d=item.get('layout',item);count+=1
            if not {'seed','tiles','features','width','height'}<=d.keys():raise ValueError(f'Missing layout fields in {p}')
            m=metrics(d,weights)
            if m['longest']<hatches or (better and m['score']<=benchmark):continue
            sig=signature(d)
            if sig in seen:dupes+=1;continue
            seen.add(sig);rows.append((m,d))
    rows.sort(key=lambda row:(-row[0]['score'],row[1]['seed']))
    results=rows if limit is None else rows[:limit]
    return results,dict(tested=count,raw=count,failures=0,duplicates=dupes,matches=len(rows),returned=len(results),seconds=0,cancelled=False,hatches=hatches,better=better,benchmark=benchmark,weights=list(weights),scoring_version='0.2',source='Imported layouts')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('files',nargs='+');p.add_argument('--weights',type=float,nargs=4,default=DEFAULT_WEIGHTS);p.add_argument('--hatches',type=int,default=0);p.add_argument('--output-dir',default=str(HERE/'rescored'));p.add_argument('--open',action='store_true');a=p.parse_args()
    rows,stats=rescore(a.files,a.weights,a.hatches);out=save_results(rows,stats,a.output_dir);print(out)
    if a.open:webbrowser.open(out.resolve().as_uri())
