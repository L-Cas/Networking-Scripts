"""Offline Huge/Normal seed hunt. Standard-library Python only."""
import argparse, json, random, time, html, webbrowser
from pathlib import Path
from collections import defaultdict
from generator import generate,is_huge,SEED_ALPHABET

HERE=Path(__file__).resolve().parent

from scoring import metrics, rectangle, DEFAULT_WEIGHTS, normalize_weights

def signature(d):
    # Ignore numeric room IDs, appliance positions and seed names; preserve the actual floor plan.
    tiles={(t['x'],t['y']):(t['roomType'],t['roomId']) for t in d['tiles']};ids={};out=[]
    for p,r in sorted(tiles.items()):
        ids.setdefault(r,len(ids));out.append((p,r[0],ids[r]))
    fs=tuple(sorted((tuple(sorted(((f['tile1X'],f['tile1Y']),(f['tile2X'],f['tile2Y'])))),f['type']) for f in d['features']))
    return tuple(out),fs

def scan(count=1000,hatches=4,limit=100,seed=None,progress=print,stop=lambda:False,better=False,weights=DEFAULT_WEIGHTS):
    rng=random.Random(seed);seen=set();matches=[];tested=raw=failures=duplicates=0;start=time.monotonic();sigs=set();benchmark=metrics(generate('oxford'),weights)['score']
    while tested<count and not stop():
        s=''.join(rng.choices(SEED_ALPHABET,k=8));raw+=1
        if s in seen:continue
        seen.add(s)
        if not is_huge(s):continue
        tested+=1;d=generate(s)
        if d is None:failures+=1
        else:
            m=metrics(d,weights)
            if m['longest']>=hatches and (not better or m['score']>benchmark):
                sig=signature(d)
                if sig in sigs:duplicates+=1
                else:sigs.add(sig);matches.append((m,d))
        if tested%25==0 or tested==count:progress(f'{tested:,}/{count:,} Huge seeds | {len(matches):,} unique matches | {time.monotonic()-start:.1f}s')
    matches.sort(key=lambda x:(-x[0]['score'],-x[0]['longest'],x[1]['seed']))
    return matches[:limit],dict(tested=tested,raw=raw,failures=failures,duplicates=duplicates,matches=len(matches),returned=min(limit,len(matches)),seconds=round(time.monotonic()-start,2),cancelled=tested<count,hatches=hatches,better=better,benchmark=benchmark,weights=list(weights), scoring_version="0.2")

def save_results(results,stats,folder=HERE):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    layouts=[d for m,d in results];out=folder/'hunt_results.json';out.write_text(json.dumps(layouts,separators=(',',':')),encoding='utf-8')
    stats=dict(stats,benchmark_metrics=metrics(generate('oxford'),stats.get('weights',DEFAULT_WEIGHTS)))
    data=[dict(layout=d,metrics=m) for m,d in results];template=(HERE/'gallery_template.html').read_text(encoding='utf-8')
    gallery=folder/'Hunt_Results.html';gallery.write_text(template.replace('/*__DATA__*/null',json.dumps({'results':data,'stats':stats},separators=(',',':')).replace('<','\\u003c')),encoding='utf-8')
    return gallery

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--count',type=int,default=1000,help='number of Huge seeds to attempt (non-Huge strings are prefiltered)');p.add_argument('--hatches',type=int,default=4);p.add_argument('--limit',type=int,default=100);p.add_argument('--random-seed',type=int);p.add_argument('--better-than-oxford',action='store_true');p.add_argument('--output-dir',default=str(HERE));p.add_argument('--open',action='store_true');p.add_argument('--weights',type=float,nargs=4,default=DEFAULT_WEIGHTS,metavar=('OPEN','GRAY','WINDOW','CONNECT'));a=p.parse_args()
    try:normalize_weights(a.weights)
    except ValueError as e:p.error(str(e))
    if a.count<1 or a.limit<1 or a.hatches<0:p.error('Count/limit must be positive and hatches nonnegative')
    results,stats=scan(a.count,a.hatches,a.limit,a.random_seed,better=a.better_than_oxford,weights=a.weights);gallery=save_results(results,stats,a.output_dir);print(json.dumps(stats,indent=2));print('Gallery:',gallery)
    for m,d in results[:10]:print(d['seed'].upper(),f"score {m['score']:.2f}",f"hatches {m['longest']}",f"rectangles {m['krect']}+{m['drect']}")
    if a.open:webbrowser.open(gallery.resolve().as_uri())
