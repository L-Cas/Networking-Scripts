"""Regression tests for genuine generated output, not benchmark self-comparison."""
import json,unittest
from pathlib import Path
from generator import generate,is_huge,SEED_ALPHABET
from validate_layout import compare
from hunt import metrics,scan,signature
ROOT=Path(__file__).parent
class Tests(unittest.TestCase):
    def test_three_benchmarks(self):
        refs=json.loads((ROOT/'benchmarks.json').read_text())
        for ref in refs:
            with self.subTest(seed=ref['seed']):
                d=generate(ref['seed']); self.assertIsNotNone(d)
                self.assertEqual(compare(ref,d),dict(dimensions_match=True,profile_match=True,tile_type_differences=0,room_partition_differences=0,feature_differences=0))
                self.assertEqual({(t['x'],t['y']):t['roomId'] for t in d['tiles']},{(t['x'],t['y']):t['roomId'] for t in ref['tiles']})
                self.assertEqual(d['appliances'],ref['appliances'])
    def test_metrics(self):
        for s,expected in [('oxford',(4,80,60)),('rgzs',(2,63,63)),('pizza',(4,54,36))]:
            m=metrics(generate(s));self.assertEqual((m['longest'],m['krect'],m['drect']),expected)
    def test_determinism(self):
        self.assertEqual(generate('hr3ey37n'),generate('HR3EY37N'))
        self.assertEqual(generate('hr3ey37n'),generate('hr3ey37n'))
    def test_seed_input(self):
        for invalid in ("qgiz60l8", "0", "", "abc-123", "abcdefghi", "é"):
            with self.subTest(seed=invalid):
                with self.assertRaises(ValueError): generate(invalid)
                with self.assertRaises(ValueError): is_huge(invalid)
        for seed in ("HR3EY37N", "1J3HY9N8"):
            self.assertIsNotNone(generate(seed))
    def test_small_hunt(self):
        rows,stats=scan(50,4,100,381,progress=lambda _:None)
        self.assertEqual(stats['tested'],50);self.assertEqual(stats['failures'],0)
        self.assertTrue(rows);self.assertTrue(all(m['longest']>=4 for m,d in rows))
        self.assertTrue(all(len(d['seed'])==8 and set(d['seed'])<=set(SEED_ALPHABET) for m,d in rows))
        self.assertEqual(len({signature(d) for m,d in rows}),len(rows))
        self.assertEqual([m['score'] for m,d in rows],sorted((m['score'] for m,d in rows),reverse=True))
if __name__=='__main__':unittest.main(verbosity=2)
