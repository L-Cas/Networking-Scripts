"""Geometry-only overtime scoring. No generator or network dependency."""
from collections import defaultdict, deque
import math

DEFAULT_WEIGHTS=(30,25,30,15)
CATEGORIES=('openness','secondary','windows','connectivity')

def normalize_weights(weights=DEFAULT_WEIGHTS):
    w=tuple(float(x) for x in weights)
    if len(w)!=4 or any(not math.isfinite(x) or x<0 for x in w) or sum(w)<=0:raise ValueError('Provide four nonnegative finite weights, at least one positive.')
    return tuple(x/sum(w) for x in w)

def rectangle(positions,min_width=1):
    if not positions:return 0
    xs=range(min(x for x,y in positions),max(x for x,y in positions)+1)
    ys=range(min(y for x,y in positions),max(y for x,y in positions)+1)
    heights=[0]*len(xs); best=0
    for y in ys:
        for i,x in enumerate(xs):heights[i]=heights[i]+1 if (x,y) in positions else 0
        stack=[]
        for i,h in enumerate(heights+[0]):
            while stack and heights[stack[-1]]>h:
                height=heights[stack.pop()]; width=i-(stack[-1]+1 if stack else 0)
                if min(height,width)>=min_width:best=max(best,height*width)
            stack.append(i)
    return best

def square_coverage(positions,n):
    # Every tile belonging to at least one n-by-n open square in this room.
    covered=set()
    for x,y in positions:
        square={(x+i,y+j) for i in range(n) for j in range(n)}
        if square<=positions:covered.update(square)
    return covered

def components(values):
    result=[]
    for v in sorted(values):
        if result and v==result[-1][-1]+1:result[-1].append(v)
        else:result.append([v])
    return result

def metrics(d,weights=DEFAULT_WEIGHTS):
    tiles={(t['x'],t['y']):(t['roomType'],t['roomId']) for t in d['tiles']}; groups=defaultdict(set)
    for p,r in tiles.items():groups[r].add(p)
    area=d['width']*d['height']; den=max(1,area)
    main_rooms={r for r in groups if r[0] in ('Kitchen','Dining')}
    secondary_rooms=set(groups)-main_rooms
    graph=defaultdict(set); lines=defaultdict(lambda:{'hatch':set(),'door':set()})
    hatches=doors=0;seen=set()
    for f in d['features']:
        a=(f['tile1X'],f['tile1Y']);b=(f['tile2X'],f['tile2Y']);ra=tiles.get(a);rb=tiles.get(b);typ=f['type']
        edge=(tuple(sorted((a,b))),typ)
        if edge in seen:continue
        seen.add(edge)
        if not ra or not rb or ra==rb or abs(a[0]-b[0])+abs(a[1]-b[1])!=1:continue
        if typ=='Door':graph[ra].add(rb);graph[rb].add(ra)
        if ra[0]=='Dining':a,b,ra,rb=b,a,rb,ra
        if ra[0]!='Kitchen' or rb[0]!='Dining' or typ not in ('Hatch','Door'):continue
        dx=b[0]-a[0];dy=b[1]-a[1]
        lines[(ra,rb,dx,dy,a[0] if dx else a[1])][typ.lower()].add(a[1] if dx else a[0])
        if typ=='Hatch':hatches+=1
        else:doors+=1
    def footprints(key,values):
        ra,rb,dx,dy,fixed=key; k=set();di=set()
        for v in values:
            for t in (v-1,v,v+1):
                a=(fixed,t) if dx else (t,fixed);b=(a[0]+dx,a[1]+dy)
                if tiles.get(a)==ra:k.add(a)
                if tiles.get(b)==rb:di.add(b)
        return k,di
    kh=set();dh=set();ka_all=set();da_all=set();longest=0;opening_run=0;hatch_groups=0;best_flow=0;best_hatch_flow=0;best_hatch_coverage=0
    for key,vs in lines.items():
        h,door=vs['hatch'],vs['door'];hc=components(h);hatch_groups+=len(hc)
        longest=max(longest,max(map(len,hc),default=0));opening_run=max(opening_run,max(map(len,components(h|door)),default=0))
        k,di=footprints(key,h);kh|=k;dh|=di
        k,di=footprints(key,h|door);ka_all|=k;da_all|=di
        # Contiguous service footprint on BOTH sides, anchored to a real hatch.
        # Doors can extend a service zone but do not themselves count as hatches.
        def paired_segments(vals,anchors):
            k,di=footprints(key,vals);dx,dy=key[2:4]
            common={a[1] if dx else a[0] for a in k if (a[0]+dx,a[1]+dy) in di}
            return [seg for seg in components(common) if set(seg)&anchors]
        best_flow=max(best_flow,max(map(len,paired_segments(h|door,h)),default=0))
        best_hatch_flow=max(best_hatch_flow,max(map(len,paired_segments(h,h)),default=0))
    def main(typ):
        return max(((rectangle(p),len(p)) for r,p in groups.items() if r[0]==typ),default=(0,0))
    kr,ks=main('Kitchen');dr,ds=main('Dining')
    old=100*(.45*(kr+dr)/den+.25*(ks+ds)/den+.20*(min(kr,dr)/max(kr,dr) if max(kr,dr) else 0)+.10*min(1,longest/8))
    # Width coverage is deliberately gradual, not a blanket penalty on gray tiles.
    # A 1/2/3/4+ tile-wide space receives 0.10/0.35/0.70/1.00 credit.
    seen_rooms=set(main_rooms);todo=deque(main_rooms)
    while todo:
        for neighbor in graph[todo.popleft()]:
            if neighbor not in seen_rooms:seen_rooms.add(neighbor);todo.append(neighbor)
    total_gray=sum(len(groups[r]) for r in secondary_rooms);effective=0;wide4=0;largest_gray=0;largest_gray4=0;dead_end=0;dual_area=0;room_details=[];reachable=0
    for r in sorted(secondary_rooms):
        p=groups[r];n=len(p);c2=len(square_coverage(p,2));c3=len(square_coverage(p,3));c4=len(square_coverage(p,4));rect=rectangle(p);rect4=rectangle(p,4)
        direct={v[0] for v in graph[r]};dual={'Kitchen','Dining'}<=direct
        # Thin rooms retain some credit. Reachability is door-based only.
        quality=.10*n+.25*c2+.35*c3+.30*c4
        if r in seen_rooms:effective+=quality;reachable+=n
        wide4+=c4;largest_gray=max(largest_gray,n);largest_gray4=max(largest_gray4,rect4)
        if len(graph[r])<=1:dead_end+=n
        if dual:dual_area+=n
        room_details.append(dict(tiles=n,rectangle=rect,rectangle4=rect4,wide4=c4,effective=round(quality,2),dual=dual,reachable=r in seen_rooms,doors=len(graph[r])))
    # Main room score rewards absolute open area and compactness, no equal-size requirement.
    openness=100*(.75*min(1,(kr+dr)/(.75*den))+.25*((kr+dr)/max(1,ks+ds)))
    # Gray score rewards useful absolute capacity and concentration in one large build area.
    secondary=100*(.75*min(1,effective/(.30*den))+.25*min(1,largest_gray4/(.25*den)))
    # Prefer one good long run, then a cohesive service zone; don't reward scattered windows equally.
    concentration=longest/max(1,hatches)
    window_score=100*(.40*min(1,longest/5)+.25*min(1,best_hatch_flow/6)+.20*min(1,best_flow/8)+.15*concentration)
    # Direct K-D access, gray access from both sides, low dead-end area, and independent alternative route.
    has_kd=doors>0
    alternate=False
    for k in (r for r in main_rooms if r[0]=='Kitchen'):
        visited={k};q=deque([k])
        while q:
            r=q.popleft()
            for v in graph[r]:
                if {r[0],v[0]}=={'Kitchen','Dining'}:continue
                if v not in visited:visited.add(v);q.append(v)
        if any(r[0]=='Dining' for r in visited):alternate=True
    connectivity=100*(.35*has_kd+.30*(dual_area/max(1,total_gray))+.20*(1-dead_end/total_gray if total_gray else 1)+.15*alternate)
    values=(openness,secondary,window_score,connectivity);w=normalize_weights(weights);score=sum(x*y for x,y in zip(values,w))
    return dict(hatches=hatches,longest=longest,kitchen=ks,dining=ds,krect=kr,drect=dr,rooms=len(groups),score=score,old_score=old,
        openness=openness,secondary=secondary,windows=window_score,connectivity=connectivity,gray=total_gray,gray_effective=effective,gray_wide4=wide4,gray_largest=largest_gray,gray_rect4=largest_gray4,gray_dual=dual_area,gray_deadend=dead_end,gray_reachable=reachable,gray_rooms=room_details,
        wta_k=len(kh),wta_d=len(dh),wta_door_k=len(ka_all),wta_door_d=len(da_all),service_span=best_flow,hatch_span=best_hatch_flow,hatch_groups=hatch_groups,opening_run=opening_run,kd_doors=doors,alternate_route=alternate)
