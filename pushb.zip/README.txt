PLATEUP SEED HUNTER — OFFLINE BETA 0.2 / OVERTIME SCORING

QUICK START
1. Extract the entire ZIP to a NEW folder. Keep your old results separately.
2. Double-click Run_Seed_Hunter.bat (uses your Python 3.14 launcher).
3. Click Open five-seed comparison to inspect the new scoring immediately.
4. To reuse previous hunts, click Rescore saved JSON and select one or more
   old hunt_results.json files. All unique imported maps are retained.
5. Or start a new offline hunt (default 1,000 Huge seeds, 4 real consecutive
   kitchen-to-dining hatches). Results open in your browser.
6. In the gallery, edit the four weights to rerank the saved candidates live.
   Reset returns to the weights used for that search. Copy seeds into PlateUp.

DEFAULT SCORING (experimental; not a game statistic)
30% Main-room openness: large open kitchen/dining rectangles, compactness.
25% Secondary usability: width coverage, largest 4+-wide rectangle.
30% Window opportunity: straight hatch run, continuous paired service span,
    hatch-only footprint and concentration rather than scattered windows.
15% Connectivity: direct K-D door, gray space with direct doors to both rooms,
    low dead-end area, and alternate kitchen-to-dining route through other rooms.

Gray-space width credit: 1 tile = 10%, 2 tiles = 35%, 3 tiles = 70%,
4+ tiles = 100%. Specifically a tile gets credit for the largest square (up
 to 4x4) it belongs to within its own room. Unreachable gray space gets no
 effective-tile credit. This is a geometry heuristic, not a simulation of
 actual conveyor paths; narrow corridors can still be useful.
Window tile availability (WTA): each hatch covers its adjacent tile and the
 two lateral neighbors, limited to the same room on each side. Counts use
 a union (no double counting). Door-inclusive WTA is potential only; doors
 remain separate from actual hatches and may need to remain clear. Continuous
 service span measures the longest contiguous paired footprint on the same
 wall, anchored to a real hatch. Consecutive hatch count remains the strict
 filter. Connectivity uses internal Door edges only, not hatches/front doors.

Weights are normalized automatically. Old score is also displayed for comparison.
Default new scores: 9T7TZD4U 92.45; 235297BF 85.76; OXFORD 77.15;
RGZS 75.73; PIZZA 68.82. New scores are on a different scale from old scores.
The Above OXFORD filter uses the new formula and current weights.

COMMAND LINE (PowerShell in extracted folder)
    py -3.14 hunt.py --count 10000 --hatches 4 --open
    py -3.14 hunt.py --count 10000 --hatches 4 --weights 30 25 30 15 --open
    py -3.14 rescore.py "C:\path\to\hunt_results.json" --open
    py -3.14 generator.py OXFORD RGZS PIZZA
    py -3.14 validate_layout.py generated.json
    py -3.14 test_generator.py
    py -3.14 test_scoring.py

NOTES
- Generator, RNG, seed validation and map profile unchanged from 0.1.1.
- Huge / Normal only; no game mods, external APIs, or dependencies.
- No zeros in seeds. Windows uses py -3.14; Tkinter required for launcher.
- CLI hunts default to overwriting output in package directory; GUI makes
  dated result directories. Gallery filters can only narrow saved results.
  Changing weights cannot restore maps discarded by the original hunt limit
  or Above OXFORD filter. Use a larger limit for more flexibility.
- Gallery favorites are browser-local where supported; export visible seeds
  for a durable text list. No cloud data. Uninstall by deleting this folder.
- Scores are provisional. Full automation placement and walking distances
  are not simulated. Secondary room width assumptions are adjustable in
  future scoring revisions; category weights can be changed now.
- Original three exact JSON benchmarks and two player-confirmed novel seeds
  remain the generator evidence; other seeds should be checked in-game.
- Tested on Linux Python 3.13. Windows Python 3.14 GUI needs local verification.
