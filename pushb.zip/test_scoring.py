import unittest,json
from pathlib import Path
from generator import generate
from scoring import metrics,rectangle,normalize_weights
from rescore import rescore
class Tests(unittest.TestCase):
    def test_new_examples(self):
        a,b=[metrics(generate(s)) for s in ('235297bf','9t7tzd4u')]
        self.assertGreater(a['old_score'],b['old_score']);self.assertGreater(b['score'],a['score'])
        self.assertEqual((a['gray'],b['gray']), (56,56));self.assertEqual((a['gray_rect4'],b['gray_rect4']),(36,48))
        self.assertEqual((a['gray_deadend'],b['gray_deadend']),(20,0));self.assertEqual((a['gray_dual'],b['gray_dual']),(36,56))
        self.assertEqual((a['opening_run'],b['opening_run']),(5,4));self.assertEqual((a['service_span'],b['service_span']),(7,8))
    def test_window_metrics(self):
        for seed,expected in [('oxford',(4,1,6,6,7,7)),('rgzs',(2,2,7,7,9,9)),('pizza',(4,1,6,4,6,4)),('9t7tzd4u',(4,1,6,6,8,8))]:
            m=metrics(generate(seed));self.assertEqual(tuple(m[k] for k in ('longest','hatch_groups','wta_k','wta_d','wta_door_k','wta_door_d')),expected)
        self.assertGreater(metrics(generate('oxford'))['windows'],metrics(generate('rgzs'))['windows'])
    def test_width(self):
        self.assertEqual(rectangle({(x,y) for x in range(2) for y in range(12)},4),0)
        self.assertEqual(rectangle({(x,y) for x in range(4) for y in range(12)},4),48)
    def test_weights(self):
        d=generate('oxford');m=metrics(d,(100,0,0,0));self.assertEqual(m['score'],m['openness'])
        for w in [(0,0,0,0),(-1,2,3,4),(1,2,3),(1,2,3,float('nan'))]:
            with self.assertRaises(ValueError):normalize_weights(w)
    def test_import(self):
        rows,stats=rescore([Path(__file__).parent/'benchmarks.json']);self.assertEqual(len(rows),3);self.assertEqual(rows[0][1]['seed'],'oxford')
if __name__=='__main__':unittest.main(verbosity=2)
