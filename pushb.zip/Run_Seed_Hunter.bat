@echo off
cd /d "%~dp0"
py -3.14 app.py
if errorlevel 1 (
 echo The graphical launcher failed. Use the command-line hunt below.
 py -3.14 hunt.py --count 1000 --hatches 4 --open
 pause
)
