@echo off
cd /d "%~dp0"
py -3.14 generator.py OXFORD RGZS PIZZA
if errorlevel 1 goto end
py -3.14 validate_layout.py generated.json
py -3.14 test_generator.py
py -3.14 test_scoring.py
:end
pause
