"""Compare a candidate offline generator's JSON to reference layouts. No network."""
import argparse,json,sys
from pathlib import Path
from collections import defaultdict

def read(p):
    a=json.loads(Path(p).read_text(encoding='utf-8-sig'))
    return a if isinstance(a,list) else [a]

def canonical(d):
    tiles={}; groups=defaultdict(list)
    for t in d['tiles']:
        p=(t['x'],t['y']); typ=t['roomType'].casefold()
        if p in tiles: raise ValueError(f'Duplicate tile {p}')
        tiles[p]=typ; groups[t['roomId']].append(p)
    if len(tiles)!=d['width']*d['height']: raise ValueError('Tile count differs from dimensions')
    partition={p:min(group) for group in groups.values() for p in group}
    features={}
    for f in d['features']:
        a=(f['tile1X'],f['tile1Y']); b=(f['tile2X'],f['tile2Y']); key=tuple(sorted((a,b))); typ=f['type'].casefold()
        if abs(a[0]-b[0])+abs(a[1]-b[1])!=1: raise ValueError(f'Nonadjacent feature: {key}')
        if key in features and features[key]!=typ: raise ValueError(f'Conflicting feature {key}')
        features[key]=typ
    return tiles,partition,features

def compare(ref,cand):
    a,b,c=canonical(ref); x,y,z=canonical(cand)
    def differences(left,right):
        return sum(left.get(k)!=right.get(k) for k in left.keys()|right.keys())
    return {'dimensions_match':(ref['width'],ref['height'])==(cand['width'],cand['height']), 'profile_match':ref.get('layoutProfileId')==cand.get('layoutProfileId'), 'tile_type_differences':differences(a,x),'room_partition_differences':differences(b,y),'feature_differences':differences(c,z)}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('candidate');p.add_argument('--reference',default=str(Path(__file__).with_name('benchmarks.json')));args=p.parse_args()
    refs={(r['seed'].casefold(),r['settingSlug'].casefold()):r for r in read(args.reference)}
    ok=True; seen=set()
    for d in read(args.candidate):
        key=d['seed'].casefold(),d['settingSlug'].casefold();seen.add(key)
        if key not in refs: print(key,'NO REFERENCE');ok=False;continue
        report=compare(refs[key],d); passed=report['dimensions_match'] and report['profile_match'] and not any(report[k] for k in ('tile_type_differences','room_partition_differences','feature_differences'));ok &= passed
        print(key, 'PASS' if passed else 'FAIL',json.dumps(report))
    missing=refs.keys()-seen
    if missing: print('Missing reference seeds:',sorted(missing));ok=False
    return 0 if ok else 1
if __name__=='__main__':sys.exit(main())
