"""PlateUp Seed Hunter: seed initialization research probe, NOT a layout generator.
Hash and context arithmetic transcribed from the user's October 2026 DLL IL.
Unity RNG candidate checked against publicly reported Unity test vectors, not
against the user's installed player. No Steam or Unity files are read or changed.
"""
import argparse
import json
import unittest
MASK=0xffffffff
M=124192293
LAYOUT_CONTEXT=5078598
MAP_CONTEXT=98234234

def signed(n):
    n &= MASK
    return n if n < 2**31 else n-2**32

def seed_hash(text):
    # Kitchen.Seed truncates to 8 UTF-16 code units; this probe accepts ASCII seeds.
    if not text.isascii() or not text.isalnum() or not text:
        raise ValueError('Use a nonempty ASCII alphanumeric seed.')
    h=5381
    for byte in reversed(text[:8].encode('ascii')):
        h=(h*33+byte)&MASK
    return signed(h)

def context_seed(fixed_seed, instance_seed, subcontext=0):
    return signed(fixed_seed+M*signed(instance_seed+M*subcontext))

class UnityRandomCandidate:
    def __init__(self, seed):
        self.state=[seed&MASK]
        for _ in range(3): self.state.append((1812433253*self.state[-1]+1)&MASK)
    def next_uint(self):
        x,y,z,w=self.state
        t=(x^(x<<11))&MASK
        w=(w^(w>>19)^t^(t>>8))&MASK
        self.state=[y,z,self.state[-1],w]
        return w
    def range_int(self, lo, hi):
        if lo==hi: return lo
        if lo>hi: raise ValueError('This probe supports ascending ranges only.')
        return lo+self.next_uint()%(hi-lo)

def probe(text):
    h=seed_hash(text)
    a=context_seed(h,LAYOUT_CONTEXT)
    b=context_seed(h,MAP_CONTEXT)
    r=UnityRandomCandidate(b)
    return {'seed_exact_case':text[:8],'seed_hash':h,'layout_selection_context':a,
            'map_context':b,'candidate_first_map_graph_seed':r.range_int(-2**31,2**31-1),
            'graph_seed_status':'candidate; not verified in installed Unity player'}

class TestProbe(unittest.TestCase):
    def test_hash_order(self): self.assertEqual(seed_hash('AB'),((5381*33+66)*33+65))
    def test_hash_truncation(self): self.assertEqual(seed_hash('abcdefgh'),seed_hash('abcdefgh9'))
    def test_case(self): self.assertNotEqual(seed_hash('OXFORD'),seed_hash('oxford'))
    def test_context(self): self.assertEqual(context_seed(123,1),124192416)
    def test_zero_init(self): self.assertEqual(UnityRandomCandidate(0).state,[0,1,1812433254,1900727103])
    def test_public_vector(self):
        r=UnityRandomCandidate(1234)
        self.assertEqual([r.next_uint() for _ in range(5)],[3463400838,3496203776,3452947669,1278673611,4169168310])
    def test_public_ranges(self):
        r=UnityRandomCandidate(1234)
        self.assertEqual([r.range_int(0,2**31-1) for _ in range(5)],[1315917191,1348720129,1305464022,1278673611,2021684663])

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('seeds',nargs='*',default=['oxford','rgzs','pizza'])
    p.add_argument('--test',action='store_true')
    a=p.parse_args()
    if a.test: unittest.main(argv=['seed_probe.py'])
    else: print(json.dumps([probe(s) for s in a.seeds],indent=2))
