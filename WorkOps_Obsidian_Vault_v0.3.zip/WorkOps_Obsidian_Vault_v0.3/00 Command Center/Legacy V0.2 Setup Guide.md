---
type: guide
status: active
---
# V0.2 Setup Guide

## Core settings
Enable **Bases, Daily Notes, Templates, Canvas, Properties, Backlinks, Command Palette, Workspaces**.

Daily Notes:
- Folder: `01 Daily/2026`
- Format: `YYYY-MM-DD`
- Template: `90 Templates/Daily Note Template`

Templates folder:
- `90 Templates`

## Install first
1. **Tasks** — vault-wide Markdown tasks.
2. **Templater** — dynamic templates used by create buttons.
3. **Meta Bind** — buttons and project property controls.
4. **Calendar Plus** — small sidebar Daily/Weekly calendar.
5. **Homepage** — set `00 Command Center/Work Command Center.md` as startup page.

## Install second
6. **Full Calendar Remastered** — scheduled meetings/change windows. Configure a Daily Note source pointed at `01 Daily/2026`, using the `Schedule` heading.
7. **QuickAdd** — start with only `Log Operation` and `Capture Task` to append into today's note.
8. **Commander** — ribbon shortcuts to Home, Today, Tasks, New Meeting, New Issue.
9. **Contribution Graph** — later, build an activity heatmap from meaningful work rather than raw word count.

## Suggested workspace
**Left:** Files / Search  
**Center:** Command Center  
**Right:** Calendar Plus / Backlinks / Outline  
**Second main tab:** Full Calendar Remastered

## Important design rule
Plugins enhance interaction. Markdown + properties + links remain the source of truth.
