---
type: guide
status: active
version: "0.3"
---
# QuickAdd Setup

V0.3 treats QuickAdd as the **capture router**. The dashboard's **⚡ Quick Capture** button opens `QuickAdd: Run`.

Create these choices in **Settings → QuickAdd**.

## 1. Log Operation

**Choice type:** Capture  
**Capture to:** Daily note (`{{DAILY}}`)  
**Write position:** After line  
**Insert after:** `## Operations Log`  
**Insert at end of section:** On  
**Create line if not found:** On

Capture format:

```text
**{{DATE:HH:mm}}** — {{VALUE}}
```

Use this for anything that would normally become scrap paper.

## 2. Capture Task

**Choice type:** Capture  
**Capture to:** Daily note (`{{DAILY}}`)  
**Write position:** After line  
**Insert after:** `## Tasks`  
**Insert at end of section:** On

Capture format:

```text
- [ ] {{VALUE}}
```

## 3. Waiting Item

**Choice type:** Capture  
**Capture to:** Daily note (`{{DAILY}}`)  
**Write position:** After line  
**Insert after:** `## Waiting`  
**Insert at end of section:** On

Capture format:

```text
- [ ] #waiting {{VALUE}}
```

## 4. Quick Note

**Choice type:** Template  
**Template:** `90 Templates/Quick Note Template.md`  
**Destination:** `50 Reference/Quick Notes`

## Recommended QuickAdd behavior

- Turn **Add to command palette** on for the first three.
- Keep **QuickAdd: Run** available as your universal picker.
- Give **Log Operation** a very easy hotkey once it becomes habitual.
- Don't create 20 QuickAdd choices immediately. Add one only when you repeatedly feel friction.

## When to capture what

| Thought | Best destination |
|---|---|
| “Check this later” | Task |
| Quick observation | Log Operation |
| Waiting on someone | Waiting Item |
| Durable fact/reference | Quick Note |
| Needs investigation/history | Issue |
| Coordinated outcome | Project |
