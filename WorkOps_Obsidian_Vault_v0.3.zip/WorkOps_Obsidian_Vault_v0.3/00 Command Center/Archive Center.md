---
type: dashboard
status: active
cssclasses: [workops-dashboard]
---
# 🗄 Archive Center

> [!abstract] Archive instead of delete
> Preserve completed, cancelled, superseded, duplicate, or abandoned work while keeping active views clean.

## Archive Queue
Notes marked `status: archived` that have not been moved into `99 Archive` appear here.

![[80 Bases/Archive.base#Queue]]

## Archived
![[80 Bases/Archive.base#Archived]]

## Workflow
1. Set `status: archived`.
2. Add `archived: YYYY-MM-DD`.
3. Add `archive_reason: completed | cancelled | superseded | duplicate | no-longer-needed`.
4. Move the note into the matching `99 Archive` folder from inside Obsidian.

The queue intentionally makes archiving safe even before we automate file movement.
