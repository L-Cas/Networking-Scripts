---
type: dashboard
status: active
version: "0.3"
cssclasses:
  - workops-dashboard
focus_project: "[[30 Projects/Program Alpha - 100 User Expansion|Program Alpha - 100 User Expansion]]"
focus_text: "Get the fiber scope quoted while validating access capacity for the expansion."
focus_context: "Main Campus · Building 3 / East Wing"
---
# Operations Workbench

<span class="workbench-kicker">`= dateformat(date(today), "cccc · MMMM d, yyyy")` · Personal operations center</span>

`BUTTON[new-project, new-meeting, new-issue, new-change, new-decision, run-quickadd]`

> [!workbench-grid]
> > [!focus]+ Current Focus
> > <span class="eyebrow">PRIMARY OUTCOME</span>
> > ### `VIEW[{focus_project}][text(renderMarkdown)]`
> > `VIEW[{focus_text}][text(renderMarkdown)]`
> > <span class="workbench-context">📍 `VIEW[{focus_context}][text]`</span>
> >
> > **Use this card as the one thing you want to protect time for today.** Change the three `focus_*` properties when priorities shift.
> >
> > [[30 Projects/Program Alpha - 100 User Expansion|Open focus project]] · [[00 Command Center/Task Center|Open tasks]]
> >
> > ---
> > **Quick actions:** `BUTTON[run-quickadd, new-issue]`
>
> > [!schedule]+ Today's Schedule
> > ```dataviewjs
> > const today = dv.date("today").toISODate();
> > const folders = ['"40 Operations/Meetings"','"40 Operations/Changes"'];
> > let rows = [];
> > for (const src of folders) {
> >   for (const p of dv.pages(src)) {
> >     const d = p.date ? dv.date(p.date) : null;
> >     if (!d || d.toISODate() !== today) continue;
> >     rows.push({
> >       time: p.start_time ?? (p.type === "meeting" ? "Meeting" : "—"),
> >       link: p.file.link,
> >       type: p.type ?? "record",
> >       location: p.location ?? ""
> >     });
> >   }
> > }
> > rows.sort((a,b) => String(a.time).localeCompare(String(b.time)));
> > if (rows.length) dv.table(["Time","Event","Where"], rows.map(r => [r.time, r.link, r.location]));
> > else dv.paragraph("_No structured meetings or changes scheduled today._");
> > ```
> >
> > **Calendar:** keep **Calendar Plus** docked in the right sidebar; open **Full Calendar Remastered** when you need the full week/month schedule.

> [!workbench-grid]
> > [!priorities]+ Today's Priorities
> > ```tasks
> > not done
> > happens before tomorrow
> > sort by priority
> > sort by due
> > limit 6
> > ```
> >
> > [[00 Command Center/Task Center|Open complete Task Center →]]
>
> > [!daily]+ Daily Checks
> > ```dataviewjs
> > const day = dv.date("today");
> > const path = `01 Daily/${day.toFormat("yyyy")}/${day.toISODate()}`;
> > const page = dv.page(path);
> > const daily = page ? page.file.tasks.where(t => t.text.includes("#daily")) : [];
> > const total = daily.length;
> > const done = total ? daily.where(t => t.completed).length : 0;
> > const pct = total ? Math.round(done / total * 100) : 0;
> > dv.container.innerHTML = `<div class="daily-progress"><div><strong>${done} / ${total}</strong><span> complete · ${pct}%</span></div><div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div></div>`;
> > if (total) dv.taskList(daily, false);
> > else dv.paragraph("_Open/create today's Daily Note to start the checklist._");
> > ```

> [!pulse]+ Operations Pulse
> ```dataviewjs
> const projects = dv.pages('"30 Projects"').where(p => p.type === "project" && p.status !== "archived");
> const active = projects.where(p => p.status === "active" && !p.parent_project).length;
> const waiting = projects.where(p => p.status === "waiting" || p.status === "blocked").length;
> const issues = dv.pages('"40 Operations/Issues"').where(p => p.type === "issue" && !["resolved","archived"].includes(p.status)).length;
> const changes = dv.pages('"40 Operations/Changes"').where(p => p.type === "change" && !["complete","cancelled","archived"].includes(p.status)).length;
> const now = dv.date("today");
> const horizon = now.plus({days: 7});
> let due7 = 0;
> for (const p of dv.pages()) {
>   for (const t of p.file.tasks ?? []) {
>     if (t.completed || !t.due) continue;
>     const d = dv.date(t.due);
>     if (d && d >= now && d <= horizon) due7++;
>   }
> }
> const cards = [
>   ["Active", active, "top-level projects"],
>   ["Waiting", waiting, "waiting / blocked"],
>   ["Issues", issues, "open investigations"],
>   ["Changes", changes, "open change records"],
>   ["Due 7d", due7, "tasks due soon"]
> ];
> dv.container.innerHTML = `<div class="ops-pulse-grid">${cards.map(([label,value,note]) => `<div class="metric-card"><span class="metric-label">${label}</span><strong>${value}</strong><small>${note}</small></div>`).join("")}</div>`;
> ```

> [!workbench-grid]
> > [!active-work]+ Active Work
> > ![[80 Bases/Projects.base#Workbench]]
>
> > [!quick-capture]+ Quick Capture
> > <span class="eyebrow">DON'T BREAK YOUR FLOW</span>
> >
> > Anything that would normally land on a sticky note, scrap paper, or temporary Notepad window can go into the Daily Operations Log first.
> >
> > ### `BUTTON[run-quickadd]`
> >
> > Configure these four QuickAdd choices:
> >
> > - **Log Operation** → timestamped line in today's `Operations Log`
> > - **Capture Task** → checkbox in today's `Tasks`
> > - **Waiting Item** → checkbox in today's `Waiting`
> > - **Quick Note** → creates a lightweight reference note
> >
> > [[00 Command Center/QuickAdd Setup|Set up QuickAdd →]]

> [!activity]+ Recent Activity
> ```dataviewjs
> const groups = [
>   ['"60 Activity"', "ACTIVITY"],
>   ['"40 Operations/Meetings"', "MEETING"],
>   ['"40 Operations/Issues"', "ISSUE"],
>   ['"40 Operations/Changes"', "CHANGE"],
>   ['"40 Operations/Decisions"', "DECISION"]
> ];
> let rows = [];
> for (const [src, label] of groups) {
>   for (const p of dv.pages(src)) {
>     const d = p.date ? dv.date(p.date) : null;
>     if (!d) continue;
>     rows.push({date:d, label, link:p.file.link, context:p.project ?? p.program ?? p.site ?? ""});
>   }
> }
> rows.sort((a,b) => b.date.toMillis() - a.date.toMillis());
> rows = rows.slice(0, 9);
> if (rows.length) dv.table(["Date","Type","Record","Context"], rows.map(r => [r.date.toFormat("MMM dd"), r.label, r.link, r.context]));
> else dv.paragraph("_No structured activity records yet._");
> ```

---

<span class="workbench-footer">[[10 Sites/Main Campus|Sites]] · [[20 Programs/Program Alpha|Programs]] · [[00 Command Center/Archive Center|Archive]] · [[00 Command Center/Plugin Stack|Plugin Stack]] · [[START HERE|Vault Guide]]</span>

```meta-bind-button
style: primary
label: + Project
id: new-project
hidden: true
actions:
  - type: templaterCreateNote
    templateFile: "90 Templates/Project Template.md"
    folderPath: "30 Projects"
    fileName: "New Project - RENAME ME"
    openNote: true
```

```meta-bind-button
style: default
label: + Meeting
id: new-meeting
hidden: true
actions:
  - type: templaterCreateNote
    templateFile: "90 Templates/Meeting Template.md"
    folderPath: "40 Operations/Meetings"
    fileName: "New Meeting - RENAME ME"
    openNote: true
```

```meta-bind-button
style: default
label: + Issue
id: new-issue
hidden: true
actions:
  - type: templaterCreateNote
    templateFile: "90 Templates/Issue Template.md"
    folderPath: "40 Operations/Issues"
    fileName: "New Issue - RENAME ME"
    openNote: true
```

```meta-bind-button
style: default
label: + Change
id: new-change
hidden: true
actions:
  - type: templaterCreateNote
    templateFile: "90 Templates/Change Template.md"
    folderPath: "40 Operations/Changes"
    fileName: "New Change - RENAME ME"
    openNote: true
```

```meta-bind-button
style: default
label: + Decision
id: new-decision
hidden: true
actions:
  - type: templaterCreateNote
    templateFile: "90 Templates/Decision Template.md"
    folderPath: "40 Operations/Decisions"
    fileName: "New Decision - RENAME ME"
    openNote: true
```

```meta-bind-button
style: primary
label: ⚡ Quick Capture
id: run-quickadd
hidden: true
actions:
  - type: command
    command: quickadd:run-quickadd
```
