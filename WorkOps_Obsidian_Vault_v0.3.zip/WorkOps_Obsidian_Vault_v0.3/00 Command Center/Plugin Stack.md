---
type: guide
status: active
version: "0.3"
---
# Plugin Stack

> [!success] V0.3 philosophy
> Plugins are welcome when they **reduce friction or make live information visible**. Markdown, links, and properties remain the source of truth.

## Install for the full V0.3 Workbench

| Plugin | Role in this vault | Priority |
|---|---|---|
| **Dataview** | Live counts, schedule, recent activity, daily progress | Must-have |
| **Tasks** | Interactive task aggregation | Must-have |
| **Meta Bind** | Dashboard buttons and project controls | Must-have |
| **Templater** | Template-driven note creation | Must-have |
| **QuickAdd** | Fast capture router | Must-have |
| **Calendar Plus** | Compact sidebar Daily Note calendar | Must-have |
| **Homepage** | Opens the Workbench automatically | Must-have |
| **Full Calendar Remastered** | Full week/month scheduling view | Recommended |
| **Commander** | Put your favorite commands in the ribbon/titlebar | Recommended |
| **Contribution Graph** | Later activity heatmap | Optional |

## Homepage

Set the homepage to:

`00 Command Center/Work Command Center.md`

Recommended behavior:

- Open on startup
- Reading mode or Live Preview
- Keep other tabs unless you prefer a clean start

## Calendar Plus

Recommended placement: **right sidebar**.

Daily notes:

- Enabled
- Folder: `01 Daily/2026`
- Format: `YYYY-MM-DD`
- Template: `90 Templates/Daily Note Template`
- Dot style: **Word count and open tasks** if you like the activity indicators

You can turn Weekly Notes on later and point them at `02 Weekly`.

## Commander

Good permanent commands:

- Homepage: Open homepage
- Daily Notes: Open today's daily note
- QuickAdd: Run
- Tasks: Create or edit task
- Search current vault

This makes the left ribbon feel like your own application launcher.

## Full Calendar Remastered

Use it for scheduled records, meetings, and change windows. The Daily Note template retains a `## Schedule` section for calendar-style entries.

## Dataview

Enable **JavaScript queries**. The Workbench uses `dataviewjs` for live dashboard cards.

## Meta Bind

The Workbench uses buttons and project notes use inline property controls. Templater must also be installed for the create-note buttons.

## Theme suggestion

Start with your normal dark theme before installing a highly opinionated theme. V0.3's CSS uses Obsidian theme variables, so it should inherit most themes cleanly.
