---
type: dashboard
status: active
cssclasses: [workops-dashboard]
---
# ✅ Task Center

Tasks can live in Daily Notes, Projects, Meetings, Issues, or Changes. One checkbox remains the source of truth.

## Today + Overdue
```tasks
not done
due before tomorrow
sort by priority
sort by due
```

## Next 7 Days
```tasks
not done
due after today
due before in 8 days
sort by due
```

## Waiting On
```tasks
not done
description includes #waiting
sort by due
```

## Project Tasks
```tasks
not done
path includes 30 Projects
sort by due
sort by priority
```
