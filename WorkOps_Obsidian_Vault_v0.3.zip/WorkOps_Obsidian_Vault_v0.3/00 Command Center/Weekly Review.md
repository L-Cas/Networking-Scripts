---
type: review
status: active
period: weekly
---
# Weekly Review

## What moved?
- Wins:
- Deliverables:
- Issues resolved:

## Active Projects
![[80 Bases/Projects.base#Active]]

## Waiting / Blocked
![[80 Bases/Projects.base#Waiting and Blocked]]

## Open Issues
![[80 Bases/Operations.base#Open Issues]]

## Upcoming Changes
![[80 Bases/Operations.base#Open Changes]]

## Archive candidates
- 

## Performance-review breadcrumbs
-
