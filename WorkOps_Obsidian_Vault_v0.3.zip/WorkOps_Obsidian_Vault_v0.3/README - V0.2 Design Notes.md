# V0.2 Design Notes

- **Site + Program are parallel contexts**, not a rigid tree.
- **Location is one optional string**, not Building/Floor/Room bureaucracy.
- **Tasks stay checkboxes** until complexity earns a workstream.
- **Daily Notes replace sticky notes** and preserve chronology.
- **Archive is a lifecycle** with an Archive Queue.
- **Templates cover repeated note types** so creation stays fast.
- **Plugins make it alive**, but Markdown remains the source of truth.
