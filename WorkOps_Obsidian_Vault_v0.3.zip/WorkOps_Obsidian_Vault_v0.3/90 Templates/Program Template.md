<%*
const name = await tp.system.prompt("Program name");
if (name) await tp.file.rename(name);
%>
---
type: program
status: active
priority: medium
sites:
---
# <% tp.file.title %>

## Objective
## Projects
```base
filters:
  and:
    - 'type == "project"'
    - 'program == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Projects
    order: [file.name, site, location, status, priority, target]
```
