<%*
const name = await tp.system.prompt("Quick note title");
if (name) await tp.file.rename(name);
%>
---
type: reference
status: active
created: <% tp.date.now("YYYY-MM-DD") %>
site:
program:
project:
location:
---
# <% tp.file.title %>

## Notes
