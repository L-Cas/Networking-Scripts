---
type: daily
date: {{date:YYYY-MM-DD}}
week:
focus:
---
# {{date:dddd, YYYY-MM-DD}}

## Top 3

- [ ] 
- [ ] 
- [ ] 

## Schedule

## Daily Checks

- [ ] #daily Review the Workbench and today's schedule
- [ ] #daily Review waiting / blocked items
- [ ] #daily Check high-priority issues or changes
- [ ] #daily Capture meaningful operational breadcrumbs
- [ ] #daily End-of-day carry-forward

## Operations Log

**{{time:HH:mm}}** — 

## Tasks

- [ ] 

## Waiting

## Meetings

## Decisions

## End of Day

### Accomplished

- 

### Carry forward

- 
