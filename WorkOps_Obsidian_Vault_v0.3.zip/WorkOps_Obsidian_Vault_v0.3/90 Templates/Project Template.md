<%*
const name = await tp.system.prompt("Project / workstream name");
if (name) await tp.file.rename(name);
%>
---
type: project
status: active
priority: medium
health: good
site:
program:
location:
parent_project:
started: <% tp.date.now("YYYY-MM-DD") %>
target:
area:
---
# <% tp.file.title %>

## Project controls
**Status:** `INPUT[inlineSelect(option(active, Active),option(waiting, Waiting),option(blocked, Blocked),option(complete, Complete),option(archived, Archived)):status]`  
**Priority:** `INPUT[inlineSelect(option(high, High),option(medium, Medium),option(low, Low)):priority]`  
**Health:** `INPUT[inlineSelect(option(good, Good),option(watch, Watch),option(at-risk, At Risk)):health]`

## Objective

## Current status

## Tasks
- [ ] 

## Workstreams
```base
filters:
  and:
    - 'type == "project"'
    - 'parent_project == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Workstreams
    order: [file.name, location, status, priority, target]
```

## Related records
```base
filters:
  and:
    - 'file.hasLink(this.file)'
    - or:
        - 'type == "meeting"'
        - 'type == "change"'
        - 'type == "issue"'
        - 'type == "decision"'
        - 'type == "activity"'
views:
  - type: table
    name: Related
    order: [file.name, type, date, status, location]
```
