<%*
const name = await tp.system.prompt("Issue title");
if (name) await tp.file.rename(name);
%>
---
type: issue
status: open
priority: medium
date: <% tp.date.now("YYYY-MM-DD") %>
site:
program:
project:
location:
owner:
---
# <% tp.file.title %>

## Impact
## Current state
## Actions
- [ ]
