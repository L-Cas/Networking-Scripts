<%*
const subject = await tp.system.prompt("Meeting title");
const date = tp.date.now("YYYY-MM-DD");
if (subject) await tp.file.rename(`${date} - ${subject}`);
%>
---
type: meeting
status: complete
date: <% tp.date.now("YYYY-MM-DD") %>
site:
program:
project:
location:
meeting_type:
---
# <% tp.file.title %>

## Attendees
- 
## Agenda
1. 
## Notes
## Decisions
- 
## Actions
- [ ]
