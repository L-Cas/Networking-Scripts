<%*
const name = await tp.system.prompt("Site name");
if (name) await tp.file.rename(name);
%>
---
type: site
status: active
site_class:
priority: medium
---
# <% tp.file.title %>

## Summary
## Projects
```base
filters:
  and:
    - 'type == "project"'
    - 'site == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Projects
    order: [file.name, program, location, status, priority, target]
```
