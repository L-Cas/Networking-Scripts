<%*
const subject = await tp.system.prompt("Change title");
const date = await tp.system.prompt("Change date YYYY-MM-DD", tp.date.now("YYYY-MM-DD"));
if (subject) await tp.file.rename(`${date} - ${subject}`);
%>
---
type: change
status: planned
date: <% date %>
start_time:
end_time:
site:
program:
project:
location:
risk: medium
---
# <% tp.file.title %>

## Objective
## Preconditions
- [ ] 
## Implementation
1. 
## Rollback trigger
## Validation
- [ ]
