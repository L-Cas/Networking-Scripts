<%*
const subject = await tp.system.prompt("Decision title");
const date = tp.date.now("YYYY-MM-DD");
if (subject) await tp.file.rename(`${date} - ${subject}`);
%>
---
type: decision
status: accepted
date: <% tp.date.now("YYYY-MM-DD") %>
site:
program:
project:
location:
---
# <% tp.file.title %>

## Decision
## Rationale
## Consequence
