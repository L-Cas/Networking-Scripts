---
type: change
status: planned
date: 2026-10-30
start_time: "18:00"
end_time: "20:00"
site: "[[10 Sites/Main Campus|Main Campus]]"
program:
project: "[[30 Projects/Main Campus - Tech Refresh|Main Campus - Tech Refresh]]"
location: "Building 3 / Room 214"
risk: medium
---
# B3-214 Access Stack Refresh

## Preconditions
- [ ] Configuration reviewed
- [ ] Uplink issue understood
- [ ] Rollback plan ready

## Validation
- [ ] Uplinks healthy
- [ ] Expected VLANs present
- [ ] Monitoring normal
- [ ] Representative endpoints validated
