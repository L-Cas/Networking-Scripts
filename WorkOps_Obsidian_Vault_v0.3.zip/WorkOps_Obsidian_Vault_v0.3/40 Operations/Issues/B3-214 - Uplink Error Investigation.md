---
type: issue
status: open
priority: high
date: 2026-10-28
site: "[[10 Sites/Main Campus|Main Campus]]"
program:
project: "[[30 Projects/Main Campus - Tech Refresh|Main Campus - Tech Refresh]]"
location: "Building 3 / Room 214"
owner: operations
---
# B3-214 - Uplink Error Investigation

Quick observation was first captured in the Daily Note and promoted only after it required follow-up.

## Actions
- [ ] Check optic and patching 📅 2026-10-29
- [ ] Review counters after physical check 📅 2026-10-29
