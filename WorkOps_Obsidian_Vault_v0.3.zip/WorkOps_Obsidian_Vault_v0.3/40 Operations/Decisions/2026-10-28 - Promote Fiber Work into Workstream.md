---
type: decision
status: accepted
date: 2026-10-28
site: "[[10 Sites/Main Campus|Main Campus]]"
program: "[[20 Programs/Program Alpha|Program Alpha]]"
project: "[[30 Projects/Program Alpha - 100 User Expansion|Program Alpha - 100 User Expansion]]"
location: "Building 3 / East Wing"
---
# Decision - Promote Fiber Work into Workstream

## Decision
Create a dedicated fiber child workstream beneath the 100 User Expansion project.

## Rationale
The original checkbox gained vendor, dependency, funding, installation, and validation work.
