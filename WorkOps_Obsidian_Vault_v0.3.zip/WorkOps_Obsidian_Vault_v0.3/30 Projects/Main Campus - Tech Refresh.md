---
type: project
status: active
priority: high
health: good
site: "[[10 Sites/Main Campus|Main Campus]]"
program:
location:
parent_project:
started: 2026-09-01
target: 2027-03-31
area: [network, infrastructure]
---
# Main Campus - Tech Refresh

## Project controls
**Status:** `INPUT[inlineSelect(option(active, Active),option(waiting, Waiting),option(blocked, Blocked),option(complete, Complete),option(archived, Archived)):status]`  
**Priority:** `INPUT[inlineSelect(option(high, High),option(medium, Medium),option(low, Low)):priority]`  
**Health:** `INPUT[inlineSelect(option(good, Good),option(watch, Watch),option(at-risk, At Risk)):health]`

## Objective
Refresh aging network infrastructure across the fictional campus.

## Tasks
- [ ] Review next building sequence 📅 2026-11-02
- [ ] Confirm hardware allocation 📅 2026-11-03
- [ ] Update migration checklist 📅 2026-11-05

## Child workstreams
```base
filters:
  and:
    - 'type == "project"'
    - 'parent_project == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Workstreams
    order: [file.name, location, status, priority, target]
```
