---
type: project
status: active
priority: high
health: watch
site: "[[10 Sites/Main Campus|Main Campus]]"
program: "[[20 Programs/Program Alpha|Program Alpha]]"
location: "Building 3 / East Wing"
parent_project:
started: 2026-10-21
target: 2026-12-15
area: [network, infrastructure]
---
# Program Alpha - 100 User Expansion

## Project controls
**Status:** `INPUT[inlineSelect(option(active, Active),option(waiting, Waiting),option(blocked, Blocked),option(complete, Complete),option(archived, Archived)):status]`  
**Priority:** `INPUT[inlineSelect(option(high, High),option(medium, Medium),option(low, Low)):priority]`  
**Health:** `INPUT[inlineSelect(option(good, Good),option(watch, Watch),option(at-risk, At Risk)):health]`

## Objective
Support roughly 100 additional users with sufficient network access and uplink capacity.

## Tasks
- [x] Confirm approximate user count ✅ 2026-10-27
- [x] Identify target area ✅ 2026-10-27
- [ ] Validate available switch ports 📅 2026-10-30
- [ ] Review wireless coverage impact 📅 2026-11-03
- [ ] #waiting Receive fiber quote 📅 2026-11-06
- [ ] Review quote and funding path 📅 2026-11-09

## Workstreams
```base
filters:
  and:
    - 'type == "project"'
    - 'parent_project == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Workstreams
    order: [file.name, location, status, priority, target]
```

## Related records
```base
filters:
  and:
    - 'file.hasLink(this.file)'
    - or:
        - 'type == "meeting"'
        - 'type == "change"'
        - 'type == "issue"'
        - 'type == "decision"'
        - 'type == "activity"'
views:
  - type: table
    name: Related
    order: [file.name, type, date, status, location]
```

> [!example] Why the fiber task became a workstream
> `Get fiber quote` gained vendor coordination, route questions, dependencies, funding, installation, and validation. That's enough independent complexity to earn [[30 Projects/100 User Expansion - Fiber Workstream|its own child project]].
