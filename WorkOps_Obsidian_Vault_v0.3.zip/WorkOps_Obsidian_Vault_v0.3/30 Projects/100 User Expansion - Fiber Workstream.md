---
type: project
status: waiting
priority: high
health: watch
site: "[[10 Sites/Main Campus|Main Campus]]"
program: "[[20 Programs/Program Alpha|Program Alpha]]"
location: "Building 3 / East Wing"
parent_project: "[[30 Projects/Program Alpha - 100 User Expansion|Program Alpha - 100 User Expansion]]"
started: 2026-10-27
target: 2026-11-20
area: [fiber, infrastructure]
---
# 100 User Expansion - Fiber Workstream

## Project controls
**Status:** `INPUT[inlineSelect(option(active, Active),option(waiting, Waiting),option(blocked, Blocked),option(complete, Complete),option(archived, Archived)):status]`  
**Priority:** `INPUT[inlineSelect(option(high, High),option(medium, Medium),option(low, Low)):priority]`  
**Health:** `INPUT[inlineSelect(option(good, Good),option(watch, Watch),option(at-risk, At Risk)):health]`

## Tasks
- [x] Identify source/destination areas ✅ 2026-10-28
- [ ] Confirm spare-strand assumptions 📅 2026-10-29
- [ ] Send quote request 📅 2026-10-29
- [ ] #waiting Receive vendor quote 📅 2026-11-06
- [ ] Validate quote scope
- [ ] Confirm funding owner
- [ ] Schedule installation
- [ ] Validate installed fiber
