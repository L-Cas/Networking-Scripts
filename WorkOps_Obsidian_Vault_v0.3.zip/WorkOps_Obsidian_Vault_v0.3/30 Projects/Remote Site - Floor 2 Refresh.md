---
type: project
status: active
priority: medium
health: good
site: "[[10 Sites/Remote Site|Remote Site]]"
program:
location: "Floor 2 / IDF"
parent_project:
started: 2026-10-15
target: 2026-11-18
area: [network]
---
# Remote Site - Floor 2 Refresh

## Project controls
**Status:** `INPUT[inlineSelect(option(active, Active),option(waiting, Waiting),option(blocked, Blocked),option(complete, Complete),option(archived, Archived)):status]`  
**Priority:** `INPUT[inlineSelect(option(high, High),option(medium, Medium),option(low, Low)):priority]`  
**Health:** `INPUT[inlineSelect(option(good, Good),option(watch, Watch),option(at-risk, At Risk)):health]`

## Tasks
- [ ] Confirm port count 📅 2026-11-02
- [ ] Build migration plan 📅 2026-11-05
- [ ] Confirm change window 📅 2026-11-09
