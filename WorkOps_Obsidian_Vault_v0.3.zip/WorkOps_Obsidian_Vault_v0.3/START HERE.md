---
type: guide
version: "0.3"
status: active
cssclasses:
  - workops-dashboard
---
# WorkOps Vault v0.3

> [!success] Workbench release
> V0.3 keeps the Site / Program / Project / Workstream model from V0.2, then adds the visual and interactive layer: a central Operations Workbench, plugin-driven live metrics, fast capture, daily routines, schedule, and sidebar calendar workflow.

## Start here

1. [[00 Command Center/V0.3 Setup Guide|V0.3 Setup Guide]]
2. [[00 Command Center/Plugin Stack|Install / configure the plugin stack]]
3. [[00 Command Center/Work Command Center|Open the Operations Workbench]]
4. [[00 Command Center/QuickAdd Setup|Configure Quick Capture]]
5. [[50 Reference/Workbench Visual Direction|See the visual reference]]

## Mental model

```text
Site ─────────────┐
                  ├─ Project ─ Tasks
Program ──────────┘     │
                        ├─ Workstream / child project
                        ├─ Meetings
                        ├─ Issues
                        ├─ Changes
                        └─ Decisions

Daily Note = chronological scratchpad / operations log
Archive    = lifecycle, not deletion
Workbench  = the live view across all of it
```

## Demo tour

- [[10 Sites/Main Campus|Main Campus]]
- [[20 Programs/Program Alpha|Program Alpha]]
- [[30 Projects/Program Alpha - 100 User Expansion|100 User Expansion]]
- [[30 Projects/100 User Expansion - Fiber Workstream|Fiber Workstream]]
- [[01 Daily/2026/2026-10-28|Demo Daily Note]]
- [[00 Command Center/Archive Center|Archive Center]]

> [!important] Data handling
> Demo data is fictional. Only put real work data in storage/sync locations approved for your environment.
