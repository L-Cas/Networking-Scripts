---
type: project
status: archived
priority: low
health: good
site: "[[10 Sites/Main Campus|Main Campus]]"
program:
location: "Building 1 / Lab"
archived: 2026-08-21
archive_reason: completed
---
# Example - Retired Pilot

Fictional archived project demonstrating preserved history without cluttering active dashboards.
