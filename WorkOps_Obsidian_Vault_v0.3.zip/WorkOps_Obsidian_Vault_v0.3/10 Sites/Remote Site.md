---
type: site
status: active
site_class: remote
priority: medium
---
# Remote Site

Fictional example: one main building organized mostly by floors and rooms.

Examples of `location`:
- `Floor 1 / Room 112`
- `Floor 2 / IDF`
- `Floor 3 / MDF`

## Projects
```base
filters:
  and:
    - 'type == "project"'
    - 'site == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Projects
    order: [file.name, location, status, priority, target]
```
