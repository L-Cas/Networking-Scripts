---
type: site
status: active
site_class: campus
priority: high
---
# Main Campus

Fictional example: three large buildings plus smaller buildings.

## Location convention
Keep physical detail human-readable:

```yaml
site: "[[10 Sites/Main Campus|Main Campus]]"
location: "Building 3 / Room 214"
```

Do not create building/floor/room properties until you actually need to query them independently.

## Projects
```base
filters:
  and:
    - 'type == "project"'
    - 'site == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Projects
    order: [file.name, program, location, status, priority, target]
```
