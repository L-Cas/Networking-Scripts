---
type: reference
status: active
---
# When Does a Task Become a Workstream?

Keep a checkbox when the work is mostly one action and easy to understand from one line.

Promote it when it gains several of these:
- multiple actions
- waiting/dependencies
- vendor coordination
- quote/funding
- design decisions
- meetings
- multiple dates
- risk
- installation
- validation
- durable documentation

Example: `Get fiber quote` → [[30 Projects/100 User Expansion - Fiber Workstream|Fiber Workstream]].
