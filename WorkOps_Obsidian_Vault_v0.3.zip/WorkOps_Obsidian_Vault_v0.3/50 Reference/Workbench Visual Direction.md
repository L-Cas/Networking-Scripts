---
type: reference
status: active
---
# Workbench Visual Direction

This screenshot is the visual north star for V0.3:

![[70 Attachments/Workbench Inspiration.png]]

## What we borrowed conceptually

- large central work surface
- one dominant current-focus card
- schedule beside focus rather than below it
- priorities and daily recurring checks as separate concepts
- compact operational metrics
- quick capture always visible
- recent activity at the bottom
- navigation/calendar pushed to sidebars

## What we intentionally changed

The original is oriented around content production metrics. WorkOps translates that into:

- active projects
- waiting / blocked work
- issues
- open changes
- upcoming task load
- Sites / Programs / Projects
- operations history

The dashboard should answer two questions quickly:

1. **What matters right now?**
2. **What is happening around me that I shouldn't forget?**
