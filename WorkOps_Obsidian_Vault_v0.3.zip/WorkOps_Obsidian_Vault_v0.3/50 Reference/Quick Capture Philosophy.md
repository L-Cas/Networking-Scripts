---
type: reference
status: active
---
# Quick Capture Philosophy

Default destination: **Daily Note → Operations Log**.

Use it for hallway conversations, temporary observations, reminders, troubleshooting breadcrumbs, and anything that otherwise lands on scrap paper.

Promote to:
- **Task** when action is needed.
- **Issue** when investigation/ownership/history matters.
- **Project** when an outcome requires coordinated actions.
- **Workstream** when part of a project develops its own timeline/dependencies.
- **Decision** when future-you may ask why.
- **Activity** when an accomplishment deserves later visibility.
