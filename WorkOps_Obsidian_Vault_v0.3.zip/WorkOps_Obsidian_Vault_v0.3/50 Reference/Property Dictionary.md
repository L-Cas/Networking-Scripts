---
type: reference
status: active
---
# Property Dictionary

> [!important] Rule
> Only create a property when you expect to **filter, group, calculate, or automate** against it.

| Property | Purpose |
|---|---|
| `type` | record class |
| `status` | lifecycle |
| `site` | physical support context |
| `program` | supported program context |
| `priority` | attention level |
| `target` | target completion |
| `parent_project` | child workstream relationship |
| `location` | optional human-readable physical detail |

## Location
Good:
```yaml
site: "[[Main Campus]]"
location: "Building 3 / Room 214"
```

Do not add `building`, `floor`, `room`, `closet`, or `wing` by default. Promote one later only if repeated queries prove you need it.
