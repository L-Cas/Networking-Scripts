---
type: program
status: active
priority: high
sites:
  - "[[10 Sites/Main Campus|Main Campus]]"
---
# Program Alpha

Fictional supported program at [[10 Sites/Main Campus|Main Campus]].

## Projects
```base
filters:
  and:
    - 'type == "project"'
    - 'program == this.file.asLink()'
    - 'status != "archived"'
views:
  - type: table
    name: Projects
    order: [file.name, site, location, status, priority, target]
```

## Program tasks
- [ ] Confirm expansion headcount 📅 2026-11-02
- [ ] Review capacity risks 📅 2026-11-04
