---
type: meeting
project: "[[Richmond Site Standup]]"
date: 2026-11-03
---
# Richmond Coordination — November 3

**Context:** Provider installation delay. Router is available before circuit readiness.

**Decision:** Wait for confirmed circuit handoff, not just physical installation.

**Action source:** [[Circuit Install]] owns the provider follow-up, and [[Router Install]] owns WAN notification. No duplicate tasks here.
