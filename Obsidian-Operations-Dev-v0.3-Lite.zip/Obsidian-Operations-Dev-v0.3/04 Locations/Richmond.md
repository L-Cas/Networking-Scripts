---
type: location
site: Richmond
---
# Richmond

Fictional site contact card. Keep location notes lightweight and reusable.

- Building: Example New Facility
- Provider: Example circuit provider
- Important: contact names and circuit identifiers intentionally omitted.
