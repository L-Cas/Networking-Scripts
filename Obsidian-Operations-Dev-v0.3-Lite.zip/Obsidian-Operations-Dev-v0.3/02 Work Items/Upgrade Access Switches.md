---
Type: Task
Status: Project.Planned
operonId: r3upg34
note_kind: work-item
location: "Building A (fictional)"
---
# Upgrade Access Switches

**Standalone operational work item** — no parent project is required. Update a handful of access switches after a maintenance window is agreed upon.

## Quick checklist

- [x] Identify candidate devices
- [ ] Agree on maintenance window
- [ ] Back up configurations
- [ ] Perform upgrades and validate uplinks

## Track one follow-up

- [ ] Confirm a maintenance window with site contact {{operonId:: r3win87}} {{parentTask:: r3upg34}} {{dateScheduled:: 2026-11-09}}

> [!note] Date example
> This is a **planned follow-up day**, not an approved change window. Do not put unconfirmed technician visits into a hard event field.
