# v0.3 — 10-minute test walkthrough

Use the **fictional Richmond case**. Take notes on what breaks or takes too many clicks.

- [ ] Install Operon and confirm its commands load.
- [ ] Open [[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond]] and verify **Richmond Notes.base** shows only Richmond project notes.
- [ ] Open [[03 Projects/Richmond Site Standup/Circuit Install|Circuit Install]] and inspect both the ordinary checklist and two tracked Operon subtasks.
- [ ] Open [[03 Projects/Richmond Site Standup/Router Install|Router Install]]. Inspect **Notify WAN team** in Operon; verify `Blocked By` points to handoff.
- [ ] Build one **Richmond — Work** folder filter in Operon. Confirm unrelated [[02 Work Items/Upgrade Access Switches|Upgrade Access Switches]] and [[03 Projects/Small Campus Cleanup/Validate Closet Documentation|Small Campus Cleanup]] do not appear.
- [ ] Reuse that saved filter in Operon's Calendar (only dated Richmond tasks should appear).
- [ ] Mark **Confirm circuit handoff is ready** complete. Examine what Operon shows in *Notify WAN team*—especially whether it warns you on its own or merely updates relationship state. **Do not assume a persistent review queue exists**.
- [ ] Convert one local checkbox into a tracked inline task using Operon's command.
- [ ] Create a note in Richmond using Ctrl+N and insert a template. Confirm it lands in Richmond's folder.
- [ ] Open [[01 Capture/Scratchpad|Scratchpad]], create one new note, then move the original into Richmond using Obsidian's native move command.

## Usability feedback

**First moment of friction:**

**Clicks needed to create a project task:**

**Could I tell which task became unblocked?**

**Did I remember to revisit the dependent task?**

**Did Richmond-only views stay scoped?**

**What should remain native to Operon versus Obsidian?**
