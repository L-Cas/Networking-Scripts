# Operon setup & project scopes

This is deliberately the **only required task plugin** in v0.3.

## Install / confirm

1. Use Obsidian **1.13.7+**. Go to Community plugins → Browse → **Operon**, Install, Enable.
2. Press `Ctrl+P` and look for **Create or edit inline task**, **Create file task**, and **Operon Filter View**.
3. Open [[03 Projects/Richmond Site Standup/Circuit Install|Circuit Install]] and [[03 Projects/Richmond Site Standup/Router Install|Router Install]]. Their pre-populated `operonId` fields are fixed, unique 7-character demo IDs. **Do not copy IDs into new tasks.**
4. For a new task, use Operon's task creator or run **Create or edit inline task** on an ordinary checkbox to let Operon generate its ID.

## Make the Richmond-only filter (about 1–2 minutes)

1. Press `Ctrl+P` → **Operon Filter View**.
2. In the filter builder, add **Folder → is in folder tree** → `03 Projects/Richmond Site Standup`.
3. Save it as **Richmond — Work**. You should see tracked actions from *Circuit Install* and *Router Install*, and **not** the standalone switch upgrade or the Small Campus Cleanup task.
4. Use the saved filter's **Copy embed code** action. Paste its generated `operon` code block under *Project-specific Operon task view* in [[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond's project note]]. Never invent a filterId.
5. In Operon's **Calendar**, create a preset that uses the saved Richmond filter. Switch to All Work using the unfiltered view or a separate preset. This is an Operon UI setup step, **not preconfigured** by the ZIP.

> [!important] Note index versus task list
> The embedded **Richmond Notes.base** uses native Obsidian Bases to show **project files** (including ordinary records). Operon's Richmond filter shows **tracked tasks**. They are complementary, not duplicate sources of truth.

## Native relationships to verify

- In Circuit Install, **Confirm circuit handoff is ready** is a tracked inline subtask.
- In Router Install, **Notify WAN team** has `blockedBy` pointing at that handoff task; the later *configuration window* action waits on WAN notification.
- Open their **Operon Task Editors** to verify that `Blocked By / Blocking` relationships are recognized. If your plugin version doesn't read the prefilled inline relationship exactly, **use Operon's Task Editor picker** to set it manually; record this in your test notes.
- Completing handoff is not supposed to silently mark WAN notification complete or start scheduling. This demo intentionally leaves the follow-up for your decision.

## Dates

| Meaning | v0.3 approach |
| --- | --- |
| Plan to revisit a question | `dateScheduled` on an Operon follow-up task |
| Firm task deadline | `dateDue` only if real |
| Confirmed calendar appointment | Use Operon's Calendar / timed task fields once confirmed |
| Vendor estimate | Plain note `estimated_window`, not a fake `dateDue` |
| Unknown date | Leave date blank; task stays visible in Filter View |

## Optional next step (not required)

Use **Operon Create File Task** or **Edit/convert to file task** if an inline action grows into a full tasking note. Plain Markdown checkboxes should stay plain for quick local steps. Do not convert every checklist item.

**Documentation:** [Operon Getting started](https://operon.cc/docs/docs-003-getting-started-with-operon/), [inline tasks](https://operon.cc/docs/docs-011-inline-tasks/), [file tasks](https://operon.cc/docs/docs-013-file-tasks/), [dependencies](https://operon.cc/docs/docs-069-task-link-and-list-pickers/), [saved filters](https://operon.cc/docs/docs-010-build-your-first-filtered-view/), [filter embed](https://operon.cc/docs/docs-083-embed-a-filter-in-a-note/).
