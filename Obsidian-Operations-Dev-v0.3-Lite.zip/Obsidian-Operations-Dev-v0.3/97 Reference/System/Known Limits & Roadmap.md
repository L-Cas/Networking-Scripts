# Known limits & next experiments

## Implemented in the vault

- Preserved folder hierarchy.
- Minimal Richmond scenario + unrelated work to test project scoping.
- Real Operon-style file task frontmatter and inline `operonId` syntax with example `parentTask` and `blockedBy` relationships.
- Native Obsidian Bases project and folder views; plain note navigation and Templates.
- Soft date context kept separate from tracked scheduled task and due dates.

## Not implemented (avoid false confidence)

- **Persistent Review & Release queue**, independent project-hold inheritance, and automatic downstream alert after prerequisite completion.
- **One-click creation from selected project template** (Ctrl+N puts a note in current folder, but inserting a template remains a second action).
- Preconfigured Operon saved filter, calendar presets, or embedded Operon table. Operon stores these in plugin data; create them once using its UI.
- Global cross-project event conflict detection.
- Capture-to-project triage automation and daily note workflows.
- External Microsoft integrations.

## What we're actually testing

1. Are Operon's native task editing and dependency views good enough to justify their complexity?
2. Does scoped Filter → Calendar → embed solve local-versus-global overwhelm?
3. Is it more natural to use markdown notes with a few tracked tasks than treating every note as a task?
4. Would adding QuickAdd afterward solve a real bottleneck rather than create another setup dependency?
