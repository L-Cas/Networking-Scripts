# Changelog

## v0.3 Lite — Operon evaluation

- Rebuilt as a **new standalone dev vault**, not a conversion of user production data.
- Kept exactly the preferred folder hierarchy.
- Reduced example work to Richmond, one tiny secondary project, one standalone work item, one loose capture, and one meeting.
- Removed v0.2 custom Operations Workspace plugin. No bespoke JavaScript/task engine.
- Added Operon-compatible example file tasks and tracked inline actions, with a dependency chain focused on circuit handoff.
- Added native Bases view directly inside Richmond project note, plus focused README, plugin registry, test walkthrough, and known limitations.
- Deferred mandatory daily notes, automated captures, Review & Release queue, and expanded dashboard features.
