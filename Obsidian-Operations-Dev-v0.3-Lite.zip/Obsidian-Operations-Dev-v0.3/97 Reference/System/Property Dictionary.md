# Property Dictionary

| Property | Scope | Purpose |
| --- | --- | --- |
| `type` | Ordinary notes / vault organization | `project`, `meeting`, `vendor-update`, `location`, `capture`; plain templates can also use `tasking` / `work-item` |
| `project` | Linked notes | Obsidian wiki-link to the containing project, helpful for cross-reference |
| `status` | Main project notes | Human project summary: On Hold, Active, etc. Does not control Operon children |
| `target_window`, `estimated_window` | Context notes | Human **soft** estimate, not a firm event / calendar date |
| `note_kind` | Operon file tasks | `tasking` or `work-item`, keeping it separate from Operon’s `Type: Task` |
| `Type: Task` | Operon file tasks | Recognized Operon task shape |
| `Status` | Operon file tasks | Operon pipeline status (e.g. `Project.Planned`) |
| `operonId` | Operon tasks | Stable unique identity; **never manually reuse on new work** |
| `parentTask` | Operon subtask | Points to another task ID, for hierarchy |
| `blockedBy` | Operon task | IDs of prerequisite tasks; inverse relationship maintained by Operon |
| `dateScheduled` | Operon task | Your planned action date (or scheduled task); not an external estimate |
| `dateDue` | Operon task | Actual deadline when one exists |

Ordinary Markdown checkboxes do **not** appear in Operon's task filters, because they lack `operonId`. Use Operon's **Create or edit inline task** command to promote only those that need tracking.
