# Plugin Registry — v0.3

| Plugin / component | Source | Required? | Purpose | Status |
| --- | --- | --- | --- | --- |
| **Operon** (`operon`) | Community Plugins | **Yes; user installs** | Inline/file tasks, parent–child, blocking, Filter, Calendar | Designed against public docs; test in Obsidian |
| **Bases** | Obsidian core | Yes | Live folder-scoped note index; project list | Config files validated, runtime untested |
| **Templates** | Obsidian core | Yes | Lightweight note templates | Included, runtime untested |
| **CSS snippets** | Obsidian built-in | Optional | Readability | `operations-clean.css` |
| QuickAdd | Community Plugins | Not installed | Possible one-click project template creation | Deferred until basic experience validated |
| v0.2 Operations Workspace | Custom plugin | **Removed** | No competing task engine | Not included |
| Dataview / Tasks / TaskNotes | Community Plugins | **Not included** | Avoid overlapping task engines | Not included |

**Plugin code is not shipped.** Obsidian must download Operon through Community Plugins. Confirm local IT policy before using any new plugin at work; demo data are fabricated.

**Version note:** Operon's documentation currently specifies Obsidian 1.13.7+; keep plugin updates under test rather than assuming stable UI/settings across major versions.
