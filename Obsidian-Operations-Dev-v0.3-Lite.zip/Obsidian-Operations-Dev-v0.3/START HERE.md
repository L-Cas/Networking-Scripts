---
cssclasses:
  - ops-home
---
# Obsidian Operations — v0.3 Lite

> [!important] Development vault — fictional examples only
> This is a **small Operon evaluation**, not a finished project-management system. Nothing here requires a custom dashboard plugin. Do not import restricted workplace information into a personal test vault.

## 5-minute setup

1. Unzip, then **Open folder as vault** in Obsidian. Keep this separate from v0.2 and your working vault.
2. Verify Obsidian is **1.13.7 or newer**. In **Settings → Community plugins → Browse**, install and enable **Operon** (plugin id `operon`). The plugin is **not included** in the ZIP. Let its first-run setup finish.
3. Enable Obsidian core **Bases** and **Templates** if needed. In **Settings → Appearance → CSS snippets**, enable `operations-clean` if it is not already on.
4. Open [[00 Dashboard/Home|Home]], then [[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond]]. Read the short [[97 Reference/System/Operon Setup & Scope|Operon Setup & Scope]] to make *one* native Operon saved filter for Richmond.
5. Open [[03 Projects/Richmond Site Standup/Circuit Install|Circuit Install]], locate its tracked **Confirm circuit handoff ready** task, then compare the **Notify WAN team** task in [[03 Projects/Richmond Site Standup/Router Install|Router Install]].

> [!note] What is deliberately **not** automatic
> Operon natively tracks dependencies, but **our proposed persistent Review & Release queue and project-hold inheritance are not implemented** in this lite demo. Completing a prerequisite is a hands-on test of Operon's behavior, not proof that it will generate our desired review alert.

## Navigation

[[00 Dashboard/Home|Dashboard]] · [[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond project]] · [[00 Dashboard/Projects|Projects]] · [[01 Capture/Scratchpad|Scratchpad]] · [[97 Reference/System/Test Walkthrough|10-minute test]]

## What's in the box

One realistic Richmond circuit project with two tasking notes and one vendor record; one small independent project; one standalone work item; one scratchpad; one meeting; small templates and a plugin registry. No extra fake task backlog.

## Help / troubleshooting

- **Operon missing?** Install it from Community Plugins. Its commands won't exist until it is enabled.
- **Task list empty?** Operon indexes tasks with an `operonId`; plain checkboxes are local only. See [[97 Reference/System/Operon Setup & Scope]].
- **Project calendar isn't preconfigured?** Create an Operon filter/preset using the setup guide. No fabricated preset IDs are bundled.
- **Want a new note in the same project folder?** Open the project note and use Ctrl+N; the vault defaults new notes to the active note's folder. Insert a core template using the Command palette → **Templates: Insert template**.
- **No automatic daily log?** By design.
