---
type: capture
---
# Scratchpad

Type immediately. No required template, project, date, or status.

## Loose thoughts

- Ask whether spare optics arrived for the next closet refresh.
- A provider callback might require a new follow-up in Richmond.

> [!tip] Triage later
> Move the **original note** to its project or `02 Work Items` when you're ready. You can convert a useful checkbox into an Operon task at that point. Capture should not become a permanent duplicate pile.
