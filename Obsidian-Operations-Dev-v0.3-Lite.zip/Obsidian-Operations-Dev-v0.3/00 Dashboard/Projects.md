---
cssclasses:
  - ops-home
---
# Projects

![[00 Dashboard/Projects.base#Projects]]

Open a project note to work there; the table is an index, not a second task list.

[[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond Site Standup]] · [[03 Projects/Small Campus Cleanup/Small Campus Cleanup|Small Campus Cleanup]]
