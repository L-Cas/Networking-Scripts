# Daily Operations

- [ ] Check incoming tickets and urgent messages
- [ ] Review upcoming work and follow-ups
- [ ] Review blockers on active projects

> [!note] Simple demo checklist
> These checkboxes **do not reset themselves**. No daily-notes implementation in v0.3. Keep or ignore this note during the plugin trial.
