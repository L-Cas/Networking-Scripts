---
cssclasses:
  - ops-home
---
# Operations

> [!info] Start where the work lives
> **[[03 Projects/Richmond Site Standup/Richmond Site Standup|Open Richmond Site Standup]]** · [[02 Work Items/Upgrade Access Switches|Standalone switch upgrade]] · [[01 Capture/Scratchpad|Scratchpad]]

## Projects

![[00 Dashboard/Projects.base#Projects]]

## Focus

> [!warning] Richmond — test the handoff
> The provider handoff is pending in [[03 Projects/Richmond Site Standup/Circuit Install|Circuit Install]]. [[03 Projects/Richmond Site Standup/Router Install|Router Install]] has a downstream **Notify WAN team** task. This is explanatory demo text, **not** an automatically updating alert.

## Work views

[[00 Dashboard/Operon Views|Operon lists & calendar]] · [[00 Dashboard/Daily Operations|Daily Operations]] · [[00 Dashboard/Projects|Projects]]

> [!tip] Avoid the clutter
> Use Richmond's own project note for Richmond records. In Operon, create a saved filter where **Folder → is in folder tree → 03 Projects/Richmond Site Standup**, then reuse it for its Filter / Calendar views. Instructions: [[97 Reference/System/Operon Setup & Scope]].
