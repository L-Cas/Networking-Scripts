---
cssclasses:
  - ops-home
---
# Operon — Work & Calendar

**This note links to native Operon views.** We don't maintain another calendar database or run a custom dashboard script.

### One-time setup

Use [[97 Reference/System/Operon Setup & Scope|Operon Setup & Scope]] to create a saved **Richmond** filter and connect it to a Calendar preset. After that, you can switch between Richmond and All Work inside Operon.

From the Obsidian Command palette (`Ctrl+P`), open:

- **Operon Filter View** — all tracked tasks, or your saved Richmond filter.
- **Operon Calendar** — due / scheduled Operon tasks. Choose the project-filtered preset you create.
- **Operon Table** — optional, only if you find it easier to edit than the Filter View.

An Operon filter can be embedded into any note by using **Copy embed code** on the saved filter. Paste the resulting `operon` code block inside [[03 Projects/Richmond Site Standup/Richmond Site Standup|Richmond]]; don't invent a `filterId`.

> [!note] Dates in the demo
> The provider's **tentative** installation window is kept as plain context, not a fake calendar commitment. The follow-up task has a `dateScheduled` value, meaning *when you intend to do the follow-up*, not when Verizon promised to finish.
