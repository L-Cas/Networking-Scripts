---
type: project
status: Active
cssclasses:
  - ops-project
---
# Small Campus Cleanup

Small unrelated project used **only** to check that Richmond project views do not show everything in the vault.

- [[Validate Closet Documentation]]

[[00 Dashboard/Projects|← Projects]]
