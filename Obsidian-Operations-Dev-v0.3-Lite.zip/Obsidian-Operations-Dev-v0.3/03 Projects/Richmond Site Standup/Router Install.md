---
Type: Task
Status: Project.Planned
operonId: r3rou93
note_kind: tasking
project: "[[Richmond Site Standup]]"
location: "[[Richmond]]"
---
# Router Install

## Current situation

The router was handed over early to align with the original circuit timeline. Configuration/deployment cannot be scheduled as final until the provider **confirms the circuit is ready for handoff**.

## Unblocked preparation (plain checklist)

- [x] Receive loaner router
- [ ] Confirm rack space and power
- [ ] Verify equipment inventory and replacement plan

## Tracked follow-on actions

- [ ] **Notify WAN team of confirmed circuit handoff** {{operonId:: r3not25}} {{parentTask:: r3rou93}} {{blockedBy:: r3han41}}
- [ ] Agree on a router configuration window {{operonId:: r3cfg52}} {{parentTask:: r3rou93}} {{blockedBy:: r3not25}}

> [!tip] Why these are tracked
> Unlike rack-space checks, the two follow-ons have their own IDs and dependencies. Operon can show these in its Filter, Calendar, and relationship editor. Keep the router tasking note itself **Planned** until you choose another status.

## Updates

- Equipment is present; provider handoff not confirmed.

[[Circuit Install|Circuit dependency]] · [[Richmond Site Standup|← Richmond project]]
