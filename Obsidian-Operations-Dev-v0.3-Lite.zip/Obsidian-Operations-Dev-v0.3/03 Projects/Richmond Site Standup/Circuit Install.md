---
Type: Task
Status: Project.InProgress
operonId: r3cir72
note_kind: tasking
project: "[[Richmond Site Standup]]"
location: "[[Richmond]]"
estimated_window: "Nov 20 originally — delayed; revised window unknown"
---
# Circuit Install

**Owner of this note:** provider coordination and the real readiness/handoff milestone.

## Current situation

Circuit installation was expected around Nov 20. The vendor reported a delay. We have **not** been handed an operational circuit yet. The team's router activity must wait for a confirmed handoff, not merely a report that the physical work is done.

## Local checklist (not individually tracked)

- [x] Original installation estimate received
- [x] Router team informed of early equipment handoff
- [ ] Provider physical installation complete
- [ ] Confirm provider testing results

## Tracked actions (Operon)

- [ ] Follow up with provider about revised handoff window {{operonId:: r3pro86}} {{parentTask:: r3cir72}} {{dateScheduled:: 2026-11-06}}
- [ ] **Confirm circuit handoff is ready** {{operonId:: r3han41}} {{parentTask:: r3cir72}}

> [!important] Dependency to inspect
> **Confirm circuit handoff is ready** is the prerequisite for **Notify WAN team** in [[Router Install]]. This is an Operon tracked action with its own stable ID; a plain checkbox cannot serve as a precise cross-note dependency.

## Updates

- 2026-11-03 — Provider indicated delay; updated delivery window unknown. [[2026-11-03 Provider Update]].

## Next step when handoff arrives

1. Open or edit the **Confirm circuit handoff is ready** tracked task in Operon and complete it.
2. Open [[Router Install]] and inspect the downstream **Notify WAN team** task (see `Blocked by`).
3. **Review manually** whether to proceed; persistent Review & Release notices are not supplied by this demo.

[[Richmond Site Standup|← Richmond project]]
