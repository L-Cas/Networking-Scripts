---
type: project
status: On Hold
location: "[[Richmond]]"
target_window: "Late November — tentative"
cssclasses:
  - ops-project
---
# Richmond Site Standup

> [!warning] Current situation — fictional scenario
> New building deployment is **on hold pending circuit handoff**. The loaner router was delivered earlier to prepare for the original schedule. Physical installation and final provider handoff are distinct milestones. No fixed replacement date has been confirmed.

## Taskings

- **[[Circuit Install]]** — coordinate provider, validate circuit, confirm handoff.
- **[[Router Install]]** — router on hand; WAN team must be notified **once handoff is confirmed**.

## Related notes — live project-only index

![[Richmond Notes.base#Notes]]

## Project actions & decision context

- No need to change every child task to `Blocked` just because the project is on hold.
- Provider's estimated dates are **soft information**, not a due date.
- The separately tracked *Confirm circuit handoff ready* action is the **specific prerequisite** for *Notify WAN team*.

## Project-specific Operon task view

> [!tip] Native Operon embed — one-time setup
> Create a saved Operon Filter with condition **Folder → is in folder tree → `03 Projects/Richmond Site Standup`**. Choose **Copy embed code** and paste the `operon` block **below this callout**. That is a native live task view; its filter ID must come from Operon. The folder Bases table above already works without this step.

## Activity / decisions

- 2026-11-03 — Provider delay noted. Keep replacement estimate unconfirmed. See [[2026-11-03 Provider Update]].
- Router supplied early; configuration scheduling still needs handoff readiness.

## Navigation

[[00 Dashboard/Home|Home]] · [[00 Dashboard/Operon Views|Work & Calendar]] · [[97 Reference/System/Test Walkthrough|Test scenario]]
