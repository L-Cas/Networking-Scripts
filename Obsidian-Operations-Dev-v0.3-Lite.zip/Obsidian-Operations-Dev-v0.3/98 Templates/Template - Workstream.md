---
type: tasking
---
# New Tasking

## Current situation

## Local steps

- [ ]

## Tracked actions

Write an ordinary checkbox first. Run **Operon: Create or edit inline task** on it when it needs a date, dependency, or global visibility.

## Updates
