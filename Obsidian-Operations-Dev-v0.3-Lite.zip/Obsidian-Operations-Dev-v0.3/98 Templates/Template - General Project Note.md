---
type: project-note
---
# New Note

## Notes

Start typing here. Add context or actions later, only as needed.

## Optional actions

- [ ]
