---
type: project
status: Planning
---
# New Project

## Current situation

## Key taskings

## Dependencies and decisions

## Updates
