---
type: work-item
---
# Standalone Work Item

## Objective

## Local steps

- [ ]

## Updates

When this needs global visibility, convert the note to an **Operon File Task** via its command. Keep it in `02 Work Items`.
