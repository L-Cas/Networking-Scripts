---
type: bom
---
# New BOM / Procurement

## Scope and requirements

## Open vendor questions

## Quotes / revisions

## Deliveries / estimates

## Actions (local or promote with Operon)

- [ ]

## Activity log
