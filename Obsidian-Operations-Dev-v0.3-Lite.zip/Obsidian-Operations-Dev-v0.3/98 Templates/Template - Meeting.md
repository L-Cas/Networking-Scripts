---
type: meeting
date: "{{date:YYYY-MM-DD}}"
---
# Meeting Notes

## Raw notes

## Decisions

## Follow-ups / places to file them
