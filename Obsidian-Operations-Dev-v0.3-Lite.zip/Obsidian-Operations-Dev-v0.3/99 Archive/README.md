# Archive

Move completed projects (whole folders) or standalone work items here when you choose. Nothing auto-archives.
