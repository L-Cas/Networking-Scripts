---
type: guide
version: "0.2"
status: active
cssclasses: [workops-dashboard]
---
# WorkOps Vault v0.2

> [!success] What V0.2 is
> A fictional demo of a work vault built around **fast Daily Operations**, flexible **Sites + Programs**, outcome-oriented **Projects**, optional **child Workstreams**, global **Tasks**, durable operational records, and an **Archive** instead of deletion.

## Mental model

```text
Site ─────────────┐
                  ├─ Project ─ Tasks
Program ──────────┘     │
                        ├─ Workstream / child project
                        ├─ Meetings
                        ├─ Issues
                        ├─ Changes
                        └─ Decisions

Daily Note = chronological scratchpad / operations log
Archive    = lifecycle, not deletion
```

## First tour

1. [[00 Command Center/Work Command Center|Work Command Center]]
2. [[10 Sites/Main Campus|Main Campus]]
3. [[20 Programs/Program Alpha|Program Alpha]]
4. [[30 Projects/Program Alpha - 100 User Expansion|100 User Expansion]]
5. [[30 Projects/100 User Expansion - Fiber Workstream|Fiber Workstream]]
6. [[01 Daily/2026/2026-10-28|Demo Daily Note]]
7. [[00 Command Center/Archive Center|Archive Center]]
8. [[00 Command Center/V0.2 Setup Guide|Setup Guide]]

> [!important] Data handling
> Demo data is fictional. Only put real work data in storage/sync locations approved for your environment.
