---
type: daily
date: {{date:YYYY-MM-DD}}
week:
focus:
---
# {{date:dddd, YYYY-MM-DD}}

## Top 3
- [ ] 
- [ ] 
- [ ] 

## Schedule

## Operations Log
**{{time:HH:mm}}** — 

## Tasks
- [ ] 

## Waiting

## Meetings

## Decisions

## End of Day
### Accomplished
- 
### Carry forward
-
