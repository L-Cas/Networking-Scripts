---
type: dashboard
status: active
cssclasses: [workops-dashboard]
---
# 🛰 Work Command Center

> [!ops] Main hub
> [[01 Daily/2026/2026-10-28|Daily Operations]] · [[00 Command Center/Task Center|Tasks]] · [[00 Command Center/Archive Center|Archive]] · [[00 Command Center/Weekly Review|Weekly Review]] · [[00 Command Center/V0.2 Setup Guide|Setup]]

## ⚡ Quick Actions

> [!tip] Requires Meta Bind + Templater
> These buttons create notes from the templates in `90 Templates`. Without those plugins, the vault still works normally.

`BUTTON[new-project,new-meeting,new-issue,new-change,new-decision,quick-note]`

```meta-bind-button
style: primary
label: + Project
id: new-project
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Project Template.md"
  folderPath: "30 Projects"
  fileName: "New Project - RENAME ME"
  openNote: true
```

```meta-bind-button
style: default
label: + Meeting
id: new-meeting
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Meeting Template.md"
  folderPath: "40 Operations/Meetings"
  fileName: "New Meeting - RENAME ME"
  openNote: true
```

```meta-bind-button
style: default
label: + Issue
id: new-issue
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Issue Template.md"
  folderPath: "40 Operations/Issues"
  fileName: "New Issue - RENAME ME"
  openNote: true
```

```meta-bind-button
style: default
label: + Change
id: new-change
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Change Template.md"
  folderPath: "40 Operations/Changes"
  fileName: "New Change - RENAME ME"
  openNote: true
```

```meta-bind-button
style: default
label: + Decision
id: new-decision
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Decision Template.md"
  folderPath: "40 Operations/Decisions"
  fileName: "New Decision - RENAME ME"
  openNote: true
```

```meta-bind-button
style: default
label: + Quick Note
id: quick-note
hidden: true
action:
  type: templaterCreateNote
  templateFile: "90 Templates/Quick Note Template.md"
  folderPath: "50 Reference/Quick Notes"
  fileName: "Quick Note - RENAME ME"
  openNote: true
```

## ✅ Today / Overdue
```tasks
not done
due before tomorrow
sort by priority
sort by due
limit 30
```

## 🧭 Sites
![[80 Bases/Sites.base#Active]]

## 🏷 Programs
![[80 Bases/Programs.base#Active]]

## 🚧 Active Projects
![[80 Bases/Projects.base#Active]]

## ⏸ Waiting / Blocked
![[80 Bases/Projects.base#Waiting and Blocked]]

## 🧩 Workstreams
![[80 Bases/Projects.base#Workstreams]]

## ⚠ Issues
![[80 Bases/Operations.base#Open Issues]]

## 🛠 Changes
![[80 Bases/Operations.base#Open Changes]]

## 📝 Decisions
![[80 Bases/Operations.base#Recent Decisions]]

## 📡 Significant Activity
![[80 Bases/Activity.base#Recent]]

> [!abstract] Capture rule
> If it would otherwise go on a sticky note, scrap paper, or temporary Notepad window, put it in the **Daily Operations Log** first. Promote it later only if it earns structure.
