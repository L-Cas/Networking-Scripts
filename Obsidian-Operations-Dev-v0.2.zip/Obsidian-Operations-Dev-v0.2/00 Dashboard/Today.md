---
cssclasses:
  - ops-dashboard
---
# Today & Follow-ups

Use **Overview** below for due and upcoming follow-ups. The Work tab provides editable tasking statuses.

```ops-view
scope: all
view: overview
```
