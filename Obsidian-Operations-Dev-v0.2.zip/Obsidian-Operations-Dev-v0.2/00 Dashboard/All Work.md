---
cssclasses:
  - ops-dashboard
---
# All Work

```ops-view
scope: all
view: work
```

[[00 Dashboard/Home|Home]] · [[00 Dashboard/Calendar|Calendar]]
