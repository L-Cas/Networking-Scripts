---
cssclasses:
  - ops-dashboard
---
# Operations

> [!tip] Project-first workspace
> Choose a project in the view below, then switch between **Overview**, **Work**, **Calendar**, and **Records**. The same view is embedded in each project note. Use **+ New** to create a templated note in the selected project.

```ops-view
scope: all
view: overview
```

## Quick navigation

[[00 Dashboard/Daily Operations|Daily Operations]] · [[01 Capture/Scratchpad|Scratchpad]] · [[00 Dashboard/All Work|All Work]] · [[00 Dashboard/Calendar|Full Calendar]] · [[03 Projects/Projects.base|Project Database]]

> [!note] Getting started
> Enable the included **Operations Workspace (v0.2 Prototype)** community plugin and the **operations-dashboard** CSS snippet. See [[START HERE]] before using this in a real vault.
