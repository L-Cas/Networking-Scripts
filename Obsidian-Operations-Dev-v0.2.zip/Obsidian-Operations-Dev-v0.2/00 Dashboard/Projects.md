---
cssclasses:
  - ops-dashboard
---
# Projects

```ops-view
scope: all
view: overview
```

[[03 Projects/Projects.base|Project database]]
