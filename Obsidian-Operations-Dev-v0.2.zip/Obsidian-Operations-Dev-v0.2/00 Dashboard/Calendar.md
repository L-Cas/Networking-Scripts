---
cssclasses:
  - ops-dashboard
---
# Calendar — All Projects

```ops-view
scope: all
view: calendar
```

Only explicit `due`, `follow_up`, and `scheduled` dates on tracked tasking notes appear here. Tentative delivery windows remain narrative context.
