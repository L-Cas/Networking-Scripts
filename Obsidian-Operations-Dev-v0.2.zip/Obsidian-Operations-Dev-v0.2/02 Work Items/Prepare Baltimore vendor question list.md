---
type: work-item
status: Open
priority: Normal
date: 2026-10-29
project: '[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]'
location: '[[04 Locations/Baltimore]]'
created: 2026-10-29
---

# Prepare Baltimore vendor question list

- [ ] Confirm optics
- [ ] Confirm delivery dock timing
- [ ] Confirm shipment tracking contact
