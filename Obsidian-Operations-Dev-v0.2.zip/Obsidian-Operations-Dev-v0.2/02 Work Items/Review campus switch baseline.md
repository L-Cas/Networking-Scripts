---
type: work-item
status: Open
priority: High
date: 2026-10-30
project: '[[03 Projects/Campus Switch Refresh/Campus Switch Refresh]]'
source: '[[05 Meetings/Cybersecurity Sync/2026-10-28 - Cybersecurity Sync]]'
created: 2026-10-28
---

# Review campus switch baseline

Validate the fictional baseline before the next deployment.
