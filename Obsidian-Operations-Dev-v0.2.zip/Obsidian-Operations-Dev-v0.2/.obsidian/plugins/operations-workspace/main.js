const { Plugin, Modal, Notice, MarkdownRenderChild } = require('obsidian');
const TYPES = ['General','Tasking','BOM','Vendor Update','Meeting','Troubleshooting'];
const STATES = ['Open','In Progress','Waiting','Blocked','Complete'];
const PREFIX = '03 Projects/';
const iso = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const esc = s => String(s || '').replace(/[\\/:*?"<>|]/g,'-').trim();
const ystr = s => JSON.stringify(String(s));
const props = (app,f) => (app.metadataCache.getFileCache(f)?.frontmatter || {});
const typeOf = (app,f) => String(props(app,f).type || '').toLowerCase();
const isMd = f => f && f.extension === 'md';
function projectPath(app,file){
  if(!file) return null;
  const p = file.path;
  if(p.startsWith(PREFIX)){
    const seg=p.substring(PREFIX.length).split('/');
    if(seg.length >= 2) return PREFIX+seg[0];
  }
  const raw=props(app,file).project;
  if(typeof raw === 'string'){
    const match=raw.match(/\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/);
    const link=match ? match[1] : raw;
    const resolved=app.metadataCache.getFirstLinkpathDest(link,file.path);
    if(resolved && resolved.path.startsWith(PREFIX)) return PREFIX+resolved.path.substring(PREFIX.length).split('/')[0];
  }
  return null;
}
function projectFiles(app){return app.vault.getMarkdownFiles().filter(f=>typeOf(app,f)==='project' && f.path.startsWith(PREFIX));}
function rootNote(app,dir){return projectFiles(app).find(f=>f.parent.path===dir)||null;}
function projectLabel(dir){return dir ? dir.split('/').pop() : 'Unassigned';}
function related(app,dir){return app.vault.getMarkdownFiles().filter(f=>f.path.startsWith(PREFIX) && projectPath(app,f)===dir && typeOf(app,f)!=='project');}
function setText(parent,tag,txt,cls){const el=parent.createEl(tag,{text:String(txt||'')}); if(cls)el.addClass(cls);return el;}
function btn(parent,label,cb,cls){const b=parent.createEl('button',{text:label});if(cls)b.addClass(cls);b.addEventListener('click',cb);return b;}
async function setProps(app,file,patch){await app.fileManager.processFrontMatter(file,fm=>{Object.entries(patch).forEach(([k,v])=>{fm[k]=v;});});}
function dateVal(v){if(!v)return '';if(v instanceof Date)return iso(v);return String(v).slice(0,10);}
class PickModal extends Modal {
  constructor(app,title,choices,onPick){super(app);this.heading=title;this.choices=choices;this.onPick=onPick;}
  onOpen(){this.contentEl.empty();setText(this.contentEl,'h3',this.heading);for(const item of this.choices){btn(this.contentEl,item.label,()=>{this.close();this.onPick(item.value);},'ops-pick');}}
  onClose(){this.contentEl.empty();}
}
class NameModal extends Modal {
  constructor(app,title,cb){super(app);this.heading=title;this.cb=cb;}
  onOpen(){this.contentEl.empty();setText(this.contentEl,'h3',this.heading);const inp=this.contentEl.createEl('input',{type:'text',placeholder:'Note title'});inp.addClass('ops-name-input');const done=()=>{const name=esc(inp.value);if(!name){new Notice('Enter a title');return;}this.close();this.cb(name);};btn(this.contentEl,'Create',done,'mod-cta');inp.addEventListener('keydown',e=>{if(e.key==='Enter')done();});setTimeout(()=>inp.focus(),30);}
}
class WorkspaceChild extends MarkdownRenderChild{
 constructor(container,plugin,source,opts){super(container);this.plugin=plugin;this.source=source;this.opts=opts;this.month=new Date();this.view=opts.view||'overview';this.scope=opts.scope||'project';this.dir=null;}
 onload(){this.render();this.registerEvent(this.plugin.app.metadataCache.on('changed',()=>this.schedule()));this.registerEvent(this.plugin.app.vault.on('create',()=>this.schedule()));this.registerEvent(this.plugin.app.vault.on('delete',()=>this.schedule()));}
 schedule(){if(this.refreshing)return;this.refreshing=true;setTimeout(()=>{this.refreshing=false;if(this.containerEl.isConnected)this.render();},250);}
 render(){
  const app=this.plugin.app, host=this.containerEl;host.empty();host.addClass('ops-workspace');
  const current=app.vault.getAbstractFileByPath(this.source);const dirs=projectFiles(app).map(f=>f.parent.path);
  if(this.dir && !dirs.includes(this.dir))this.dir=null;
  if(!this.dir){this.dir=this.scope==='project'?projectPath(app,current):null;}
  const top=host.createDiv({cls:'ops-top'});
  const heading=top.createDiv();setText(heading,'div',this.dir?projectLabel(this.dir):'All projects','ops-title');setText(heading,'div',this.dir?'Project workspace':'Operations overview','ops-muted');
  const actions=top.createDiv({cls:'ops-actions'});
  const sel=actions.createEl('select');sel.createEl('option',{text:'All projects',value:''});dirs.sort().forEach(dir=>sel.createEl('option',{text:projectLabel(dir),value:dir}));sel.value=this.dir||'';sel.addEventListener('change',()=>{this.dir=sel.value||null;this.render();});
  btn(actions,'+ New',()=>this.plugin.chooseCreate(this.dir));btn(actions,'↻',()=>this.render());
  const tabs=host.createDiv({cls:'ops-tabs'});for(const [key,label] of [['overview','Overview'],['work','Work'],['calendar','Calendar'],['records','Records']]){const b=btn(tabs,label,()=>{this.view=key;this.render();});if(this.view===key)b.addClass('is-active');}
  const content=host.createDiv({cls:'ops-content'});
  if(this.view==='calendar')this.renderCalendar(content);
  else if(this.view==='work')this.renderWork(content);
  else if(this.view==='records')this.renderRecords(content);
  else this.renderOverview(content);
 }
 files(){const all=this.plugin.app.vault.getMarkdownFiles().filter(f=>!f.path.startsWith('99 Archive/'));return this.dir?related(this.plugin.app,this.dir):all.filter(f=>['tasking','work-item','bom','vendor-update','meeting','troubleshooting','general'].includes(typeOf(this.plugin.app,f)));}
 trackables(){return this.files().filter(f=>['tasking','work-item','bom'].includes(typeOf(this.plugin.app,f)) || props(this.plugin.app,f).track_global===true);}
 renderOverview(el){const app=this.plugin.app;
  if(this.dir){const main=rootNote(app,this.dir);const p=main?props(app,main):{};
   const strip=el.createDiv({cls:'ops-summary'});setText(strip,'strong',`Project: ${p.status||'Open'}`);if(p.hold===true)setText(strip,'span','⏸ Project hold active','ops-alert');if(p.hold_reason)setText(strip,'p',p.hold_reason);
   if(main)btn(strip,'Open project note',()=>this.plugin.open(main));
   if(main)btn(strip,p.hold===true?'Resolve project hold':'Place on hold',async()=>{if(p.hold===true){await setProps(app,main,{hold:false,release_review:true});new Notice('Hold resolved. Review affected taskings below.');}else{await setProps(app,main,{hold:true,release_review:false});new Notice('Project on hold; tasking statuses unchanged.');}this.render();});
   if(p.release_review===true){const pending=related(app,this.dir).filter(f=>props(app,f).affected_by_hold===true && props(app,f).release_reviewed!==true);const panel=el.createDiv({cls:'ops-review'});setText(panel,'h4',`Review & Release (${pending.length})`);setText(panel,'p','Hold lifted. Review each affected item. Releasing does not change its recorded status.');pending.forEach(f=>{const line=panel.createDiv({cls:'ops-item'});btn(line,f.basename,()=>this.plugin.open(f),'ops-link');btn(line,'Release',async()=>{await setProps(app,f,{release_reviewed:true,affected_by_hold:false});this.render();});});if(!pending.length)btn(panel,'Close review',async()=>{await setProps(app,main,{release_review:false});this.render();});}
  } else {const summary=el.createDiv({cls:'ops-summary'});setText(summary,'strong',`${projectFiles(app).length} projects`);setText(summary,'p','Select a project above to focus its work and calendar.');}
  const list=this.trackables();const active=list.filter(f=>String(props(app,f).status||'Open').toLowerCase()!=='complete');const today=iso(new Date());const dated=active.filter(f=>dateVal(props(app,f).follow_up)||dateVal(props(app,f).due));const due=dated.filter(f=>(dateVal(props(app,f).follow_up)||dateVal(props(app,f).due))<=today);
  const metrics=el.createDiv({cls:'ops-metrics'});[['Open taskings',active.length],['Follow-ups due',due.length],['Dated items',dated.length]].forEach(([k,v])=>{const box=metrics.createDiv({cls:'ops-metric'});setText(box,'strong',v);setText(box,'span',k);});
  setText(el,'h4','Attention & upcoming');this.renderRows(el,active.filter(f=>dateVal(props(app,f).follow_up)||dateVal(props(app,f).due)).sort((a,b)=>(dateVal(props(app,a).follow_up)||dateVal(props(app,a).due)).localeCompare(dateVal(props(app,b).follow_up)||dateVal(props(app,b).due))).slice(0,10));
  if(this.dir){setText(el,'h4','Project taskings');this.renderRows(el,active.slice(0,12));}
  else {setText(el,'h4','Projects');projectFiles(app).forEach(f=>{const row=el.createDiv({cls:'ops-item'});btn(row,f.basename,()=>{this.dir=f.parent.path;this.render();},'ops-link');const p=props(app,f);setText(row,'span',p.hold===true?'On Hold':p.status||'Open','ops-pill');});}
 }
 renderRows(el,files){const app=this.plugin.app;if(!files.length){setText(el,'p','Nothing to show in this view.','ops-muted');return;}for(const f of files){const p=props(app,f);const row=el.createDiv({cls:'ops-item'});const left=row.createDiv({cls:'ops-item-main'});btn(left,f.basename,()=>this.plugin.open(f),'ops-link');const details=[projectLabel(projectPath(app,f)),p.follow_up?`Follow up ${dateVal(p.follow_up)}`:'',p.due?`Due ${dateVal(p.due)}`:''].filter(Boolean).join(' · ');setText(left,'div',details,'ops-muted');const holdProject=projectPath(app,f);const project=holdProject?rootNote(app,holdProject):null;const held=project && props(app,project).hold===true && p.affected_by_hold!==false;
   if(held)setText(row,'span','Inherited hold','ops-pill ops-alert');
   const select=row.createEl('select');STATES.forEach(s=>select.createEl('option',{value:s,text:s}));select.value=STATES.includes(p.status)?p.status:'Open';select.addEventListener('change',async()=>{await setProps(app,f,{status:select.value});new Notice('Status updated');});
  }}
 renderWork(el){const list=this.trackables().sort((a,b)=>a.basename.localeCompare(b.basename));setText(el,'h4',`Taskings & tracked work (${list.length})`);setText(el,'p','Statuses are editable here. Local Markdown checkboxes stay in their notes unless you create a tracked tasking.','ops-muted');this.renderRows(el,list);}
 renderRecords(el){const list=this.files().filter(f=>!['tasking','work-item','bom'].includes(typeOf(this.plugin.app,f)));setText(el,'h4',`Related records (${list.length})`);this.renderRows(el,list);}
 renderCalendar(el){const app=this.plugin.app;const controls=el.createDiv({cls:'ops-cal-controls'});btn(controls,'‹',()=>{this.month=new Date(this.month.getFullYear(),this.month.getMonth()-1,1);this.render();});setText(controls,'strong',this.month.toLocaleDateString(undefined,{month:'long',year:'numeric'}));btn(controls,'›',()=>{this.month=new Date(this.month.getFullYear(),this.month.getMonth()+1,1);this.render();});
  const events=[];for(const f of this.trackables()){const p=props(app,f);for(const [field,label] of [['due','Due'],['follow_up','Follow-up'],['scheduled','Scheduled']]){const date=dateVal(p[field]);if(/^\d{4}-\d{2}-\d{2}$/.test(date))events.push({date,label,file:f});}}
  const grid=el.createDiv({cls:'ops-calendar'});['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>setText(grid,'div',d,'ops-day-head'));
  const y=this.month.getFullYear(),m=this.month.getMonth(),first=new Date(y,m,1).getDay(),last=new Date(y,m+1,0).getDate();for(let n=0;n<first;n++)grid.createDiv({cls:'ops-day ops-blank'});
  for(let day=1;day<=last;day++){const cell=grid.createDiv({cls:'ops-day'});const d=iso(new Date(y,m,day));setText(cell,'div',day,'ops-day-num');for(const e of events.filter(x=>x.date===d).slice(0,4)){btn(cell,`${e.label}: ${e.file.basename}`,()=>this.plugin.open(e.file),'ops-event');}const count=events.filter(x=>x.date===d).length;if(count>4)setText(cell,'span',`+${count-4} more`,'ops-muted');}
  setText(el,'p','Dates show tracked note properties only. Tentative provider windows are intentionally excluded unless entered as a firm scheduled date.','ops-muted');
 }
}
module.exports = class OperationsWorkspace extends Plugin {
 async onload(){this.registerMarkdownCodeBlockProcessor('ops-view',(src,el,ctx)=>{const opts={};src.split('\n').forEach(line=>{const m=line.match(/^\s*(scope|view):\s*(.+?)\s*$/);if(m)opts[m[1]]=m[2];});ctx.addChild(new WorkspaceChild(el,this,ctx.sourcePath,opts));});
 this.addCommand({id:'create-in-project',name:'Create note in current project',callback:()=>this.chooseCreate(projectPath(this.app,this.app.workspace.getActiveFile()))});
 this.addCommand({id:'open-project-workspace',name:'Open Operations Home',callback:()=>{const f=this.app.vault.getAbstractFileByPath('00 Dashboard/Home.md');if(f)this.open(f);}});
 }
 async open(file){await this.app.workspace.getLeaf(false).openFile(file);}
 chooseCreate(dir){const app=this.app;const chooseType=selectedDir=>new PickModal(app,'Choose note template',TYPES.map(x=>({label:x,value:x})),type=>new NameModal(app,`New ${type}`,name=>this.create(selectedDir,type,name)).open()).open();if(dir){chooseType(dir);return;}const dirs=projectFiles(app).map(f=>f.parent.path);new PickModal(app,'Choose project',dirs.map(d=>({label:projectLabel(d),value:d})),chooseType).open();}
 async create(dir,type,name){try{const app=this.app;const folder=app.vault.getAbstractFileByPath(dir);if(!folder){new Notice('Project folder not found');return;}const fileName=esc(name);let path=`${dir}/${fileName}.md`;let i=2;while(app.vault.getAbstractFileByPath(path)){path=`${dir}/${fileName} ${i++}.md`;}
 const template=app.vault.getAbstractFileByPath(`98 Templates/Template - ${type}.md`);let body=template?await app.vault.read(template):`---\ntype: general\nproject: ${ystr(`[[${dir}/${projectLabel(dir)}]]`)}\n---\n# ${fileName}\n`;
 body=body.replaceAll('{{TITLE}}',fileName).replaceAll('{{DATE}}',iso(new Date())).replaceAll('{{PROJECT_LINK}}',`[[${dir}/${projectLabel(dir)}]]`).replaceAll('{{PROJECT_NAME}}',projectLabel(dir));
 const created=await app.vault.create(path,body);await this.open(created);new Notice(`Created ${type} in ${projectLabel(dir)}`);
 }catch(e){new Notice(`Creation failed: ${e.message}`);console.error(e);}}
};
