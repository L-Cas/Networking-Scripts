# Operations Development Vault — v0.2

**This is a separate development vault. Do not overwrite your modified production vault.** All names, sites, vendors, and dates in this package are fictional examples.

## Install / open

1. Unzip the archive to a new folder.
2. In Obsidian choose **Open folder as vault** and select that folder.
3. In **Settings → Community plugins**, allow community plugins and enable **Operations Workspace (v0.2 Prototype)**. The plugin is included in `.obsidian/plugins/operations-workspace`; it does not require an internet download. Obsidian may require a restart or plugin toggle after opening.
4. In **Settings → Appearance → CSS snippets**, enable **operations-dashboard** if not already enabled.
5. Open [[00 Dashboard/Home]]. Select a project, then use **Overview / Work / Calendar / Records** and **+ New**.
6. Open [[03 Projects/Baltimore Site Standup/Baltimore Site Standup]] or [[03 Projects/Building B Network Procurement/Building B Network Procurement]] to see the same views embedded in project notes.

## What works in this prototype

- Project selection and switching views on the main dashboard.
- Embedded project-scoped Overview / Work / Calendar / Records in project notes.
- Project-aware **+ New** creation with six selectable Markdown templates.
- Editing tracked note status directly from the Work view.
- A month calendar using tracked note `due`, `follow_up`, and `scheduled` properties.
- Project hold toggle without rewriting tasking statuses.
- Hold resolution opens **Review & Release** for taskings marked `affected_by_hold: true`. Release marks each item reviewed; it **does not** change its status.
- Notes stay in their project folder; project properties allow relationships and filtering.

## Deliberate limitations

- This is a **custom local plugin prototype**, not an official community plugin or verified production software. Its JavaScript passes syntax checks but **has not been run inside your installed Obsidian version**.
- Local Markdown checkboxes are not automatically converted into global tracked items. For a global item, use **+ New → Tasking** (or manually set `track_global: true` on a note).
- Dependency chains are recorded in notes; no automatic graph-based blocker release is implemented. Review & Release is project-hold scoped and deliberately conservative.
- Calendar shows one date per property; estimated ranges are intentionally not plotted as firm dates. No Outlook/Microsoft integration.
- No plugin automatically copies your existing production vault changes. Migrate only after validating behavior in a development copy.
- The bundled plugin is source code. Review it with your organization's security/software policy before using at work.

## Fast test

See [[97 Reference/System/v0.2 Acceptance Tests]]. If the embedded `ops-view` block renders as plain code, the plugin is not enabled.

## Next release candidates

Inline-task promotion, better keyboard shortcuts, per-workstream filtering, and optional Operon integration **after** its compatibility with the project-scoped views is verified.
