---
type: bom
project: "{{PROJECT_LINK}}"
status: Open
created: "{{DATE}}"
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up: 
due: 
---

# {{TITLE}}

## Scope and requirements


## Equipment / quantities


## Vendor questions and quotes


## Open actions
- [ ] 

## Pending responses


## Estimated delivery windows (not firm dates)


## Decisions and revisions


## Activity log
- {{DATE}} — Created.
