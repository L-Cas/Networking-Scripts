---
type: meeting
project: "{{PROJECT_LINK}}"
status: Open
created: "{{DATE}}"
track_global: false
---

# {{TITLE}}

## Attendees / context


## Scratch notes


## Decisions


## Follow-up actions
- [ ] 

## Linked taskings
