---
type: troubleshooting
project: "{{PROJECT_LINK}}"
status: Open
created: "{{DATE}}"
---

# {{TITLE}}

## Symptom and impact


## Observations


## Tests and results


## Actions
- [ ] 

## Resolution / next step
