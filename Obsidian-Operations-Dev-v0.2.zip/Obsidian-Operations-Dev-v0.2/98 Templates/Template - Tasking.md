---
type: tasking
project: "{{PROJECT_LINK}}"
status: Open
created: "{{DATE}}"
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up: 
due: 
---

# {{TITLE}}

## Current situation


## Next actions
- [ ] 

## Dependencies


## Activity log
- {{DATE}} — Created.

## Related records
