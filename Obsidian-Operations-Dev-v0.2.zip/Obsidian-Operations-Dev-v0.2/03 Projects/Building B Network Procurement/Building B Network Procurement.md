---
type: project
status: In Progress
hold: false
release_review: false
location: "[[04 Locations/Baltimore]]"
---
# Building B Network Procurement

> [!tip] Project workspace
> Create notes with **+ New** and use the Work / Calendar / Records tabs.

```ops-view
scope: project
view: overview
```

## Outcome

Finalize a fictional building network equipment BOM, receive approved quotes, and coordinate delivery.

## Current situation

Multiple vendor questions and revised quotes are in flight. Follow-up dates are reminders, **not** promises of delivery.

## Key taskings

- [[03 Projects/Building B Network Procurement/Building B BOM and Quotes]]
- [[03 Projects/Building B Network Procurement/Optics Compatibility Review]]

## Decisions

- No purchase order is authorized by this demo.
