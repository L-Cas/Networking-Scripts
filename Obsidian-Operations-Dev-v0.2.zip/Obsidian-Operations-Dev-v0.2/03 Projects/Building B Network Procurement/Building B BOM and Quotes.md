---
type: bom
project: "[[03 Projects/Building B Network Procurement/Building B Network Procurement]]"
status: In Progress
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up: 2026-11-06
due:
---
# Building B BOM and Quotes

## Current situation

Vendor A is preparing a revised quote. Vendor B needs optics clarification. This workstream can remain open for months.

## Actions
- [ ] Follow up with Vendor A on revised quote
- [ ] Clarify transceiver requirements for Vendor B
- [ ] Compare quote revisions

## Quotes and related records
- [[03 Projects/Building B Network Procurement/2026-11-03 Vendor A Clarification]]

## Activity log
- 2026-11-03 — Vendor A requested updated port quantities.
- 2026-10-27 — Revised scope received.
