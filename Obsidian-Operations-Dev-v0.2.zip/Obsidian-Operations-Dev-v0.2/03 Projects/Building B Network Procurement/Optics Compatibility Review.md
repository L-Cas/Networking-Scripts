---
type: tasking
project: "[[03 Projects/Building B Network Procurement/Building B Network Procurement]]"
status: Waiting
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up: 2026-11-09
due:
---
# Optics Compatibility Review

## Current situation

Waiting on fictional vendor confirmation of compatible optics. Other BOM work may continue.

## Next actions
- [ ] Check vendor response and update BOM
