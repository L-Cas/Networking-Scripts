---
type: tasking
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
status: Open
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up: 2026-11-05
due:
---
# Router Deployment

## Current situation

Provider circuit installation and T&T must be completed before scheduling router configuration with Patrick.

## Next actions
- [ ] Follow up on provider completion window
- [ ] Reach out to Patrick to schedule router setup when ready
- [ ] Notify Bob of superseding project timeline

## Dependencies

- [[03 Projects/Baltimore Site Standup/Circuit Readiness]]

## Activity log
- 2026-11-03 — Project on hold pending external work.
