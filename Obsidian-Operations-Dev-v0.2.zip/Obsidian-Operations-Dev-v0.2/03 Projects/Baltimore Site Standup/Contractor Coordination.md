---
type: tasking
project: "[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"
status: Open
track_global: true
affected_by_hold: true
release_reviewed: false
follow_up:
due:
---
# Contractor Coordination

## Current situation

Existing contractor taskings remain open while the project is on hold. Their recorded status is not rewritten.

## Next actions
- [ ] Reconfirm availability after circuit readiness
