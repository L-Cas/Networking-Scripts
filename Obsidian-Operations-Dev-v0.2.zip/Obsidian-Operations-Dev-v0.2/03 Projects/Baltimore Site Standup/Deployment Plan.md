---
type: project-note
status: In Progress
project: '[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]'
location: '[[04 Locations/Baltimore]]'
---

# Deployment Plan

## Phases

- [x] Site prerequisites
- [ ] Equipment received
- [ ] Rack / power verification
- [ ] Network installation
- [ ] Validation
- [ ] Handoff

## Notes

This note demonstrates that a project note can contain several checkboxes without every checkbox becoming a separate Work Item.
