---
type: project-note
status: In Progress
project: '[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]'
location: '[[04 Locations/Baltimore]]'
---

# Vendor Notes

- 2026-10-27 — Vendor moved estimated delivery to 2026-10-30.
- 2026-10-29 — Need confirmation that spare optics are included.
- Source meeting: [[05 Meetings/Baltimore Vendor Coordination/2026-10-27 - Baltimore Vendor Coordination]]
