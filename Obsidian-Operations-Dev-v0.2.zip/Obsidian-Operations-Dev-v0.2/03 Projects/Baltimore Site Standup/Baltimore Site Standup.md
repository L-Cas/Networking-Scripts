---
type: project
status: On Hold
progress: 68
target: 2026-11-20
locations:
- '[[04 Locations/Baltimore]]'
hold: true
release_review: false
hold_reason: Provider circuit installation and T&T are pending; timing unconfirmed.
---

# Baltimore Site Standup

> [!tip] Project workspace
> Use **+ New** to create a note in this project. Switch between Work, Calendar, and Records below. Keep high-level decisions in this project note.

```ops-view
scope: project
view: overview
```


## Outcome

Bring the fictional Baltimore site online with network, firewall, vendor, and validation work completed.

## Current state

- **Status:** On Track
- **Target:** 2026-11-20
- **Task completion:** 68% *(demo value; not a claim of true project completion)*
- **Primary blocker:** Equipment delivery timing

## Next actions

- [[02 Work Items/Confirm Baltimore equipment shipment]]
- [[02 Work Items/Review Baltimore switch configuration]]
- [[02 Work Items/Verify Baltimore rack power]]
- [[02 Work Items/Locate spare firewall]]

## Project notes

- [[03 Projects/Baltimore Site Standup/Switch Configuration]]
- [[03 Projects/Baltimore Site Standup/Deployment Plan]]
- [[03 Projects/Baltimore Site Standup/Vendor Notes]]

## Meetings

- [[05 Meetings/Baltimore Vendor Coordination/2026-10-27 - Baltimore Vendor Coordination]]
- [[05 Meetings/Weekly Team Meeting/2026-10-26 - Weekly Team Meeting]]

## Log

- 2026-10-19 — Initial equipment list reviewed.
- 2026-10-26 — Shipment follow-up created from weekly meeting.
- 2026-10-27 — Vendor provided revised delivery window.
