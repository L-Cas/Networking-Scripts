---
type: project
status: On Track
progress: 42
target: 2027-02-15
locations:
- '[[04 Locations/Baltimore]]'
- '[[04 Locations/DC]]'
- '[[04 Locations/Richmond]]'
hold: false
release_review: false
---

# Campus Switch Refresh

> [!tip] Project workspace
> Use **+ New** to create a note in this project. Switch between Work, Calendar, and Records below. Keep high-level decisions in this project note.

```ops-view
scope: project
view: overview
```


## Outcome

Standardize fictional campus access switching across multiple locations.

## Why this project matters to the demo

This proves that a project can span several locations without being physically stored under any one site.

## Open work

- [[02 Work Items/Review campus switch baseline]]
- [[02 Work Items/Confirm maintenance window]]

## Notes

- [[03 Projects/Campus Switch Refresh/Scope Notes]]
