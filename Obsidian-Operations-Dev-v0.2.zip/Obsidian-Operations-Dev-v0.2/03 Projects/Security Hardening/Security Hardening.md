---
type: project
status: Blocked
progress: 25
target: 2026-12-15
locations:
- '[[04 Locations/DC]]'
- '[[04 Locations/Richmond]]'
hold: false
release_review: false
---

# Security Hardening

> [!tip] Project workspace
> Use **+ New** to create a note in this project. Switch between Work, Calendar, and Records below. Keep high-level decisions in this project note.

```ops-view
scope: project
view: overview
```


## Current state

Blocked pending approval of a fictional exception request.

## Open work

- [[02 Work Items/Security hardening exception review]]
