# Property Dictionary — v0.2

| Property | Type | Purpose |
|---|---|---|
| `type` | text | `project`, `tasking`, `bom`, `general`, `vendor-update`, `meeting`, `troubleshooting`, legacy `work-item` |
| `project` | link text | Main project note relationship, e.g. `"[[03 Projects/Baltimore Site Standup/Baltimore Site Standup]]"` |
| `status` | text | Recorded tasking status, not overwritten by project hold |
| `track_global` | boolean | Whether non-tasking notes appear in work/calendar views |
| `follow_up` | date | Date to check back with someone |
| `due` | date | Actual deadline, not a vendor estimate |
| `scheduled` | date | Firm scheduled date |
| `hold` | boolean | Project-wide pause; inherited for display |
| `hold_reason` | text | Why the project is paused |
| `affected_by_hold` | boolean | Whether a tasking participates in hold/release review |
| `release_review` | boolean | Project review queue is active after hold resolution |
| `release_reviewed` | boolean | Whether a specific tasking has been reviewed |

Local checkboxes are ordinary Markdown and are intentionally not global trackables.
