# Changelog

## v0.2 — development release

- Built a project-first workspace in a local Obsidian plugin (project selector, views, quick creation).
- Added six practical templates and separate tasking notes.
- Added project-filtered work and calendar views, status editing, and non-destructive hold review.
- Added fictional circuit-readiness and BOM examples.
- Simplified Home and retained existing v0.1 content, folders, Bases, and archive.
- Removed DataviewJS as a dependency for new views.

## v0.1

Original test vault retained as the source baseline. See original ZIP for comparison.
