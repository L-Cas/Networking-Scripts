# Plugin Registry — v0.2

| Component | Included | Purpose | Status |
|---|---|---|---|
| Obsidian Bases (core) | Core enabled | Optional native databases from v0.1 | Existing files retained; test locally |
| Operations Workspace (local plugin) | Yes, `.obsidian/plugins/operations-workspace` | Project scope, quick creation, work/calendar views, hold review | Prototype, syntax-checked, not Obsidian-runtime verified |
| Operations dashboard CSS | Yes | Readable project workspace and calendar | Included |
| Obsidian Templates (core) | Core enabled | Standard Markdown templates | Included |
| Operon | No | Candidate for inline tasks, dependencies, timeline | Deferred pending isolated compatibility test |
| TaskNotes | No | Alternative task engine | Deferred |
| QuickAdd | No | Alternative capture automation | Not needed for v0.2 prototype's + New |
| Dataview / DataviewJS | No | Querying notes | Deliberately not required |
| Meta Bind | No | In-note controls | Deliberately not required |

Do not install competing task engines together during the initial test. Obsidian plugin security and organization policy apply to the included local plugin too.
